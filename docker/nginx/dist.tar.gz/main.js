(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "+xtZ":
/*!*********************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/environments/environment.ts ***!
  \*********************************************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 0:
/*!*******************************************************!*\
  !*** multi ./projects/dsgov-angular-demo/src/main.ts ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/fabianorodrigo/Projetos/angular/github/dsgov-angular-components/projects/dsgov-angular-demo/src/main.ts */"0i3V");


/***/ }),

/***/ "05dn":
/*!**************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header-logo/header-logo.component.ts ***!
  \**************************************************************************************************/
/*! exports provided: HeaderLogoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderLogoComponent", function() { return HeaderLogoComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


class HeaderLogoComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        // texto assinatura (texto ao lado direito da logo)
        this.textoAssinatura = 'Governo Federal';
    }
}
HeaderLogoComponent.ɵfac = function HeaderLogoComponent_Factory(t) { return new (t || HeaderLogoComponent)(); };
HeaderLogoComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: HeaderLogoComponent, selectors: [["br-header-logo"]], inputs: { logo: "logo", textoAssinatura: "textoAssinatura" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 5, vars: 2, consts: [[1, "header-logo"], ["alt", "logo", 3, "src"], [1, "br-divider", "vertical", "mx-half", "mx-sm-1"], [1, "header-sign"]], template: function HeaderLogoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "img", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", ctx.logo, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.textoAssinatura);
    } }, encapsulation: 2 });


/***/ }),

/***/ "0BJg":
/*!*******************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/menu.json ***!
  \*******************************************************/
/*! exports provided: 0, 1, default */
/***/ (function(module) {

module.exports = JSON.parse("[{\"classIconeFontAwesome\":\"fas fa-hamburger\",\"texto\":\"Grupo 1\",\"itens\":[{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-users\",\"texto\":\"Entidade\",\"url\":\"/entidade\"}},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-map-signs\",\"texto\":\"Qualquer coisa\"}},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-map-pin\",\"texto\":\"Jureba\"},\"subItens\":[{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-photo-video\",\"texto\":\"Obras publicitárias\",\"url\":\"http://oglobo.com.br\"}},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-money-bill-alt\",\"texto\":\"Fomento\",\"url\":\"http://ge.com.br\"}},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-film\",\"texto\":\"Esse tem subitens\"},\"subItens\":[{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-users\",\"texto\":\"Teste \",\"url\":\"/entidade\"}},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-allergies\",\"texto\":\"Teste \",\"url\":\"/entidade\"}}]}]},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"url\",\"classIconeFontAwesome\":\"fas fa-calendar-alt\",\"texto\":\"Eventos\",\"url\":\"http://uol.com.br\",\"novaAba\":true}},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-university\",\"texto\":\"Instituições\"}},{\"exibicao\":\"sempre\",\"link\":{\"tipo\":\"rota\",\"classIconeFontAwesome\":\"fas fa-film\",\"texto\":\"Obras não publicitárias\"}}]},{\"classIconeFontAwesome\":\"fas fa-futbol\",\"texto\":\"Grupo 2\",\"itens\":[{\"exibicao\":\"sempre\",\"link\":{\"classIconeFontAwesome\":\"fas fa-users\",\"texto\":\"Entidade\",\"url\":\"/entidade\"}}]}]");

/***/ }),

/***/ "0QCI":
/*!********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/divider/divider.module.ts ***!
  \********************************************************************************/
/*! exports provided: DividerModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DividerModule", function() { return DividerModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _divider_divider_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./divider/divider.component */ "4yHK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



class DividerModule {
}
DividerModule.ɵfac = function DividerModule_Factory(t) { return new (t || DividerModule)(); };
DividerModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: DividerModule });
DividerModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](DividerModule, { declarations: [_divider_divider_component__WEBPACK_IMPORTED_MODULE_1__["DividerComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]], exports: [_divider_divider_component__WEBPACK_IMPORTED_MODULE_1__["DividerComponent"]] }); })();


/***/ }),

/***/ "0i3V":
/*!*************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/main.ts ***!
  \*************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "E5bW");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "+xtZ");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ "0joH":
/*!*****************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/item/tipo-item.enum.ts ***!
  \*****************************************************************************/
/*! exports provided: TipoItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TipoItem", function() { return TipoItem; });
class TipoItem {
}
TipoItem.PADRAO = 'padrao';
TipoItem.LINK = 'link';
TipoItem.BUTTON = 'button';
TipoItem.SELECTION = 'selection';


/***/ }),

/***/ "3dAS":
/*!*******************************************************************!*\
  !*** ./dist/dsgov-components/fesm2015/ancine-dsgov-components.js ***!
  \*******************************************************************/
/*! exports provided: BaseComponent, BreadcrumbComponent, BreadcrumbModule, ButtonComponent, ButtonModule, Densidade, DividerComponent, DividerModule, EstadoInput, FooterComponent, FooterModule, HeaderComponent, HeaderModule, InformacaoLicenca, InputComponent, InputModule, MenuComponent, MenuModule, RegraExibicaoMenu, SigninComponent, SigninModule, TamanhoHeader, TipoAgrupamentoLista, TipoLink, TipoSignin, base64LogoGovBr */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseComponent", function() { return BaseComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbComponent", function() { return BreadcrumbComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbModule", function() { return BreadcrumbModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return ButtonComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Densidade", function() { return Densidade; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DividerComponent", function() { return DividerComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DividerModule", function() { return DividerModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EstadoInput", function() { return EstadoInput; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterModule", function() { return FooterModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderModule", function() { return HeaderModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InformacaoLicenca", function() { return InformacaoLicenca; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputComponent", function() { return InputComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputModule", function() { return InputModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuModule", function() { return MenuModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegraExibicaoMenu", function() { return RegraExibicaoMenu; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninComponent", function() { return SigninComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninModule", function() { return SigninModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TamanhoHeader", function() { return TamanhoHeader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TipoAgrupamentoLista", function() { return TipoAgrupamentoLista; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TipoLink", function() { return TipoLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TipoSignin", function() { return TipoSignin; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "base64LogoGovBr", function() { return base64LogoGovBr; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");






/**
 * Estrutura com o texto de apresentação da licença e o nome da própria licença,
 * que vem em negrito em determinados componentes do DSGov
 */
class InformacaoLicenca {
    constructor() {
        this.label = 'Todo o conteúdo deste site está publicado sob a licença';
        this.nomeLicenca = 'Creative Commons Atribuição-SemDerivações 3.0';
    }
}

class BaseComponent {
    constructor() {
        /*** Classes aplicáveis ao componente (setadas em sua declaração no template do componente/página onde é utilizado) ***/
        this.ngClass = '';
    }
    /**
     * Recebe um {ngClass}, que pode ser uma string, array ou set de strings, e uma sequência de
     * parâmetros do tipo string. Filtra os nulos e realizada uma concatenação separada por espaços.
     * Utilizada para aplicar coleção de classes CSS em determinado elemento HTML
     *
     * @param ngClass string, array ou set de strings com classes CSS
     * @param classesCSS sequência de nomes de classes CSS
     * @returns classes CSS aplicáveis separadas por espaço
     */
    jc(ngClass, ...classesCSS) {
        return (classesCSS.filter((classe) => classe != null).join(' ') +
            (ngClass ? ' ' + ngClass : ''));
    }
}
BaseComponent.ɵfac = function BaseComponent_Factory(t) { return new (t || BaseComponent)(); };
BaseComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: BaseComponent, selectors: [["br-base"]], inputs: { id: "id", ngClass: "ngClass" }, decls: 0, vars: 0, template: function BaseComponent_Template(rf, ctx) { }, encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(BaseComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-base',
                template: '',
                styles: [],
            }]
    }], function () { return []; }, { id: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], ngClass: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class Densidade {
}
Densidade.ALTA = 'small';
Densidade.MEDIA = 'medium';
Densidade.BAIXA = 'large';

//logo gov.br
const base64LogoGovBr = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG8AAAAoCAMAAADHRlSGAAAAeFBMVEUAAAD5vRAoZK0oZK4odpQnY676vRD6vRAxd5IoZK8oY65GrUQnY64nZqolZa8oY677vRAmY6//vxBErUP6vRBFrUNFrUQnZK75vBBFrEP8vBD6vxBFrENFqkYnY676vRAoYq3/vxBErURGrEO7tyIoZK76vRBGrUS/9hXBAAAAJXRSTlMAwYDAEPDw1iBAoH/QcDDgf1AQZ2TawLCqmEUw8LCQkGAgOFCUOz6uWgAAAthJREFUWMPtltt2qjAQQIeEewUFsQh47wn9/z88NZkLINaX6pP7yWjIdiYzs4A/wjgUPODte/vevlvyJEnyV/l8tbS7lycA0O5JcLTHqL/irbrr8sOxBuRCa/HFmb4elRZ2Q7WyXD95Yd9H8EMRGGLhj3yrqBeiFmD/7fDRh+sP8Sk+TF83ee5ZKO1J1ncyA5a++Dq0MdvyC30U4M4tY/alRghi8eFRHkAcmCE1+7qwnxKVKGicDvWffH94FmeLfFXPvtrMAiXrhsLGGXbO13C0ZhZFvpB9Mf+YZlkaiG/b49aqLdsjCf9hQi/Wt+HbHGRR6yUvfG9yI5DRNtsN8YJ2dqTrXJ3SEhUfdrckV/41/JDRKvNE1Z7hfIZ61DlymxRRBY7jOMAN/LB2n7/QxzoRavTJORQQVTgVWITxAHKmvznoiL3cpZkcQyn1OJEIlRIuuTv4gokQv/jkGvEHtUrxAHKY+OytzG1Mxr4V+zz0YRL33A2XuXmmxr4Q7sVXPPBF/o6y2OBNPvRJmiTRtE4f5RMaCmtDiRVfzfm859P4wwlHdzCul+imXiiNzQVn2dAXALK451M8OO2yNpN+aHHfiusa49qs8R4t3HDjKtA3vpznQuFDoQ3R8cgEABmmYclTDNNZ1DoTX5DYLFF4B/FJ5LOAR8IKoKzCQf3E38JOuWqTB9MiOQS0iG99yR3fGRWMRLsR3x7TaGap4cYnpTR+kkamIMN0LT7cntJ9mSGBP/FJC8j8Yx+04TS6DouYdRvMjqL8BUNdDrM+SJZUpAXEg/4vt0NjKL2/J18DC3cy/ct8IboCJj4hV6mu1XVDMZpvZYXKaFuBcPlEYogX9mTOip/hu5eyDXb0LEe4h6abFs5tCb8Q5zfvlirJf3sAhBP37fMwacEvogbJ4XnY+0qVOkg1a3gW8w2fAPMK3wGEF/gUPJN8ORl6OTyZ+KS0Duyrqjr58Ez+A7sTAiW6Xr/YAAAAAElFTkSuQmCC';

class TipoLink {
}
/**
 * Rota dentro da própria aplicação tratado pelo Router
 * do Angular (sem recarregar página)
 */
TipoLink.ROTA = 'rota';
/**
 * Endereço que não representa uma rota tratada pela aplicação.
 * Tipicamente, um endereço externo
 */
TipoLink.URL = 'url';

class BaseModule {
}
BaseModule.ɵfac = function BaseModule_Factory(t) { return new (t || BaseModule)(); };
BaseModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: BaseModule });
BaseModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(BaseModule, { declarations: [BaseComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(BaseModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [BaseComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
            }]
    }], null, null); })();

const _c0 = ["*"];
class ButtonComponent extends BaseComponent {
    constructor() {
        super();
        //Evento de click
        this.click = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    ngOnInit() { }
    onClickComponent(event) {
        this.click.emit(event);
    }
}
ButtonComponent.ɵfac = function ButtonComponent_Factory(t) { return new (t || ButtonComponent)(); };
ButtonComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: ButtonComponent, selectors: [["br-button"]], inputs: { isDisabled: "isDisabled", isActive: "isActive", isLoading: "isLoading" }, outputs: { click: "click" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c0, decls: 2, vars: 7, consts: [["type", "button", 3, "ngClass", "click"]], template: function ButtonComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "button", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function ButtonComponent_Template_button_click_0_listener($event) { return ctx.onClickComponent($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"])("disabled", ctx.isDisabled)("active", ctx.isActive)("loading", ctx.isLoading);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx.jc(ctx.ngClass, "br-button"));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"]], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(ButtonComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-button',
                templateUrl: './button.component.html',
                styles: [],
            }]
    }], function () { return []; }, { click: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], isDisabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], isActive: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], isLoading: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class ButtonModule {
}
ButtonModule.ɵfac = function ButtonModule_Factory(t) { return new (t || ButtonModule)(); };
ButtonModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: ButtonModule });
ButtonModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], BaseModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(ButtonModule, { declarations: [ButtonComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], BaseModule], exports: [ButtonComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(ButtonModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [ButtonComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], BaseModule],
                exports: [ButtonComponent],
            }]
    }], null, null); })();

function BreadcrumbComponent_ng_container_7_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "li", 9);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "i", 10);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "span");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const item_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(item_r1.label);
} }
function BreadcrumbComponent_ng_container_7_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "li", 11);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "i", 10);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "a", 12);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const item_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("routerLink", item_r1.link);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(item_r1.label);
} }
function BreadcrumbComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, BreadcrumbComponent_ng_container_7_ng_container_1_Template, 5, 1, "ng-container", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, BreadcrumbComponent_ng_container_7_ng_template_2_Template, 4, 2, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const i_r2 = ctx.index;
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"])(3);
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", i_r2 == ctx_r0.itens.length - 1)("ngIfElse", _r4);
} }
class BreadcrumbComponent extends BaseComponent {
    constructor() {
        super();
        this.labelPaginaInicial = 'Página inicial';
        this.linkPaginaInicial = '/';
        this.itens = [];
    }
    ngOnInit() { }
}
BreadcrumbComponent.ɵfac = function BreadcrumbComponent_Factory(t) { return new (t || BreadcrumbComponent)(); };
BreadcrumbComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: BreadcrumbComponent, selectors: [["br-breadcrumb"]], inputs: { labelPaginaInicial: "labelPaginaInicial", linkPaginaInicial: "linkPaginaInicial", itens: "itens" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 8, vars: 3, consts: [["aria-label", "Breadcumb", 1, "br-breadcrumb"], [1, "crumb-list"], [1, "crumb", "home", 3, "routerLink"], [1, "br-button", "circle"], [1, "sr-only"], [1, "icon", "fas", "fa-home"], [4, "ngFor", "ngForOf"], [4, "ngIf", "ngIfElse"], ["breadcrumAncestral", ""], ["data-active", "active", 1, "crumb"], [1, "icon", "fas", "fa-chevron-right"], [1, "crumb"], [3, "routerLink"]], template: function BreadcrumbComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "ul", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "li", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "div", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "span", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(6, "i", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(7, BreadcrumbComponent_ng_container_7_Template, 4, 2, "ng-container", 6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("routerLink", ctx.linkPaginaInicial);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx.labelPaginaInicial);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx.itens);
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLink"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLinkWithHref"]], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(BreadcrumbComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-breadcrumb',
                templateUrl: './breadcrumb.component.html',
                styles: [],
            }]
    }], function () { return []; }, { labelPaginaInicial: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], linkPaginaInicial: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], itens: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class BreadcrumbModule {
}
BreadcrumbModule.ɵfac = function BreadcrumbModule_Factory(t) { return new (t || BreadcrumbModule)(); };
BreadcrumbModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: BreadcrumbModule });
BreadcrumbModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], BaseModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(BreadcrumbModule, { declarations: [BreadcrumbComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], BaseModule], exports: [BreadcrumbComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(BreadcrumbModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [BreadcrumbComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], BaseModule],
                exports: [BreadcrumbComponent],
            }]
    }], null, null); })();

class DividerComponent extends BaseComponent {
    constructor() {
        super();
        //Vertical ou horizontal
        this.orientacao = '';
    }
}
DividerComponent.ɵfac = function DividerComponent_Factory(t) { return new (t || DividerComponent)(); };
DividerComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: DividerComponent, selectors: [["br-divider"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 1, vars: 1, consts: [[3, "ngClass"]], template: function DividerComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "span", 0);
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx.jc(ctx.ngClass, "br-divider", ctx.orientacao));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"]], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(DividerComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-divider',
                templateUrl: './divider.component.html',
                styles: [],
            }]
    }], function () { return []; }, null); })();

class DividerModule {
}
DividerModule.ɵfac = function DividerModule_Factory(t) { return new (t || DividerModule)(); };
DividerModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: DividerModule });
DividerModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(DividerModule, { declarations: [DividerComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]], exports: [DividerComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(DividerModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [DividerComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
                exports: [DividerComponent],
            }]
    }], null, null); })();

class TipoItem {
}
TipoItem.PADRAO = 'padrao';
TipoItem.LINK = 'link';
TipoItem.BUTTON = 'button';
TipoItem.SELECTION = 'selection';

function ItemComponent_div_0_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"])(0);
} }
function ItemComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemComponent_div_0_ng_container_1_Template, 1, 0, "ng-container", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"])(5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r0.jc(ctx_r0.ngClass, "br-item"))("disabled", ctx_r0.isDisabled ? "disabled" : "");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngTemplateOutlet", _r4);
} }
function ItemComponent_div_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"])(0);
} }
function ItemComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemComponent_div_1_ng_container_1_Template, 1, 0, "ng-container", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"])(5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r1.jc(ctx_r1.ngClass, "br-item"))("disabled", ctx_r1.isDisabled ? "disabled" : "");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngTemplateOutlet", _r4);
} }
function ItemComponent_a_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"])(0);
} }
function ItemComponent_a_2_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "a", 8);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemComponent_a_2_ng_container_1_Template, 1, 0, "ng-container", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"])(5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r2.jc(ctx_r2.ngClass, "br-item"))("href", ctx_r2.href, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("target", ctx_r2.target)("disabled", ctx_r2.isDisabled ? "disabled" : "");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngTemplateOutlet", _r4);
} }
function ItemComponent_br_button_3_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"])(0);
} }
function ItemComponent_br_button_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-button", 9);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemComponent_br_button_3_ng_container_1_Template, 1, 0, "ng-container", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"])(5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r3.jc(ctx_r3.ngClass, "br-item"))("click", ctx_r3.click)("isActive", ctx_r3.isActive)("isDisabled", ctx_r3.isDisabled);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngTemplateOutlet", _r4);
} }
function ItemComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"])(0);
} }
const _c0$1 = ["*"];
class ItemComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.PADRAO = TipoItem.PADRAO;
        this.LINK = TipoItem.LINK;
        this.BUTTON = TipoItem.BUTTON;
        this.SELECTION = TipoItem.SELECTION;
        this.tipoItem = this.PADRAO;
        /*** Os Estados são representados em propriedades específicas ***/
        //se true, aplica a classe 'disabled'
        this.isDisabled = false;
        //se true, aplica a classe 'active'
        this.isActive = false;
        //se true, Aplica estilo selecionado
        this.isSelected = false;
    }
}
ItemComponent.ɵfac = function ItemComponent_Factory(t) { return new (t || ItemComponent)(); };
ItemComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: ItemComponent, selectors: [["br-item"]], inputs: { href: "href", target: "target", tipoItem: "tipoItem", click: "click", divider: "divider", isDisabled: "isDisabled", isActive: "isActive", isSelected: "isSelected" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c0$1, decls: 6, vars: 4, consts: [["role", "listitem", 3, "ngClass", "disabled", 4, "ngIf"], ["data-toggle", "selection", "role", "listitem", 3, "ngClass", "disabled", 4, "ngIf"], [3, "ngClass", "href", "target", "disabled", 4, "ngIf"], ["role", "listitem", 3, "ngClass", "click", "isActive", "isDisabled", 4, "ngIf"], ["innerHTML", ""], ["role", "listitem", 3, "ngClass", "disabled"], [4, "ngTemplateOutlet"], ["data-toggle", "selection", "role", "listitem", 3, "ngClass", "disabled"], [3, "ngClass", "href", "target", "disabled"], ["role", "listitem", 3, "ngClass", "click", "isActive", "isDisabled"]], template: function ItemComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(0, ItemComponent_div_0_Template, 2, 3, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemComponent_div_1_Template, 2, 3, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, ItemComponent_a_2_Template, 2, 5, "a", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, ItemComponent_br_button_3_Template, 2, 5, "br-button", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(4, ItemComponent_ng_template_4_Template, 1, 0, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.tipoItem == ctx.PADRAO);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.tipoItem == ctx.SELECTION);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.tipoItem == ctx.LINK);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.tipoItem == ctx.BUTTON);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgTemplateOutlet"]], styles: ["a[_ngcontent-%COMP%] {\n        text-decoration: none;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(ItemComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-item',
                templateUrl: './item.component.html',
                styles: [
                    `
      a {
        text-decoration: none;
      }
    `,
                ],
            }]
    }], function () { return []; }, { href: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], target: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], tipoItem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], click: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], divider: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], isDisabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], isActive: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], isSelected: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class ItemModule {
}
ItemModule.ɵfac = function ItemModule_Factory(t) { return new (t || ItemModule)(); };
ItemModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: ItemModule });
ItemModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(ItemModule, { declarations: [ItemComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]], exports: [ItemComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(ItemModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [ItemComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
                exports: [ItemComponent],
            }]
    }], null, null); })();

function GrupoFooterComponent_div_6_br_item_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-item", 8);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "div", 9);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("href", item_r2.url);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(item_r2.texto);
} }
function GrupoFooterComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoFooterComponent_div_6_br_item_1_Template, 3, 2, "br-item", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx_r0.links);
} }
class GrupoFooterComponent extends BaseComponent {
    constructor() {
        super();
        this.links = [];
        //Indica se o grupo de menu está expandido ou colapsado
        this.expandido = true;
    }
    ngOnInit() {
        //pegando tamanho da tela/janela
        this.windowWidth = window.innerWidth > 0 ? window.innerWidth : screen.width;
    }
    /**
     * Atualiza o atributo do tamanho da janela ao redimensionar a janela
     * @param event
     */
    onResize(event) {
        this.windowWidth = window.innerWidth;
    }
    // o click no grupo inverte a condição de expandido ou não do próprio componente de Grupo
    onClickComponent(event) {
        // aplica-se apenas para telas menores que 992 pois, no CSS, o ícone
        // de seta é exibido apenas em telas menores que isto:
        /*
        .br-footer .br-list.horizontal .br-item .support:last-child {
          display: none;
          pointer-events: none;
        }
        */
        if (this.windowWidth < 992) {
            this.expandido = !this.expandido;
        }
    }
}
GrupoFooterComponent.ɵfac = function GrupoFooterComponent_Factory(t) { return new (t || GrupoFooterComponent)(); };
GrupoFooterComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: GrupoFooterComponent, selectors: [["br-grupo-footer"]], hostBindings: function GrupoFooterComponent_HostBindings(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("resize", function GrupoFooterComponent_resize_HostBindingHandler($event) { return ctx.onResize($event); }, false, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresolveWindow"]);
    } }, inputs: { horizontal: "horizontal", grupo: "grupo", links: "links", expandido: "expandido" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 7, vars: 6, consts: [[1, "col"], ["href", "javascript:void(0)", 3, "click"], [1, "content", "text-down-01", "text-bold", "text-uppercase"], [1, "support"], ["aria-hidden", "true"], ["class", "br-list open", 4, "ngIf"], [1, "br-list", "open"], ["tipoItem", "link", "target", "_blank", 3, "href", 4, "ngFor", "ngForOf"], ["tipoItem", "link", "target", "_blank", 3, "href"], [1, "content"]], template: function GrupoFooterComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "a", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function GrupoFooterComponent_Template_a_click_1_listener($event) { return ctx.onClickComponent($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "div", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "div", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(5, "i", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(6, GrupoFooterComponent_div_6_Template, 2, 1, "div", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx.expandido ? "br-item header open" : "br-item header");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"])(" ", ctx.grupo, " ");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx.expandido ? "fas fa-angle-up" : "fas fa-angle-down");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.expandido);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], ItemComponent], styles: ["a[_ngcontent-%COMP%] {\n        text-decoration: none;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(GrupoFooterComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-grupo-footer',
                templateUrl: './grupo-footer.component.html',
                styles: [
                    `
      a {
        text-decoration: none;
      }
    `,
                ],
            }]
    }], function () { return []; }, { horizontal: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], grupo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], links: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], expandido: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], onResize: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['window:resize', ['$event']]
        }] }); })();

function FooterComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "br-grupo-footer", 15);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const grupo_r2 = ctx.$implicit;
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("horizontal", ctx_r0.horizontal)("grupo", grupo_r2)("links", ctx_r0.gruposLinks[grupo_r2]);
} }
function FooterComponent_div_8_ng_container_3_i_2_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "i", 21);
} if (rf & 2) {
    const perfil_r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(perfil_r4.classIconeFontAwesome);
} }
function FooterComponent_div_8_ng_container_3_span_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const perfil_r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(perfil_r4 == null ? null : perfil_r4.texto);
} }
function FooterComponent_div_8_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "a", 18);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, FooterComponent_div_8_ng_container_3_i_2_Template, 1, 2, "i", 19);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, FooterComponent_div_8_ng_container_3_span_3_Template, 2, 1, "span", 20);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const perfil_r4 = ctx.$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("href", perfil_r4.url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", perfil_r4.classIconeFontAwesome);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", !perfil_r4.classIconeFontAwesome);
} }
function FooterComponent_div_8_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 16);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "p", 17);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(2, "Redes Sociais");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, FooterComponent_div_8_ng_container_3_Template, 4, 3, "ng-container", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx_r1.linksRedesSociais);
} }
const _c0$2 = function () { return {}; };
const _c1 = function () { return { filter: "invert(1)" }; };
class FooterComponent extends BaseComponent {
    constructor(domSanitizer) {
        super();
        this.domSanitizer = domSanitizer;
        // Indica se o padrão de cores é invertido. Se TRUE, será apendado ao atributo
        // "class" o valor "[inverted]", o que deixa o rodapé na cor branca com fonte azul(invertido)
        // Se FALSE, o rodapé fica padrão: fundo azul e fonte branca
        this.invertido = false;
        // Se TRUE, a classe 'horizontal' é acionada ao elemento br-list
        this.horizontal = true;
        this.alt = 'gov.br';
        this.url2 = 'http://www.acessoainformacao.gov.br/';
        this.alt2 = 'Acesso à Informação';
        this.url3 = 'http://www.brasil.gov.br/';
        this.alt3 = 'Governo Federal';
        this.gruposLinks = {};
        // links para os perfis do órgão em redes sociais
        this.linksRedesSociais = [];
        // Indica a exibição ou não da informação sobre licença no menu
        this.exibeInformacaoLicenca = true;
        // Label de apresentação e nome da licença utilizada
        this.informacaoLicenca = new InformacaoLicenca();
        //gov.br negativo
        this.base64Imagem1Default = this.domSanitizer.bypassSecurityTrustUrl(`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAh8AAADFBAMAAAAGSY2CAAAALVBMVEVHcEz////////////////////////////////////////////////////////NXt0CAAAADnRSTlMAfbce9jkM61ChZ9rJihJ9h0oAAA+ySURBVHja7Z39j5RXFccvO53ZF9hm1ppaGjtZbEtBcPKoLIW2bohENNBMhuLWhshmKGirVrKFQoLGzSi21iqbpRWslW6ghL5g3EyREqS62aSGGLSTaY0vaNyws7PM7rzcv8EfZnZenvs9957nmS2JM8/9iTDPs/fezz33nHPPufc+QvxflZC0l02ipYsHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAUMX32Avnes69+ax184HsGRgY2LHexV/eMzBANrfv9LVfferVO4+4a/OG5WsWGps5f+zIzQTi/2256vwrjzr5q4GdJy9IKeX5V8/G1NF968JCXQ+/EnXc4u2/tjV427HoTQLScTJS/e/Mp2PsP7p7ovrekJ3VW8O1teVvq/7U0WMroMbt90i15P9+U4B8Ybj+h/Sp+lfDthfnFn7YWMNRJupf8v/CXt/Vym9t9p+UKef/pcTlcFVIfOqv06jnfuWxUT2Qnyu/ZG9nAdlY97+Tde90TajNvcQG8tkJSZUaSUsqP6YRkCXKY3EdkMBvQK2ZfzCAdEVoIB2wR39mAnlE6sq9tNBLNNuXKeOtnTJvwEqzcSMQv22AemullBjhEywgX5eSRWSfxGNvK8pjRR2Qh4hK05YJyI/RxCzr0ylK3i0GEBOPCpE2ibWDrYzbH5rVALGJfU35igGIMjNT1Rd+QnZlqxnIt6S5vFSal+oPCQBkDD8EgQTCdKUn9EDGaCBLNF0ZNQHpGGYAyQSFECKgjuYMAKI8FaSBPKWpNG/pgHRKXA1kVTsVY3ogvrDklHwUVzTNsboWCcQ3oav0gA6IMjFlxXnp1Hblih7I1ySvbBVCiEGO3e0mnkFAHtTWmY3SQPwaBa8f47ylA7JEcktKCNGuzqWY2ermSCCBCX2dB2kg62gg3YaeXNQAYU4YKaUsxGBVcbPV3UICecpQZ9YigahOooxSVk6VWBLIg5Jffged95TZ6o6SQIzDcZEC0gUeLneqgyHsFBDfsAMgeQuNy5ACJEwIkQrki8Y60xSQdTSQdca/miOB3C+dlANIGmeMVjdLO/7mEiSAINkiV1yK4rMIIP5hR43LWsB5zxmtbrERILMYCJwWPJUqpZQJAsj9Dlt3CDjvaaPVnW0ESD4GgSxD41WqZpDxV4sYiMnoAUOjjkzGDmQp5d27AlLSyAqQEcSuVA2rU49AIMsct64XOO92u9tPedTugOQgEKQnCqUYCeuvvguBjDluXRG8kzJZXashIPkYAJKmLdITrmqRFsteA99n0Gh3w5SScQdEBo2+eLnMCyGEmHIPxA3LQ+1GuxuhzJBLIFscAQlE3AMZc/HefLfJ7voJx901kCIXSNHZ2kwBQs2Y/XfsiIm+jxGkj5jsbjcZU3MJJBNjApkWcPnJBoJnTHYhEfMkbkQiabC7S0kr5BKIDDKB5IQQYsQ9ENi+7OtV2YetyI0b7G4/4bhrgWxb/d8XL1A/DjkBQj254uz6PY+dTmqABKDbXpsNgbHFfL/B7o4TjrsGSFkqdw2THWUBmRNCBAjbXc4twRRQGcgSXUBGs/R7TVKeKLa6s0Yg6agm11ZyuPRAtv117V8ipZqwW5atZkZ/RgJ5QhvVLQUHUAMvG+xuhMRFAKnJSBFELB2Qw+WNG31H38GJEinlezXt+zgFZByHgIwikoto7W4H5biTQO42ZkSCNJDM8foW7yXtcWWUkwSQCRQmsG+vALO6MKa1u91k9JYAMq33+0talQKS+ZutxSN0TGWhPI6B+AmtVF++Cp4a0drdpTQtDKR+40MHjolQQN6zN3iKdOmFPmljdVMrbb2XJaX8p9bu9tPzKWQWEPxQkQKiJoXQfJi0PQMj2xbw6LJqRgHZ5h9o7e445bgTQHptNbZBM4OBZJT9TQHJUATQ4bBGODMGzumc1u6GaalDQJRBgGHvGAZyUGluB+Wv1RUUU7PAREJ56+8AAU7q7G6Enk4hltpCajUe5gkIdK7UbqFMpzVhUm+Cij8VxjVj0EE67hhIrznvJ6UcDUsWTNhVtVs+sHD9PF5VqkoEvNuvsbvdGhcgRIQhzFI/GZYsG6CuLHG3gC3aYLZOZN74Rxq720467hAIqhMYCpjhy4Oe3mrwyqiwr5QbeToVejova+xuv2YCh5CHwapxNsybMainqApgykBOF28836c+eCVC292QxkkM8fT4LcBQhFnqB8Ic4mnGfl4FUMdtGqP7FdboiJDJqSYVYxEBifK8BLQJDuTsB3mNg77qzCBpdwMwVUIDQZ0CWjUdlqbIJVkFsp1gIQdkKw6BgObNtpN2t0PnFKmtzQre8BXCPN2AlikW77kQ803UvFw3OVqdtOOOgGDDpvqq2TBPNyCbCKtQp5aKKENs2Qcz2ke+266bwCHG4ozoFfivlGCZ7DysYpBRQ4EAMgHGNUlNt0HdNAwxLf0UC0iU11ioaoB5TjLfROOVViUuhfucNWi8GaY8g+Zm2KOHiurAcd9E+qegOicJTK9oAHKd6wtyx2+YOStvYQApEkCmAJA2YqgDWksQ4ilGtDpPMpvLBaJGg7hvIiB51RbnsNVNGIAk3APB6ifCiIZgIBE2EOQ9KGvgNLa6QcNfmnQPZIZpEnPMKcNFSbhTY1jFtWtdm0UFsokpIdNMpdqYhKhtjqOuFMRHByTRkA7pX2Qdos7BFOpyzh2QEY4f0ssEUmQyb8zKqEu+BHIUtwhXSpUFZFQ04piNL6ofkgYrnBlkdXuFKz8kxAECPXfguheYo5xkAwlD6Emkkjv062eupwrWWWFmsILr0SYXeS2jylwaWN2sceRnma3Nc4Ewl/8gdN7QahdEFjPA6s4bgUwzbWeaC2SKF+YBQZ6G4iEoTBtVdfesEcg8s8Z5LhBmCBFEKUeY62kYMUP/nVJ7nOB4NKwI8DRXqTKDzHsXN6Z6A83ChDr5g2brEeUN3xxXQgZdZ6zXNRB1H0Lqa0a1upYZSIq18EJ5mRQ3acLMhTWSl5lEY5FTplGB4V8M8Ub5OldCeKlMlC1tJHOXQuOYVmQ9xwAyxzOdCa6EoGR3ioOtodxuHOmWjMJoCwNInpdeH+VKCNoOsZnjCjeU/Y9B4xi1y3ovpx1xVp+CXAlBk2HefBRf4v0hQeb+EKyYUvYOxzlAEhyTKKNcCYEbmeOMzaZwB9EQT0sVselK2BBlWZJa5DibWcGVELjp7oANGtwdjPaY5XgWexbHWGYCJpUEN91FzX6qTAuuhMA6CjHzJsRGdiEO4T0WuS7Twg0C2czYM5njSwg8o3qFs5OZt09VY8bs+ivdadIOEIhtez3cVTvDl5B2Yx3E9SDMnczjklwE2u1Pph20+IG1z3z5/BntTuYrxp3CMsGXEHyVytbqA9+VBBDeXveIpOMm9rGcUrj5P1n659tRDZB6EYHbroN8CfHj7q5a+H13hASCBp91GkI7Xeu4Vdzhu3WnIWq33z5ENJYtIdS57rdL2HdRPBo4L5PQTtdabtWrFkpHYqgDRNVb/rqGCbZsCSEvU8m/PPDCtfvo9lr47FH9Zmmof05pp3ut4x6yuRsUkMq9hx1hii1fQvZKd8UihKv2zB3UP3mtx1DruHfbDRh9CHFVTAj6zN0hJxLS7R7ICByt6qnMb8P2zem9whp/edwePdWcynz4g7tOkqcyg04kxOceCL4bonJul9A/k+bpWvK2/RH7gmJRDzJTEuLqvHoJCMVy/x07vtl39B6idZY2dlTjuLcpIBf1qDslIWgzMxOIqwbmDGd9qo77iDLVXALZLBxJSKd7IMtcvDdpOh9XWfAkFWW8qNdlkBISGHYNxO9iPluG4FGlFyCA5A5INuZMQozXutFAXLw6x9VfVpfag0W8ckcjIdqZbADifLqlzGvtsnPZpk42O5AMyyAkhEMJ4VxWl5/AS9akQx5pxlq7PKxL1SyHHUiWYxBKB+ucSAjnxozNYQzE6T1mF7le4RZ1F9cNFUgnd8Y4khDOPVVxAojzm+6YXmGv6g7MqkB8EXOdvcKxhJh9s2lBAHF0WaYaHaCnXJwFhKFmy2PgSELMurGXBBJwokUKMa6Fy4CdoDMAyFJjnV8SLiTEdP9KWpBAiKsScFnJSfwuRNwVhXsdADF7QnHhQkJMlnelBoiDe9Cm+RXPAjc4AYAYDUJOuJIQvRZJo9ViRfq7IkwemTgvc1hy3NWM5CgCYjIIQeFKQvS3ma1E2i9mCssr5QAz81turU8VfgDEIKA54VJClK8k2CVdAVJjO3kBhPmYA9G01GhvVkAgnTyhdCohVDpKLlxQP6yagWrknnMBaSHKT5SVMhUjyrggIFrLe1C4lhBaFZyAeyvrMtFdZvcse8pBoqwk6cuUJQkEovkQQ83nQxxLiBCfw3/0HexS1qfmd5sUq+17QCbn/QZIGcUJIFTDpcycEg1ICPFNlO8R1sC2c8dAhORBOO+9qtdWFBQQ4ns79dd5uZAQ9KEneTlGWCH7hrjdOj2Sv52uNEl7U232SBsBhNDql/Sup1lCwHemVpHOvXJoQv3iV6Uc1n3abRw77kLUfzmmYNFAsFZ/2uCLMyRECH/dJai/P0PrPnXjTuA1PG0M35zbhx13u1zCr5hVFBn4vtblmGhcQoQQ/uV/Kvfj/TM664h23T+JPux2+DmDdetRy22KWrsktEAU+czca1ytBQW39D1/rufc84bjf/jE4c6T9TYw+5mzoqFSVmtXjQ8GdtUoo8yKxfz+Ik/1zVJWY+fCxzIz54+dbfz7oQ+skXL/Gc6TgaPlivf/y/qocYBV9oyuaXv6Bnasjy1W3fwvgX7jdM+dz64XN6F0Ytepdcs6HNtv3aJ6PqMtzcMvGzBazVjABY/RlgYCYtCxVuYB4ov5Ju/yT7WuDPNOxmYq4/MaIt3GXQ3NV0LVy/NVZxxlsTY1OZApKQuvE7+9QYe0mtvxyh7nhtEkcWFi03mifwShC+JjGc1udcNqjKykPz5B5qKbu1TDHfv/XV1tb1g+TOeim7vUhSS/v/qDnp6eng8neJtNm7I43ara7DpVuNkK28wl4GYrbDMXp0dEJj0gLRYMcbiJv+m9EKdfRT3Q9EC6vBnTCJDppufh8IuqLZCBcHRUtRBrfiCOzgGtbH4ejs5UzQsPSOvlMB0cN93aCjwYp04q69zWSGG2exq1vtzK5XGpNXhoLyUA25qbvzzOOwP0dKxVgAj/fxg8ropWKttNpyszx0VrlcD2+3Q4VrTilqENHxLpiMz7z4nWLL4frlH167YVj4oWLr6dd117ce27z0gpZfYPq4+92dI0Wr78D20zXEzc9fryAAAAAElFTkSuQmCC`);
        //Acesso à Informação
        this.base64Imagem2Default = this.domSanitizer.bypassSecurityTrustUrl(`data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20117%2049%22%20height%3D%2249%22%20width%3D%22117%22%20shape-rendering%3D%22geometricPrecision%22%20text-rendering%3D%22geometricPrecision%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%3C!%5BCDATA%5B.a%20%7Bfont%3A%20normal%20bold%2011px%20Open%20Sans%2C%20sans-serif%3B%7D%5D%5D%3E%3C%2Fstyle%3E%3C%2Fdefs%3E%3Ccircle%20cx%3D%2222%22%20cy%3D%2223%22%20r%3D%2222%22%20fill%3D%22%23222%22%2F%3E%3Cpath%20style%3D%22stroke%3A%23fff%3Bstroke-width%3A9%3Bstroke-linecap%3Around%3B%22%20d%3D%22m%2022%2C23%20v%2013%22%2F%3E%3Cpath%20style%3D%22stroke%3A%23222%3Bstroke-width%3A4%3Bstroke-linejoin%3Around%3B%22%20d%3D%22m%204%2C43%203%2C-6%204%2C3%20z%22%2F%3E%3Ccircle%20r%3D%224.5%22%20cy%3D%2211%22%20cx%3D%2222%22%20fill%3D%22%23fff%22%2F%3E%3Cg%20fill%3D%22%23222%22%3E%3Ctext%20x%3D%2247%22%20y%3D%2222%22%3E%3Ctspan%20class%3D%22a%22%20y%3D%2218%22%3EAcesso%20%C3%A0%3C%2Ftspan%3E%3Ctspan%20class%3D%22a%22%20x%3D%2247%22%20y%3D%2231%22%3EInforma%C3%A7%C3%A3o%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fsvg%3E`);
        //Logo Pátria Amada Brasil
        this.base64Imagem3Default = this.domSanitizer.bypassSecurityTrustUrl(`data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20viewBox%3D%220%200%20496.2%20143.8%22%3E%3Cstyle%3E.st0%7Bfill%3A%23575756%7D%3C%2Fstyle%3E%3Cpath%20d%3D%22M220.5%2054.5c14.5%200%2021.4%206%2021.4%2016%200%205.6-3.7%2010.4-9.2%2012.4%206.7%201.8%2012.5%207.9%2012.5%2015.5%200%209.8-7.1%2017.2-23.4%2017.2-8%200-14.4-.2-21.7-.3l-.6-.6V55.4l.6-.6c7.2-.1%2013.9-.3%2020.4-.3zm-10.7%2025.4h10.3c9.2%200%2011.3-4.9%2011.3-9.1%200-4.3-1.9-9.1-11.1-9.1-2.8%200-7.4%200-10.5-.1v18.3zm0%207.2v21.4c4.1%200%208.3-.1%2011.9-.1%2010.6%200%2012.8-6.1%2012.8-10.6%200-4.4-2.9-10.7-13.4-10.7h-11.3zM284.5%2088.7c3.2%201.1%205.6%204.1%207%207.5l4.3%2010.3c1%202.4%202.2%204.8%204.4%206.4-1.4%201.9-4.4%202.9-7.1%202.9-3.9%200-5.3-1.9-6.9-5.7l-4.9-11.9c-1.7-4.1-3.8-7.2-9.9-7.2h-8.1v24.3c-1.6.3-3.5.4-5.2.4-1.6%200-3.6-.1-5.1-.4V55.4l.6-.6c7.4-.1%2014.5-.3%2021.1-.3%2013.7%200%2022.3%206.4%2022.3%2018.1.1%208.1-5.3%2014.1-12.5%2016.1zm-21.1-5.3c3.8-.1%208.2-.2%2010.9-.2%209.6%200%2012-5.5%2012-10.6%200-5.4-2.4-10.7-12-10.7-2.9%200-7.6%200-10.9-.1v21.6zM320.8%20100.5l-5.2%2014.8c-1.3.3-2.9.4-4.5.4-1.9%200-3.7-.3-5.1-.6l-.3-.4L327.9%2055c1.6-.3%204.3-.4%206-.4%201.7%200%204.4.1%205.9.4l22%2059.7c-1.5.9-3.8%201.2-6.1%201.2-3.2%200-4.9-1.1-6.2-4.9l-3.6-10.3c-1.7%200-5.1.1-5.9.1h-13.5c-.8-.2-4-.3-5.7-.3zm2.6-7.6c1.6%200%204.2-.1%205-.1h9.8c.7%200%203.3.1%204.9.1l-4.5-12.8c-1.8-5.1-3.8-11.3-5.2-16h-.4c-1%204-2.8%209.5-3.8%2012.8l-5.8%2016zM371.1%20102.5c5.7%203.4%2013%206%2019.8%206%208%200%2012.5-3.4%2012.6-8.3%200-4.2-3.2-7.3-8.9-9.5L383%2086.2c-8.3-3.2-13.5-7.8-13.5-15.3%200-9.6%209-17.1%2022.2-17.1%208.2%200%2015.7%202.3%2020.8%204.6-.1%202.7-1.7%205.6-3.8%207.3-5.1-2.3-11.8-4.2-16.8-4.2-7.3%200-11.8%203.6-11.8%208.3%200%203.9%203.3%206.1%208.2%208l11.4%204.4c8.5%203.2%2014.7%208.6%2014.7%2016.4%200%2010.2-7.9%2017.8-24.1%2017.8-8.2%200-17-2.5-23.6-6.6.3-2.8%202.2-5.7%204.4-7.3zM426.6%2054.9c1.5-.3%203.6-.4%205.2-.4s3.6.1%205.2.4v60.3c-1.6.3-3.6.4-5.2.4s-3.7-.1-5.2-.4V54.9zM492.9%20107.1c0%201-.1%202.6-.3%203.7-.6%203-3%204.5-6.8%204.5h-25.7c-3.5%200-6.1-2-6.1-5.8V55l.7-.5h3.9c4.3%200%205.9%201.9%205.9%206v46.9c3-.3%206.1-.4%208.7-.4h19.7zM209.6%2034.6h-4.1v10.1c-.9.2-2.1.2-3%20.2-.8%200-2%200-3-.2V14.5l.3-.3c3.6-.1%206.5-.2%209.7-.2%206.1%200%2010.6%203.3%2010.6%2010.3%200%206.8-4.4%2010.3-10.5%2010.3zm-4.1-4.6c1.5%200%203.1-.1%203.7-.1%204%200%204.8-3.2%204.8-5.6%200-2.4-.8-5.6-4.8-5.6h-3.7V30zM227.2%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.7%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H227.2zm1.5-4.7H236.4l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM252.3%2022.5v-3.3H244.7c-.2-.9-.2-1.8-.2-2.5s0-1.6.2-2.5H266c.2.6.3%201.6.3%202.3%200%202-1%202.7-3.2%202.7H258.3v25.5c-1%20.2-2.1.2-3%20.2-.8%200-2%200-3-.2V22.5zM285.4%2031.6c1.6.6%202.7%202.1%203.3%203.9l1.6%204.5c.4%201.2%201.1%202.4%202.1%203.2-.8%201.1-2.4%201.8-4%201.8-2.2%200-2.9-1.2-3.8-3.5l-1.9-5.3c-.7-1.8-1.6-3.2-4.1-3.2H276v11.7c-1%20.2-2.1.2-3%20.2-.8%200-2%200-2.9-.2V14.5l.3-.3c3.6-.1%206.9-.2%2010.2-.2%206.2%200%2010.5%203.1%2010.5%209.4-.1%204.3-2.8%207.2-5.7%208.2zm-9.4-3.2c1.6-.1%203.2-.1%204.1-.1%203.9%200%204.8-2.4%204.8-4.8%200-2.5-.9-4.8-4.8-4.8H276v9.7zM297.3%2014.3c.9-.2%202.2-.2%203-.2.8%200%202%200%203%20.2v30.4c-1%20.2-2.1.2-3%20.2-.8%200-2.1%200-3-.2V14.3zM315.4%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.8%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1h-10.7zm1.5-4.7H324.6l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM353.1%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.7%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H353.1zm1.4-4.7H362.2l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM377.7%2014.3c1.3-.2%203-.3%204-.3%201.1%200%202.5.1%203.8.3l3.4%2012.3c.3%201.2%201.4%205.8%201.7%207.6h.3c.3-1.8%201.4-6.4%201.7-7.6l3.4-12.3c1.3-.2%202.8-.3%203.8-.3%201.1%200%202.7.1%204.1.3l2.4%2030.3c-.8.2-2%20.3-3%20.3-.9%200-1.8%200-2.6-.2l-.8-14.3c-.2-2.8-.4-6.9-.4-9.7h-.3L394%2040.1c-.9.1-2.2.2-3.1.2-.8%200-2.1-.1-3-.2l-5.2-19.4h-.3c0%202.8-.2%206.9-.4%209.7l-1%2014.3c-.8.1-1.7.2-2.7.2-.9%200-2.1-.1-3-.3l2.4-30.3zM417.4%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.7%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H417.4zm1.5-4.7H426.6l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM459.4%2042.7c-2%201.6-5.6%202.2-8%202.2-3.7%200-6.6-.1-10.5-.2l-.3-.3v-30l.3-.3c3.8-.1%206.8-.2%2010.5-.2%202.4%200%206%20.6%208%202.2%204.1%203.3%204.9%208%204.9%2013.2-.1%205.4-.8%2010.1-4.9%2013.4zm-8-23.9h-4.9v21.5h4.9c5.8%200%206.7-5.8%206.7-10.7%200-5-.9-10.8-6.7-10.8zM474%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.8%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H474zm1.5-4.7H483.2l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM238.2%203.9c.9.5%202.1%201.9%202.4%203.2l-7.4%204.4c-.7-.3-1.4-1.3-1.6-2l6.6-5.6z%22%2F%3E%3Cg%3E%3Cpath%20d%3D%22M206.9%20133.7h3.4c1.5%200%202.3.7%202.3%202.2v5.7c-1.9.6-3.8.9-5.9.9-1%200-2-.2-2.8-.5-.8-.3-1.5-.8-2-1.5-.5-.6-.9-1.4-1.2-2.4-.3-.9-.4-2-.4-3.2%200-1.3.2-2.5.6-3.4s.9-1.8%201.5-2.4c.6-.6%201.4-1.1%202.2-1.5.8-.3%201.7-.5%202.6-.5%201.9%200%203.6.5%205.3%201.6%200%20.2-.1.5-.2.7-.1.2-.2.5-.3.7-.1.2-.3.4-.5.6-.2.2-.4.3-.6.5-1.2-.8-2.4-1.2-3.6-1.2-2.4%200-3.5%201.6-3.5%204.9%200%203.3%201.2%204.9%203.6%204.9h1c.3%200%20.6-.1.9-.1v-1.4-.9-.6h-1.1c-.6%200-1-.1-1.3-.4-.2-.2-.4-.6-.4-1.1.1-.6.2-1.1.4-1.6zM224.2%20141.1c-1.5-1.3-2.3-3.4-2.3-6.3%200-1.3.1-2.4.4-3.3.3-1%20.7-1.8%201.3-2.4.6-.6%201.2-1.1%202-1.5.8-.3%201.7-.5%202.7-.5%201%200%201.9.2%202.7.5.8.3%201.5.8%202%201.5.6.7%201%201.5%201.3%202.4.3%201%20.4%202.1.4%203.3%200%201.3-.1%202.4-.4%203.3-.3%201-.7%201.8-1.3%202.4-.6.6-1.2%201.1-2%201.5-.8.3-1.7.5-2.7.5-1.7-.1-3-.5-4.1-1.4zm1.7-3c.4%201.1%201.2%201.7%202.4%201.7.6%200%201.1-.1%201.4-.4.4-.3.7-.7.9-1.1.2-.5.3-1%20.4-1.5.1-.6.1-1.1.1-1.7%200-.5%200-1.1-.1-1.7%200-.6-.1-1.2-.3-1.7-.2-.5-.4-1-.8-1.4-.4-.4-.9-.6-1.6-.6-.7%200-1.2.2-1.6.5-.4.4-.6.8-.8%201.3-.2.5-.3%201.1-.3%201.7%200%20.6-.1%201.1-.1%201.5%200%20.7%200%201.3.1%201.8%200%20.5.1%201%20.3%201.6zM249.6%20139.2l2.8-11.9c.3-.1.8-.1%201.3-.1.8%200%201.3.1%201.8.2l.1.2-4%2014.5c-.8.1-1.6.1-2.5.1-.8%200-1.4-.1-1.8-.3-.4-.2-.6-.6-.8-1.2l-3.6-13.1c.8-.3%201.4-.5%201.9-.5.6%200%201.1.1%201.3.4.3.3.5.7.7%201.3l1.7%206.2c.3%201%20.5%202.3.8%203.9.1.2.1.3.3.3zM268.3%20137.7v1.6h6.6c0%20.5%200%20.9-.1%201.2-.2%201.1-.9%201.7-2.2%201.7h-5.8c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.7l.2-.2h9.3c.1.4.1.9.1%201.4s-.1%201-.3%201.5h-5.9v3.1h4.8c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4h-4.8v1.6zM295.3%20131.9c0%20.5-.1.9-.2%201.4-.1.4-.3.8-.6%201.1-.2.3-.5.6-.8.9-.3.3-.7.4-1%20.6.8.3%201.3.9%201.7%202l.6%201.8c.2.7.6%201.3%201.1%201.6-.2.3-.5.5-1%20.7-.4.2-.9.3-1.4.3-.5%200-.9-.1-1.2-.4-.3-.3-.6-.8-.8-1.5l-.8-2.3c-.2-.4-.4-.8-.6-1-.3-.2-.7-.3-1.2-.3h-.9v5.4c-.5.1-1%20.1-1.7.1s-1.3%200-1.7-.1v-14.7l.2-.2c1.3%200%202.3%200%203.2-.1h2c.8%200%201.5.1%202.2.3.6.2%201.2.5%201.7.9s.8.9%201.1%201.5c0%20.5.1%201.2.1%202zm-7.1-2.1v4.3h1.7c.5%200%20.8-.1%201.1-.3.3-.2.5-.4.6-.6.1-.3.2-.7.2-1.2%200-1.4-.7-2.1-2-2.1h-.9c-.3-.1-.5-.1-.7-.1zM317.1%20127.2l.2.2V142c-.6.1-1.3.2-2%20.2s-1.5%200-2.1-.1l-3.4-7.7c-.4-.9-.8-1.9-1.2-3.1h-.1c.2%202.1.3%204.3.3%206.5v4.3c-.4.1-1%20.1-1.6.1-.6%200-1.2%200-1.6-.1v-14.7c.5-.1%201.2-.2%202-.2s1.5%200%202.1.1l3.4%207.7c.6%201.4%201.1%202.5%201.3%203.3h.1c-.2-2-.3-4.1-.3-6.4v-2.6c0-.8.2-1.3.5-1.6.3-.3.8-.5%201.5-.5h.9zM329.4%20141.1c-1.5-1.3-2.3-3.4-2.3-6.3%200-1.3.1-2.4.4-3.3.3-1%20.7-1.8%201.3-2.4.6-.6%201.2-1.1%202-1.5.8-.3%201.7-.5%202.7-.5%201%200%201.9.2%202.7.5.8.3%201.5.8%202%201.5.6.7%201%201.5%201.3%202.4.3%201%20.4%202.1.4%203.3%200%201.3-.1%202.4-.4%203.3-.3%201-.7%201.8-1.3%202.4-.6.6-1.2%201.1-2%201.5-.8.3-1.7.5-2.7.5-1.6-.1-3-.5-4.1-1.4zm1.7-3c.4%201.1%201.2%201.7%202.4%201.7.6%200%201.1-.1%201.4-.4.4-.3.7-.7.9-1.1.2-.5.3-1%20.4-1.5.1-.6.1-1.1.1-1.7%200-.5%200-1.1-.1-1.7%200-.6-.1-1.2-.3-1.7-.2-.5-.4-1-.8-1.4-.4-.4-.9-.6-1.6-.6-.7%200-1.2.2-1.6.5-.4.4-.6.8-.8%201.3-.2.5-.3%201.1-.3%201.7%200%20.6-.1%201.1-.1%201.5%200%20.7%200%201.3.1%201.8s.2%201%20.3%201.6zM365.4%20130.3V133.4h4.7c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4h-4.7v6c-.5.1-1%20.1-1.7.1s-1.3%200-1.7-.1v-14.7l.2-.1h9.3c.1.4.1.8.1%201.4s-.1.9-.4%201.2c-.3.3-.8.4-1.4.4h-4.4zM384.4%20137.7v1.6h6.6c0%20.5%200%20.9-.1%201.2-.2%201.1-.9%201.7-2.2%201.7H383c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.7l.2-.2h9.3c.1.4.1.9.1%201.4s-.1%201-.3%201.5h-5.9v3.1h4.8c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4h-4.8v1.6zM410.4%20141.2c-.5.4-1.1.6-1.8.8-.8.2-1.6.3-2.5.3h-1.9c-.8%200-1.9%200-3.2-.1l-.2-.2v-14.6l.2-.2c.8%200%201.7%200%202.6-.1h2.8c1.2%200%202.3.2%203.1.6.8.4%201.5.9%202%201.6s.8%201.5%201%202.4c.2.9.3%201.9.3%203%200%201.4-.2%202.7-.5%203.7-.3%201.1-1%202-1.9%202.8zm-4-1.7c1.9%200%202.9-1.6%202.9-4.8%200-3.2-1-4.8-2.9-4.8h-2.1v9.7h.9c.3-.1.7-.1%201.2-.1zM426.1%20137.7v1.6h6.6c0%20.5%200%20.9-.1%201.2-.2%201.1-.9%201.7-2.2%201.7h-5.8c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.7l.2-.2h9.3c.1.4.1.9.1%201.4s-.1%201-.3%201.5H426v3.1h4.8c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4H426v1.6zM453.1%20131.9c0%20.5-.1.9-.2%201.4s-.3.8-.6%201.1c-.2.3-.5.6-.8.9-.3.3-.7.4-1%20.6.8.3%201.3.9%201.7%202l.6%201.8c.2.7.6%201.3%201.1%201.6-.2.3-.5.5-1%20.7-.4.2-.9.3-1.4.3-.5%200-.9-.1-1.2-.4-.3-.3-.6-.8-.8-1.5l-.8-2.3c-.2-.4-.4-.8-.6-1-.3-.2-.7-.3-1.2-.3h-.9v5.4c-.5.1-1%20.1-1.7.1s-1.3%200-1.7-.1v-14.7l.2-.2c1.3%200%202.3%200%203.2-.1h2c.8%200%201.5.1%202.2.3.6.2%201.2.5%201.7.9s.8.9%201.1%201.5c0%20.5.1%201.2.1%202zm-7.2-2.1v4.3h1.7c.5%200%20.8-.1%201.1-.3.3-.2.5-.4.6-.6.1-.3.2-.7.2-1.2%200-1.4-.7-2.1-2-2.1h-.9c-.2-.1-.5-.1-.7-.1zM466.8%20139h-.9l-.9%203.1c-.3.1-.8.1-1.4.1-.7%200-1.3-.1-1.7-.2l-.1-.2%204.8-14.5c.6-.1%201.2-.1%202-.1.9%200%201.5.1%202%20.2l4.7%2014.5c-.5.3-1.1.4-1.7.4-.8%200-1.3-.1-1.6-.4-.3-.3-.6-.8-.8-1.5l-.4-1.4h-4zm0-2.7h3.3l-.4-1.3c-.3-1.2-.7-2.7-1.2-4.5h-.1c-.1.6-.5%202-1%204.1l-.6%201.7zM489.9%20139.2h3.8c0%20.6%200%201.1-.1%201.5-.1.4-.3.8-.7%201.1-.4.3-.9.4-1.5.4h-4.9c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.8l.2-.2h1.3c1.3%200%202%20.7%202%202.2v9.9c.5-.1%201.2-.1%201.9-.1z%22%2F%3E%3C%2Fg%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M.7%2014v69.8l72.1-58.2%20109.1%2048.1V14z%22%2F%3E%3Cpath%20d%3D%22M.7%2083.8v49.4s5.8-5%2016.5-12.2C22.4%2089.1%2050%2064.8%2083.3%2064.8c15.1%200%2029%205%2040.2%2013.4%2017.9-3.3%2037.4-5.1%2058.3-4.5l-109-48.1L.7%2083.8z%22%20fill%3D%22%23c6c6c6%22%2F%3E%3Cpath%20d%3D%22M83.3%2064.8c-33.3%200-60.9%2024.3-66%2056.2%2019.9-13.2%2057-33.7%20106.3-42.8-11.2-8.4-25.2-13.4-40.3-13.4z%22%2F%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M140.2%2096.5C79.3%20100%2037.4%20119.4%2016.4%20131.8%206%20137.9.7%20142.3.7%20142.3h181.1V96.6c-14.7-.9-28.5-.9-41.6-.1z%22%2F%3E%3C%2Fsvg%3E`);
    }
    ngOnInit() {
        this.grupos = Object.keys(this.gruposLinks);
    }
}
FooterComponent.ɵfac = function FooterComponent_Factory(t) { return new (t || FooterComponent)(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"])(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"])); };
FooterComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: FooterComponent, selectors: [["br-footer"]], inputs: { invertido: "invertido", horizontal: "horizontal", urlImagem: "urlImagem", alt: "alt", urlImagem2: "urlImagem2", url2: "url2", alt2: "alt2", urlImagem3: "urlImagem3", url3: "url3", alt3: "alt3", gruposLinks: "gruposLinks", linksRedesSociais: "linksRedesSociais", exibeInformacaoLicenca: "exibeInformacaoLicenca", informacaoLicenca: "informacaoLicenca" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 21, vars: 20, consts: [["id", "footer"], [1, "container-fluid"], [1, "logo"], [3, "src", "alt"], ["data-toggle", "data-toggle", "data-unique", "data-unique", 3, "ngClass"], [4, "ngFor", "ngForOf"], [1, "d-none", "d-sm-block"], [1, "row", "align-items-end", "justify-content-between", "py-5"], ["class", "col social-network", 4, "ngIf"], ["id", "footer-brasil", 1, "col", "assigns", "text-right", 3, "ngStyle"], ["target", "_blank", 3, "href", "title"], [1, "ml-4", 3, "alt", "src"], ["ngClass", "br-divider my-3"], [1, "info"], [1, "text-down-01", "text-medium", "pb-3", "text-center"], [3, "horizontal", "grupo", "links"], [1, "col", "social-network"], [1, "text-up-01", "text-extra-bold", "text-uppercase"], ["target", "_blank", 1, "mr-3", 3, "href"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], [4, "ngIf"], ["aria-hidden", "true"]], template: function FooterComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "footer", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "div", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(3, "img", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "div", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(5, FooterComponent_ng_container_5_Template, 2, 3, "ng-container", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(6, "div", 6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(7, "div", 7);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(8, FooterComponent_div_8_Template, 4, 1, "div", 8);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(9, "div", 9);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(10, "a", 10);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(11, "img", 11);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(12, "a", 10);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(13, "img", 11);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(14, "br-divider", 12);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(15, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(16, "div", 13);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(17, "div", 14);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(18);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(19, "strong");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(20);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])("br-footer " + (ctx.invertido ? "inverted" : ""));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("src", ctx.urlImagem || ctx.base64Imagem1Default, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("alt", ctx.alt);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx.jc(ctx.ngClass, "br-list ", ctx.horizontal ? " horizontal " : ""));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx.grupos);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", (ctx.linksRedesSociais == null ? null : ctx.linksRedesSociais.length) > 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngStyle", ctx.invertido ? Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"])(18, _c0$2) : Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"])(19, _c1));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("href", ctx.url2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("title", ctx.alt2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("alt", ctx.alt2)("src", ctx.urlImagem2 || ctx.base64Imagem2Default, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("href", ctx.url3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("title", ctx.alt3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("alt", ctx.alt3)("src", ctx.urlImagem3 || ctx.base64Imagem3Default, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"])(" ", ctx.informacaoLicenca.label, " ");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx.informacaoLicenca.nomeLicenca);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgStyle"], DividerComponent, GrupoFooterComponent], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(FooterComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-footer',
                templateUrl: './footer.component.html',
            }]
    }], function () { return [{ type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"] }]; }, { invertido: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], horizontal: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], urlImagem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], alt: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], urlImagem2: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], url2: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], alt2: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], urlImagem3: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], url3: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], alt3: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], gruposLinks: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], linksRedesSociais: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], exibeInformacaoLicenca: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], informacaoLicenca: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class FooterModule {
}
FooterModule.ɵfac = function FooterModule_Factory(t) { return new (t || FooterModule)(); };
FooterModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: FooterModule });
FooterModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], DividerModule, ItemModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(FooterModule, { declarations: [FooterComponent, GrupoFooterComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], DividerModule, ItemModule], exports: [FooterComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(FooterModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [FooterComponent, GrupoFooterComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], DividerModule, ItemModule],
                exports: [FooterComponent],
            }]
    }], null, null); })();

class TipoSignin {
}
TipoSignin.ENTRAR = 'entrar';
TipoSignin.ENTRAR_GOVBR_MONO = 'entrargovbr_mono';
TipoSignin.ENTRAR_GOVBR_COR = 'entrargovbr_cor';

function SigninComponent_br_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-button", 1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function SigninComponent_br_button_0_Template_br_button_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r4); const ctx_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return ctx_r3.onClickBotao($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "i", 2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(2, "Entrar");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r0.jc(ctx_r0.ngClass, "sign-in", ctx_r0.densidade == ctx_r0.DENSIDADE_MEDIA ? "" : ctx_r0.densidade));
} }
function SigninComponent_br_button_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-button", 1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function SigninComponent_br_button_1_Template_br_button_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r6); const ctx_r5 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return ctx_r5.onClickBotao($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(1, "Entrar com\u00A0");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "span", 3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(3, "gov.br");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r1.jc(ctx_r1.ngClass, "sign-in ", ctx_r1.densidade == ctx_r1.DENSIDADE_MEDIA ? "" : ctx_r1.densidade));
} }
function SigninComponent_br_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-button", 1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function SigninComponent_br_button_2_Template_br_button_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r8); const ctx_r7 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return ctx_r7.onClickBotao($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(1, "Entrar com\u00A0");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "img", 4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r2.jc(ctx_r2.ngClass, "sign-in", ctx_r2.densidade == ctx_r2.DENSIDADE_MEDIA ? "" : ctx_r2.densidade));
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("src", ctx_r2.base64LogoDefault, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
} }
class SigninComponent extends BaseComponent {
    constructor(domSanitizer) {
        super();
        this.domSanitizer = domSanitizer;
        //constantes usadas no template
        this.ENTRAR = TipoSignin.ENTRAR;
        this.ENTRAR_GOVBR_MONO = TipoSignin.ENTRAR_GOVBR_MONO;
        this.ENTRAR_GOVBR_COR = TipoSignin.ENTRAR_GOVBR_COR;
        this.DENSIDADE_MEDIA = Densidade.MEDIA;
        //Evento de click
        this.click = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // tipo de exibição do componente signin
        this.tipoSignin = TipoSignin.ENTRAR_GOVBR_COR;
        // Densidade dos itens de menu. Default: densidade alta (small)
        this.densidade = Densidade.ALTA;
        //logo gov.br
        this.base64LogoDefault = this.domSanitizer.bypassSecurityTrustUrl(base64LogoGovBr);
    }
    onClickBotao(event) {
        this.click.emit(event);
    }
}
SigninComponent.ɵfac = function SigninComponent_Factory(t) { return new (t || SigninComponent)(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"])(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"])); };
SigninComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: SigninComponent, selectors: [["br-signin"]], inputs: { tipoSignin: "tipoSignin", densidade: "densidade" }, outputs: { click: "click" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 3, consts: [[3, "ngClass", "click", 4, "ngIf"], [3, "ngClass", "click"], ["aria-hidden", "true", 1, "fas", "fa-user"], [1, "text-black"], ["alt", "gov.br", 3, "src"]], template: function SigninComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(0, SigninComponent_br_button_0_Template, 3, 1, "br-button", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, SigninComponent_br_button_1_Template, 4, 1, "br-button", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, SigninComponent_br_button_2_Template, 3, 2, "br-button", 0);
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.tipoSignin == ctx.ENTRAR);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.tipoSignin == ctx.ENTRAR_GOVBR_MONO);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.tipoSignin == ctx.ENTRAR_GOVBR_COR);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], ButtonComponent, _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"]], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(SigninComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-signin',
                templateUrl: './signin.component.html',
            }]
    }], function () { return [{ type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"] }]; }, { click: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], tipoSignin: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], densidade: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class SigninModule {
}
SigninModule.ɵfac = function SigninModule_Factory(t) { return new (t || SigninModule)(); };
SigninModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: SigninModule });
SigninModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], ButtonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(SigninModule, { declarations: [SigninComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], ButtonModule], exports: [SigninComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(SigninModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [SigninComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], ButtonModule],
                exports: [SigninComponent],
            }]
    }], null, null); })();

function HeaderLinksComponent_ng_container_7_i_2_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "i", 10);
} if (rf & 2) {
    const link_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(link_r1.classIconeFontAwesome);
} }
function HeaderLinksComponent_ng_container_7_span_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span", 11);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const link_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(link_r1.texto);
} }
function HeaderLinksComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "a", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, HeaderLinksComponent_ng_container_7_i_2_Template, 1, 2, "i", 8);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, HeaderLinksComponent_ng_container_7_span_3_Template, 2, 1, "span", 9);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const link_r1 = ctx.$implicit;
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("routerLink", link_r1.tipo == ctx_r0.TIPOLINK_ROTA ? link_r1.url : null)("href", link_r1.tipo == ctx_r0.TIPOLINK_URL ? link_r1.url : null, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("target", link_r1.tipo == ctx_r0.TIPOLINK_URL && link_r1.novaAba ? "_blank" : null);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", link_r1.classIconeFontAwesome);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", link_r1.texto);
} }
class HeaderLinksComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.TIPOLINK_ROTA = TipoLink.ROTA;
        this.TIPOLINK_URL = TipoLink.URL;
        this.links = [];
    }
}
HeaderLinksComponent.ɵfac = function HeaderLinksComponent_Factory(t) { return new (t || HeaderLinksComponent)(); };
HeaderLinksComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderLinksComponent, selectors: [["br-header-links"]], inputs: { links: "links" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 8, vars: 1, consts: [[1, "header-links", "dropdown"], ["type", "button", "data-toggle", "dropdown", "aria-label", "Abrir Acesso R\u00E1pido", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-ellipsis-v"], [1, "br-list"], [1, "header"], [1, "title"], [4, "ngFor", "ngForOf"], [1, "br-item", 3, "routerLink", "href", "target"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], ["class", "text", 4, "ngIf"], ["aria-hidden", "true"], [1, "text"]], template: function HeaderLinksComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "button", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "i", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "div", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "div", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "div", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(6, "Acesso R\u00E1pido");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(7, HeaderLinksComponent_ng_container_7_Template, 4, 5, "ng-container", 6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(7);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx.links);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"]], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderLinksComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header-links',
                templateUrl: './header-links.component.html',
            }]
    }], function () { return []; }, { links: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

function HeaderFunctionsComponent_ng_container_7_i_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "i", 11);
} if (rf & 2) {
    const funcionalidade_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(funcionalidade_r1.classIconeFontAwesome);
} }
function HeaderFunctionsComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    const _r5 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "div", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "button", 8);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function HeaderFunctionsComponent_ng_container_7_Template_button_click_2_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r5); const funcionalidade_r1 = ctx.$implicit; const ctx_r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return funcionalidade_r1.funcao ? funcionalidade_r1.funcao($event) : ctx_r4._; });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, HeaderFunctionsComponent_ng_container_7_i_3_Template, 1, 2, "i", 9);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "span", 10);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const funcionalidade_r1 = ctx.$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("aria-label", funcionalidade_r1.texto);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", funcionalidade_r1.classIconeFontAwesome);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(funcionalidade_r1.texto);
} }
class HeaderFunctionsComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.TIPOLINK_ROTA = TipoLink.ROTA;
        this.TIPOLINK_URL = TipoLink.URL;
        this.funcionalidades = [];
    }
}
HeaderFunctionsComponent.ɵfac = function HeaderFunctionsComponent_Factory(t) { return new (t || HeaderFunctionsComponent)(); };
HeaderFunctionsComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderFunctionsComponent, selectors: [["br-header-functions"]], inputs: { funcionalidades: "funcionalidades" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 8, vars: 1, consts: [[1, "header-functions", "dropdown"], ["type", "button", "data-toggle", "dropdown", "aria-label", "Abrir Funcionalidades do Sistema", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-th"], [1, "br-list"], [1, "header"], [1, "title"], [4, "ngFor", "ngForOf"], [1, "align-items-center", "br-item"], ["type", "button", 1, "br-button", "circle", "small", 3, "aria-label", "click"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], [1, "text"], ["aria-hidden", "true"]], template: function HeaderFunctionsComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "button", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "i", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "div", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "div", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "div", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(6, "Funcionalidades do Sistema");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(7, HeaderFunctionsComponent_ng_container_7_Template, 6, 3, "ng-container", 6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(7);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx.funcionalidades);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"]], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderFunctionsComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header-functions',
                templateUrl: './header-functions.component.html',
            }]
    }], function () { return []; }, { funcionalidades: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class HeaderSearchTriggerComponent extends BaseComponent {
    constructor() {
        super();
    }
    ngOnInit() { }
}
HeaderSearchTriggerComponent.ɵfac = function HeaderSearchTriggerComponent_Factory(t) { return new (t || HeaderSearchTriggerComponent)(); };
HeaderSearchTriggerComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderSearchTriggerComponent, selectors: [["br-header-search-trigger"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 0, consts: [[1, "header-search-trigger"], ["type", "button", "aria-label", "Abrir Busca", "data-toggle", "search", "data-target", ".header-search", 1, "br-button", "circle"], ["aria-hidden", "true", 1, "fas", "fa-search"]], template: function HeaderSearchTriggerComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "button", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "i", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } }, encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderSearchTriggerComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header-search-trigger',
                templateUrl: './header-search-trigger.component.html',
            }]
    }], function () { return []; }, null); })();

function HeaderLoginComponent_img_7_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "img", 19);
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("src", ctx_r0.usuario == null ? null : ctx_r0.usuario.imgAvatar, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
} }
function HeaderLoginComponent_div_24_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 20);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "nav", 21);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "ul");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "li", 22);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "button", 23);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "span", 24);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(6, "span", 25);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(7, "i", 26);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(8, "span", 24);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(9, "Item");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(10, "li", 27);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(11, "button", 28);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(12, "span", 24);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(13, "span", 25);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(14, "i", 26);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(15, "span", 24);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(16, "Item");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(17, "div", 29);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(18, "div", 30);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(19, "div", 31);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(20, "button", 32);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(21, "i", 33);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(22, "Link de Acesso");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(23, "span", 34);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(24, "button", 32);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(25, "i", 33);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(26, "Link de Acesso");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(27, "span", 34);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(28, "button", 32);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(29, "i", 33);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(30, "Link de Acesso ");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(31, "div", 35);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(32, "div", 31);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(33, "button", 32);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(34, "span", 36);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(35, "span", 13);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(36, "T\u00EDtulo");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(37, "span", 37);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(38, "25 de out");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(39, "span");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(40, "Nostrud consequat culpa ex mollit aute. Ex ex veniam ea labore laboris duis duis elit. Ex aute dolor enim aute Lorem dolor. Duis labore ad anim culpa. Non aliqua excepteur sunt eiusmod ex consectetur ex esse laborum velit ut aute.");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(41, "span", 34);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(42, "button", 32);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(43, "span", 13);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(44, "T\u00EDtulo");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(45, "span", 37);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(46, "24 de out");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(47, "span");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(48, "Labore nulla elit laborum nulla duis. Deserunt ad nulla commodo occaecat nulla proident ea proident aliquip dolore sunt nulla. Do sit eu consectetur quis culpa. Eiusmod minim irure sint nulla incididunt occaecat ipsum mollit in ut. Minim adipisicing veniam adipisicing velit nostrud duis consectetur aute nulla deserunt culpa aliquip.");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(49, "span", 34);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(50, "button", 32);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(51, "span", 36);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(52, "span", 13);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(53, "T\u00EDtulo");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(54, "span", 37);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(55, "03 de out");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(56, "span");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(57, "Duis qui dolor dolor qui sint consectetur. Ipsum eu dolore ex anim reprehenderit laborum commodo. Labore do ut nulla eiusmod consectetur.");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(58, "span", 34);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(59, "button", 32);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(60, "span", 13);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(61, "T\u00EDtulo");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(62, "span", 37);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(63, "16 de mai");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(64, "span");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(65, "Sunt velit dolor enim mollit incididunt irure est. Ad ea Lorem culpa quis occaecat sunt in exercitation nisi. Sit laborum laborum dolor culpa ipsum velit. Non nulla nisi dolore et anim consequat officia deserunt amet qui. Incididunt exercitation irure labore ut Lorem culpa. Dolore ea irure pariatur ullamco culpa veniam amet dolor in fugiat pariatur ut. Sit non ut enim et incididunt tempor irure pariatur ex proident labore cillum dolore nisi.");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} }
class HeaderLoginComponent extends BaseComponent {
    constructor() {
        super();
        //Evento de click no botão signin
        this.clickEntrar = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Evento de click no botão sair
        this.clickSair = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    onClickEntrar(event) {
        this.clickEntrar.emit(event);
    }
    onClickSair(event) {
        this.clickSair.emit(event);
    }
}
HeaderLoginComponent.ɵfac = function HeaderLoginComponent_Factory(t) { return new (t || HeaderLoginComponent)(); };
HeaderLoginComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderLoginComponent, selectors: [["br-header-login"]], inputs: { usuario: "usuario" }, outputs: { clickEntrar: "clickEntrar", clickSair: "clickSair" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 25, vars: 7, consts: [[1, "header-login"], [3, "ngClass"], ["tipoSignin", "entrar", 3, "click"], [1, "avatar", "dropdown"], [1, "br-avatar", 3, "title"], [1, "image"], ["alt", "Avatar", 3, "src", 4, "ngIf"], ["type", "button", "aria-label", "Abrir Menu de usu\u00E1rio", "data-toggle", "dropdown", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-angle-down"], [1, "br-notification"], [1, "notification-header"], [1, "row"], [1, "col-10"], [1, "text-bold"], [1, "notification-body"], ["ngClass", "br-divider"], ["id", "divBotaoSair", 1, "col-10"], ["ngClass", "secondary small", 3, "click"], ["class", "br-tab", 4, "ngIf"], ["alt", "Avatar", 3, "src"], [1, "br-tab"], [1, "tab-nav"], [1, "tab-item"], ["type", "button", "data-panel", "notif-item783", "aria-label", "notif-item783"], [1, "name"], [1, "icon"], ["aria-hidden", "true", 1, "fas", "fa-image"], [1, "tab-item", "is-active"], ["type", "button", "data-panel", "notif-item784", "aria-label", "notif-item784"], [1, "tab-content"], ["id", "notif-item783", 1, "tab-panel"], [1, "br-list"], ["type", "button", 1, "br-item"], ["aria-hidden", "true", 1, "fas", "fa-heartbeat"], [1, "br-divider"], ["id", "notif-item784", 1, "tab-panel", "is-active"], [1, "br-tag", "status", "small", "warning"], [1, "text-medium", "mb-2"]], template: function HeaderLoginComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "br-signin", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function HeaderLoginComponent_Template_br_signin_click_2_listener($event) { return ctx.onClickEntrar($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "div", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "span", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(6, "span", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(7, HeaderLoginComponent_img_7_Template, 1, 1, "img", 6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(8, "button", 7);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(9, "i", 8);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(10, "div", 9);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(11, "div", 10);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(12, "div", 11);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(13, "div", 12);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(14, "span", 13);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(15);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(16, "br");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(17, "small");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(18);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(19, "div", 14);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(20, "br-divider", 15);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(21, "div", 16);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(22, "br-button", 17);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function HeaderLoginComponent_Template_br_button_click_22_listener($event) { return ctx.onClickSair($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(23, "Sair");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(24, HeaderLoginComponent_div_24_Template, 66, 0, "div", 18);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", "header-sign-in " + (ctx.usuario == null ? "" : "d-none"));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", "header-avatar " + (ctx.usuario != null ? "" : "d-none"));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("title", (ctx.usuario == null ? null : ctx.usuario.nomeCompleto) || (ctx.usuario == null ? null : ctx.usuario.upn));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.usuario == null ? null : ctx.usuario.imgAvatar);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(8);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])((ctx.usuario == null ? null : ctx.usuario.nomeCompleto) || (ctx.usuario == null ? null : ctx.usuario.upn));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])((ctx.usuario == null ? null : ctx.usuario.email) || (ctx.usuario == null ? null : ctx.usuario.upn));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", false);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], SigninComponent, _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], DividerComponent, ButtonComponent], styles: ["#divBotaoSair[_ngcontent-%COMP%] {\n        margin-top: 10px;\n        margin-bottom: 10px;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderLoginComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header-login',
                templateUrl: './header-login.component.html',
                styles: [
                    `
      #divBotaoSair {
        margin-top: 10px;
        margin-bottom: 10px;
      }
    `,
                ],
            }]
    }], function () { return []; }, { usuario: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clickEntrar: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], clickSair: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();

class HeaderActionsComponent extends BaseComponent {
    constructor() {
        super();
        this.links = [];
        this.funcionalidades = [];
        //Evento de click do botão entrar (login)
        this.clickEntrar = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Evento de click no botão sair
        this.clickSair = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    onClickEntrar(event) {
        this.clickEntrar.emit(event);
    }
    onClickSair(event) {
        this.clickSair.emit(event);
    }
}
HeaderActionsComponent.ɵfac = function HeaderActionsComponent_Factory(t) { return new (t || HeaderActionsComponent)(); };
HeaderActionsComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderActionsComponent, selectors: [["br-header-actions"]], inputs: { links: "links", funcionalidades: "funcionalidades", usuario: "usuario" }, outputs: { clickEntrar: "clickEntrar", clickSair: "clickSair" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 5, vars: 3, consts: [["ngClass", "header-links dropdown", 3, "links"], ["ngClass", "br-divider vertical"], ["ngClass", "header-functions dropdown", 3, "funcionalidades"], ["ngClass", "header-search-trigger"], ["ngClass", "header-login", 3, "usuario", "clickEntrar", "clickSair"]], template: function HeaderActionsComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "br-header-links", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "br-divider", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "br-header-functions", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(3, "br-header-search-trigger", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "br-header-login", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("clickEntrar", function HeaderActionsComponent_Template_br_header_login_clickEntrar_4_listener($event) { return ctx.onClickEntrar($event); })("clickSair", function HeaderActionsComponent_Template_br_header_login_clickSair_4_listener($event) { return ctx.onClickSair($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("links", ctx.links);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("funcionalidades", ctx.funcionalidades);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("usuario", ctx.usuario);
    } }, directives: [HeaderLinksComponent, _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], DividerComponent, HeaderFunctionsComponent, HeaderSearchTriggerComponent, HeaderLoginComponent], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderActionsComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header-actions',
                templateUrl: './header-actions.component.html',
            }]
    }], function () { return []; }, { links: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], funcionalidades: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], usuario: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clickEntrar: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], clickSair: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();

class HeaderBottomComponent extends BaseComponent {
    constructor() {
        super();
        // texto do Título
        this.titulo = 'Título';
        // texto do Subtítulo
        this.subtitulo = 'Subtítulo';
        //texto do label do campo de pesquisa
        this.labelPesquisa = 'Texto da pesquisa';
        // Evento do clique para abrir o menu
        this.clickMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    onClickMenu(event) {
        this.clickMenu.emit(event);
    }
}
HeaderBottomComponent.ɵfac = function HeaderBottomComponent_Factory(t) { return new (t || HeaderBottomComponent)(); };
HeaderBottomComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderBottomComponent, selectors: [["br-header-bottom"]], inputs: { titulo: "titulo", subtitulo: "subtitulo", labelPesquisa: "labelPesquisa" }, outputs: { clickMenu: "clickMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 18, vars: 3, consts: [[1, "header-menu"], [1, "header-menu-trigger"], ["type", "button", "aria-label", "Menu", "data-toggle", "menu", "data-target", "#main-navigation", "id", "navigation", 1, "br-button", "small", "circle", 3, "click"], ["aria-hidden", "true", 1, "fas", "fa-bars"], [1, "header-info"], [1, "header-title"], [1, "header-subtitle"], [1, "header-search"], [1, "br-input", "has-icon"], ["for", "searchbox-56953"], ["id", "searchbox-56953", "type", "text", "placeholder", "O que voc\u00EA procura?", 1, "has-icon"], ["type", "button", "aria-label", "Pesquisar", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-search"], ["type", "button", "aria-label", "Fechar Busca", "data-dismiss", "search", 1, "br-button", "circle", "search-close", "ml-1"], ["aria-hidden", "true", 1, "fas", "fa-times"]], template: function HeaderBottomComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "button", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function HeaderBottomComponent_Template_button_click_2_listener($event) { return ctx.onClickMenu($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(3, "i", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "div", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "div", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(7, "div", 6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(8);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(9, "div", 7);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(10, "div", 8);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(11, "label", 9);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(12);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(13, "input", 10);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(14, "button", 11);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(15, "i", 12);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(16, "button", 13);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(17, "i", 14);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(6);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx.titulo);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx.subtitulo);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx.labelPesquisa);
    } }, encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderBottomComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header-bottom',
                templateUrl: './header-bottom.component.html',
            }]
    }], function () { return []; }, { titulo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], subtitulo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], labelPesquisa: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clickMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();

class HeaderLogoComponent extends BaseComponent {
    constructor() {
        super();
        // texto assinatura (texto ao lado direito da logo)
        this.textoAssinatura = 'Governo Federal';
    }
}
HeaderLogoComponent.ɵfac = function HeaderLogoComponent_Factory(t) { return new (t || HeaderLogoComponent)(); };
HeaderLogoComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderLogoComponent, selectors: [["br-header-logo"]], inputs: { logo: "logo", textoAssinatura: "textoAssinatura" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 5, vars: 2, consts: [[1, "header-logo"], ["alt", "logo", 3, "src"], [1, "br-divider", "vertical", "mx-half", "mx-sm-1"], [1, "header-sign"]], template: function HeaderLogoComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "img", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "span", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "div", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("src", ctx.logo, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx.textoAssinatura);
    } }, encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderLogoComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header-logo',
                templateUrl: './header-logo.component.html',
            }]
    }], function () { return []; }, { logo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], textoAssinatura: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

/**
 * Código copiado de: https://dsgov.estaleiro.serpro.gov.br/components/header?tab=desenvolvedor
 * na versão 2.1.0-BETA e convertido para Typescript
 */
class BRHeader {
    constructor(name, component) {
        this.name = name;
        this.component = component;
        this.componentSearch = this.component.querySelector('.header-search');
        this.componentSearchInput = this.component.querySelector('.header-search input');
        this.componentSearchTrigger = this.component.querySelector('[data-toggle="search"]');
        this.componentSearchDismiss = this.component.querySelector('[data-dismiss="search"]');
        this.hideDrop = null;
        this.menuTrigger = this.component.querySelector('[data-target="#main-navigation"]');
        this._setBehavior();
    }
    _setBehavior() {
        this._setLoginBehavior();
        this._setLogoutBehavior();
        this._setSearchBehaviors();
        this._setKeyboardBehaviors();
        this._setDropdownBehavior();
        this._setSticky();
    }
    _setLoginBehavior() {
        for (const login of this.component.querySelectorAll('[data-trigger="login"]')) {
            login.addEventListener('click', () => {
                const loginParent = login.closest('.header-login');
                loginParent.querySelector('.header-sign-in').classList.add('d-none');
                loginParent.querySelector('.header-avatar').classList.remove('d-none');
            });
        }
    }
    _setLogoutBehavior() {
        for (const logout of this.component.querySelectorAll('[data-trigger="logout"]')) {
            logout.addEventListener('click', () => {
                const logoutParent = logout.closest('.header-login');
                logoutParent.querySelector('.avatar').classList.remove('show');
                logoutParent
                    .querySelector('[data-toggle="dropdown"]')
                    .classList.remove('active');
                logoutParent
                    .querySelector('.header-sign-in')
                    .classList.remove('d-none');
                logoutParent.querySelector('.header-avatar').classList.add('d-none');
            });
        }
    }
    _setSearchBehaviors() {
        // Abrir busca
        if (this.componentSearchTrigger) {
            this.componentSearchTrigger.addEventListener('focus', () => {
                this._cleanDropDownHeader();
            });
            this.componentSearchTrigger.addEventListener('click', () => {
                this._openSearch();
            });
        }
        // Fechar busca
        if (this.componentSearchDismiss) {
            this.componentSearchDismiss.addEventListener('click', () => {
                this._closeSearch();
            });
        }
    }
    _setKeyboardBehaviors() {
        if (this.componentSearchInput) {
            this.componentSearchInput.addEventListener('keydown', (event) => {
                switch (event.keyCode) {
                    // Tecla ESC
                    case 27:
                        this._closeSearch();
                        break;
                    default:
                        break;
                }
            });
        }
        for (const trigger of this.component.querySelectorAll('.dropdown [data-toggle="dropdown"]')) {
            trigger.addEventListener('keydown', (event) => {
                switch (event.keyCode) {
                    // Tecla ESC
                    case 32:
                        if (event.target.parentNode.classList.contains('show')) {
                            event.target.parentNode.click();
                            event.target.parentNode.classList.remove('show');
                            event.target.classList.remove('active');
                            event.stopPropagation();
                        }
                        break;
                    default:
                        break;
                }
            });
        }
    }
    _openSearch() {
        if (this.componentSearch) {
            this.componentSearch.classList.add('active');
            this.componentSearch.querySelector('input').focus();
        }
    }
    _closeSearch() {
        if (this.componentSearch) {
            this.componentSearch.classList.remove('active');
            //this.componentSearchTrigger.focus()
            this._nextFocusElement().focus();
        }
    }
    _setDropdownBehavior() {
        let hideDrop;
        for (const trigger of this.component.querySelectorAll('.dropdown [data-toggle="dropdown"]')) {
            trigger.addEventListener('click', (event) => {
                clearTimeout(hideDrop);
                // Toggle de abrir / fechar
                const hasShow = event.target.parentNode.classList.contains('active');
                if (hasShow) {
                    event.target.parentNode.classList.remove('active');
                    event.target.parentNode.parentNode.classList.remove('show');
                }
                else {
                    this._cleanDropDownHeader();
                    trigger.classList.add('active');
                    trigger.parentNode.classList.add('show');
                    // Evita que o componente feche o drop ao navegar pelo teclado
                    const next = this._nextFocusElement();
                    next.addEventListener('focus', (event) => {
                        clearTimeout(hideDrop);
                    });
                }
                event.stopPropagation();
            });
            // Faz o drop fechar ao clicar fora
            trigger.addEventListener('blur', (event) => {
                hideDrop = setTimeout(this._cleanDropDownHeaderRef, 500, this.component);
            });
        }
        this.menuTrigger.addEventListener('focus', (event) => {
            this._cleanDropDownHeader();
        });
    }
    _cleanDropDownHeaderRef(ref) {
        for (const trigger of ref.querySelectorAll('.dropdown.show')) {
            trigger.classList.remove('show');
            trigger.parentNode.classList.remove('show');
            for (const button of ref.querySelectorAll('.br-button')) {
                button.classList.remove('active');
            }
        }
    }
    _cleanDropDownHeader() {
        this._cleanDropDownHeaderRef(this.component);
    }
    _setSticky() {
        if (this.component.hasAttribute('data-sticky')) {
            window.onscroll = () => {
                if (window.pageYOffset > this.component.offsetHeight) {
                    this.component.classList.add('sticky', 'compact');
                }
                else {
                    this.component.classList.remove('sticky', 'compact');
                }
            };
        }
    }
    _nextFocusElement() {
        //add all elements we want to include in our selection
        const focussableElements = 'a:not([disabled]), button:not([disabled]), input[type=text]:not([disabled]), [tabindex]:not([disabled]):not([tabindex="-1"])';
        if (document.activeElement) {
            const focussable = Array.prototype.filter.call(document.body.querySelectorAll(focussableElements), (element) => {
                //check for visibility while always include the current activeElement
                return (element.offsetWidth > 0 ||
                    element.offsetHeight > 0 ||
                    element === document.activeElement);
            });
            const index = focussable.indexOf(document.activeElement);
            if (index > -1) {
                const nextElement = focussable[index + 1] || focussable[0];
                //nextElement.focus();
                return nextElement;
            }
        }
        return null;
    }
}

class TamanhoHeader {
}
TamanhoHeader.DEFAULT = '';
TamanhoHeader.LARGE = 'large';
TamanhoHeader.SMALL = 'small';
TamanhoHeader.COMPACT = 'compact';

class HeaderComponent extends BaseComponent {
    constructor(component, domSanitizer) {
        super();
        this.component = component;
        this.domSanitizer = domSanitizer;
        // texto assinatura (texto ao lado direito da logo)
        this.textoAssinatura = 'Governo Federal';
        // texto do Título
        this.titulo = 'Título';
        // texto do Subtítulo
        this.subtitulo = 'Subtítulo';
        //texto do label do campo de pesquisa
        this.labelPesquisa = 'Texto da pesquisa';
        // links do cabeçalho
        this.links = [];
        // menu de funcionalidades do cabeçalho
        this.funcionalidades = [];
        // tamanho do header
        this.tamanhoHeader = TamanhoHeader.DEFAULT;
        // Evento do clique para abrir o menu
        this.clickMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Evento de click do botão entrar (login)
        this.clickEntrar = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Evento de click no botão sair
        this.clickSair = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //logo gov.br
        this.base64LogoDefault = this.domSanitizer.bypassSecurityTrustUrl(base64LogoGovBr);
    }
    ngOnInit() {
        this.headerDS = new BRHeader('br-header', this.component.nativeElement);
    }
    onClickMenu(event) {
        this.clickMenu.emit(event);
    }
    onClickEntrar(event) {
        this.clickEntrar.emit(event);
    }
    onClickSair(event) {
        this.clickSair.emit(event);
    }
}
HeaderComponent.ɵfac = function HeaderComponent_Factory(t) { return new (t || HeaderComponent)(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"])(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"])(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"])); };
HeaderComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: HeaderComponent, selectors: [["br-header"]], inputs: { urlImagem: "urlImagem", textoAssinatura: "textoAssinatura", titulo: "titulo", subtitulo: "subtitulo", labelPesquisa: "labelPesquisa", links: "links", funcionalidades: "funcionalidades", tamanhoHeader: "tamanhoHeader", usuario: "usuario" }, outputs: { clickMenu: "clickMenu", clickEntrar: "clickEntrar", clickSair: "clickSair" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 6, vars: 10, consts: [["id", "header"], [1, "container-fluid"], [1, "header-top"], ["ngClass", "header-logo", 3, "logo", "textoAssinatura"], ["ngClass", "header-actions", 3, "usuario", "links", "funcionalidades", "clickEntrar", "clickSair"], ["ngClass", "header-bottom", 3, "titulo", "subtitulo", "labelPesquisa", "clickMenu"]], template: function HeaderComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "header", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "div", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(3, "br-header-logo", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "br-header-actions", 4);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("clickEntrar", function HeaderComponent_Template_br_header_actions_clickEntrar_4_listener($event) { return ctx.onClickEntrar($event); })("clickSair", function HeaderComponent_Template_br_header_actions_clickSair_4_listener($event) { return ctx.onClickSair($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "br-header-bottom", 5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("clickMenu", function HeaderComponent_Template_br_header_bottom_clickMenu_5_listener($event) { return ctx.onClickMenu($event); });
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])("br-header " + ctx.tamanhoHeader);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("logo", ctx.urlImagem || ctx.base64LogoDefault)("textoAssinatura", ctx.textoAssinatura);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("usuario", ctx.usuario)("links", ctx.links)("funcionalidades", ctx.funcionalidades);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("titulo", ctx.titulo)("subtitulo", ctx.subtitulo)("labelPesquisa", ctx.labelPesquisa);
    } }, directives: [HeaderLogoComponent, _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], HeaderActionsComponent, HeaderBottomComponent], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-header',
                templateUrl: './header.component.html',
            }]
    }], function () { return [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"] }]; }, { urlImagem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], textoAssinatura: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], titulo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], subtitulo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], labelPesquisa: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], links: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], funcionalidades: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], tamanhoHeader: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], usuario: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], clickMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], clickEntrar: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], clickSair: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();

class HeaderModule {
}
HeaderModule.ɵfac = function HeaderModule_Factory(t) { return new (t || HeaderModule)(); };
HeaderModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: HeaderModule });
HeaderModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], DividerModule, SigninModule, ButtonModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(HeaderModule, { declarations: [HeaderComponent,
        HeaderLogoComponent,
        HeaderActionsComponent,
        HeaderLinksComponent,
        HeaderFunctionsComponent,
        HeaderSearchTriggerComponent,
        HeaderLoginComponent,
        HeaderBottomComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], DividerModule, SigninModule, ButtonModule], exports: [HeaderComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(HeaderModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [
                    HeaderComponent,
                    HeaderLogoComponent,
                    HeaderActionsComponent,
                    HeaderLinksComponent,
                    HeaderFunctionsComponent,
                    HeaderSearchTriggerComponent,
                    HeaderLoginComponent,
                    HeaderBottomComponent,
                ],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], DividerModule, SigninModule, ButtonModule],
                exports: [HeaderComponent],
            }]
    }], null, null); })();

class EstadoInput {
}
EstadoInput.DEFAULT = '';
EstadoInput.SUCCESS = 'success';
EstadoInput.DANGER = 'danger';
EstadoInput.WARNING = 'warning';
EstadoInput.INFO = 'info';

function InputComponent_label_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "label", 4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("for", ctx_r0.id)("ngClass", ctx_r0.ngClassLabel);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r0.textoLabel);
} }
function InputComponent_br_button_3_Template(rf, ctx) { if (rf & 1) {
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-button", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function InputComponent_br_button_3_Template_br_button_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r4); const ctx_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return ctx_r3.onClickButton($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "i", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx_r1.jc(ctx_r1.ngClassButton, "circle", "small"));
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r1.classIconeFontAwesomeBotao);
} }
function InputComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "i", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])("feedback mt-1 " + ctx_r2.estado);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r2.iconesEstado[ctx_r2.estado]);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r2.textoFeedback);
} }
const _c0$3 = ["*"];
class InputComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.ESTADO_DEFAULT = EstadoInput.DEFAULT;
        //ícones feedback
        this.iconesEstado = {
            success: 'fas fa-check-circle',
            danger: 'fas fa-times-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle',
        };
        //Evento de click
        this.click = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // Evento de mudança de valor
        this.change = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // Evento de pressiona tecla
        this.keypress = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Evento de click do botao dentro do input
        this.clickButton = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //atributos input HTML
        this.type = 'text';
        this.placeHolder = '';
        this.required = false;
        // Estado do componente input
        this.estado = EstadoInput.DEFAULT;
        // Densidade dos itens de menu. Default: densidade medium
        this.densidade = Densidade.MEDIA;
        // classes aplicáveis ao <label></label>
        this.ngClassLabel = '';
        // classes aplicáveis ao <input></input>
        this.ngClassInput = '';
        // classes aplicáveis ao <button></button>
        this.ngClassButton = '';
    }
    ngOnInit() {
        if (!this.id) {
            this.id = this.textoLabel;
        }
    }
    onClickButton(event) {
        //The mouseEvent propagates from the child component to the parent component by default.
        //You can stop propagation of event to parent component.
        event.stopPropagation();
        this.clickButton.emit(event);
    }
}
InputComponent.ɵfac = function InputComponent_Factory(t) { return new (t || InputComponent)(); };
InputComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: InputComponent, selectors: [["br-input"]], inputs: { type: "type", maxLength: "maxLength", min: "min", max: "max", pattern: "pattern", placeHolder: "placeHolder", step: "step", required: "required", formControlName: "formControlName", textoLabel: "textoLabel", classIconeFontAwesomeBotao: "classIconeFontAwesomeBotao", ariaLabelButton: "ariaLabelButton", textoFeedback: "textoFeedback", estado: "estado", isDisabled: "isDisabled", densidade: "densidade", ngClassLabel: "ngClassLabel", ngClassInput: "ngClassInput", ngClassButton: "ngClassButton" }, outputs: { click: "click", change: "change", keypress: "keypress", clickButton: "clickButton" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c0$3, decls: 6, vars: 20, consts: [[3, "for", "ngClass", 4, "ngIf"], [3, "ngClass", "id", "type", "disabled", "maxLength", "min", "max", "pattern", "placeholder", "step"], [3, "ngClass", "click", 4, "ngIf"], ["role", "alert", 3, "class", 4, "ngIf"], [3, "for", "ngClass"], [3, "ngClass", "click"], ["aria-hidden", "true"], ["role", "alert"]], template: function InputComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, InputComponent_label_1_Template, 2, 3, "label", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(2, "input", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, InputComponent_br_button_3_Template, 2, 3, "br-button", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(4, InputComponent_span_4_Template, 3, 5, "span", 3);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"])(5);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx.jc(ctx.ngClass, "br-input", ctx.densidade, ctx.estado, ctx.classIconeFontAwesomeBotao != null ? " has-icon " : ""));
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.textoLabel);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"])("disabled", ctx.isDisabled);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngClass", ctx.jc(ctx.ngClassInput, ctx.estado, ctx.densidade, ctx.classIconeFontAwesomeBotao != null ? "has-icon" : ""))("id", ctx.id)("type", ctx.type)("ngClass", ctx.ngClassInput)("disabled", ctx.isDisabled ? "disabled" : "")("maxLength", ctx.maxLength)("min", ctx.min)("max", ctx.max)("pattern", ctx.pattern)("placeholder", ctx.placeHolder)("step", ctx.step);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"])("formControlName", ctx.formControlName)("required", ctx.required);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.classIconeFontAwesomeBotao);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.estado != ctx.ESTADO_DEFAULT && ctx.textoFeedback);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControlName"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["PatternValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["RequiredValidator"], ButtonComponent], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(InputComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-input',
                templateUrl: './input.component.html',
            }]
    }], function () { return []; }, { click: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], change: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], keypress: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], clickButton: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], type: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], maxLength: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], min: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], max: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], pattern: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], placeHolder: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], step: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], required: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], formControlName: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], textoLabel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], classIconeFontAwesomeBotao: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], ariaLabelButton: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], textoFeedback: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], estado: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], isDisabled: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], densidade: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], ngClassLabel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], ngClassInput: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], ngClassButton: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class InputModule {
}
InputModule.ɵfac = function InputModule_Factory(t) { return new (t || InputModule)(); };
InputModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: InputModule });
InputModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], ButtonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(InputModule, { declarations: [InputComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], ButtonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]], exports: [InputComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(InputModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [InputComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], ButtonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]],
                exports: [InputComponent],
            }]
    }], null, null); })();

class RegraExibicaoMenu {
}
RegraExibicaoMenu.SEMPRE = 'sempre';
RegraExibicaoMenu.LOGADO = 'logado';
RegraExibicaoMenu.NAO_LOGADO = 'naoLogado';

function ItemMenuComponent_li_0_a_1_i_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "i", 6);
} if (rf & 2) {
    const ctx_r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r4.item == null ? null : ctx_r4.item.link == null ? null : ctx_r4.item.link.classIconeFontAwesome);
} }
function ItemMenuComponent_li_0_a_1_span_2_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r5 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r5.item.link.texto);
} }
function ItemMenuComponent_li_0_a_1_Template(rf, ctx) { if (rf & 1) {
    const _r7 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "a", 3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function ItemMenuComponent_li_0_a_1_Template_a_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r7); const ctx_r6 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2); return ctx_r6.onClickComponent($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemMenuComponent_li_0_a_1_i_1_Template, 1, 2, "i", 4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, ItemMenuComponent_li_0_a_1_span_2_Template, 2, 1, "span", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("routerLink", (ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.tipo) == ctx_r3.TIPOLINK_ROTA ? ctx_r3.item.link.url : null)("href", (ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.tipo) == ctx_r3.TIPOLINK_URL ? ctx_r3.item.link.url : null, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("target", (ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.tipo) == ctx_r3.TIPOLINK_URL && ctx_r3.item.link.novaAba ? "_blank" : null);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.classIconeFontAwesome);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.texto);
} }
function ItemMenuComponent_li_0_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "li");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemMenuComponent_li_0_a_1_Template, 3, 5, "a", 2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r0.idSideMenuVisivel.length == 0 || ctx_r0.idSideMenuVisivel[ctx_r0.idSideMenuVisivel.length - 1] == ctx_r0.item.id || ctx_r0.item.idParents.includes(ctx_r0.idSideMenuVisivel[ctx_r0.idSideMenuVisivel.length - 1]));
} }
function ItemMenuComponent_ng_template_1_li_0_a_1_span_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span", 15);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "i", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r11 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r11.item.link.classIconeFontAwesome);
} }
function ItemMenuComponent_ng_template_1_li_0_a_1_span_2_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r12 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r12.item.link.texto);
} }
function ItemMenuComponent_ng_template_1_li_0_a_1_Template(rf, ctx) { if (rf & 1) {
    const _r14 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "a", 11);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function ItemMenuComponent_ng_template_1_li_0_a_1_Template_a_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r14); const ctx_r13 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3); return ctx_r13.onClickComponent($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemMenuComponent_ng_template_1_li_0_a_1_span_1_Template, 2, 2, "span", 12);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, ItemMenuComponent_ng_template_1_li_0_a_1_span_2_Template, 2, 1, "span", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "span", 13);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(4, "i", 14);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r9 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r9.item.link.classIconeFontAwesome);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r9.item.link.texto);
} }
function ItemMenuComponent_ng_template_1_li_0_ng_container_3_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "br-item-menu", 17);
} if (rf & 2) {
    const subItem_r15 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    const ctx_r16 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("item", subItem_r15)("closeMenu", ctx_r16.closeMenu)("mudancaExibicaoSideMenu", ctx_r16.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r16.idSideMenuVisivel);
} }
function ItemMenuComponent_ng_template_1_li_0_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemMenuComponent_ng_template_1_li_0_ng_container_3_br_item_menu_1_Template, 1, 4, "br-item-menu", 16);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const subItem_r15 = ctx.$implicit;
    const ctx_r10 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", subItem_r15.exibicao == null || subItem_r15.exibicao == ctx_r10.SEMPRE || subItem_r15.exibicao == ctx_r10.LOGADO && ctx_r10.usuario != null || subItem_r15.exibicao == ctx_r10.NAO_LOGADO && ctx_r10.usuario == null);
} }
function ItemMenuComponent_ng_template_1_li_0_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "li");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemMenuComponent_ng_template_1_li_0_a_1_Template, 5, 2, "a", 9);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "ul");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, ItemMenuComponent_ng_template_1_li_0_ng_container_3_Template, 2, 1, "ng-container", 10);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r8 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r8.expandido ? "side-menu active" : "side-menu");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r8.idSideMenuVisivel.length == 0 || ctx_r8.idSideMenuVisivel[ctx_r8.idSideMenuVisivel.length - 1] == ctx_r8.item.id || ctx_r8.item.idParents.includes(ctx_r8.idSideMenuVisivel[ctx_r8.idSideMenuVisivel.length - 1]));
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx_r8.item.subItens);
} }
function ItemMenuComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(0, ItemMenuComponent_ng_template_1_li_0_Template, 4, 4, "li", 8);
} if (rf & 2) {
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r2.idSideMenuVisivel.length == 0 || ctx_r2.idSideMenuVisivel[ctx_r2.idSideMenuVisivel.length - 1] == ctx_r2.item.id || ctx_r2.item.idParents.includes(ctx_r2.idSideMenuVisivel[ctx_r2.idSideMenuVisivel.length - 1]) || ctx_r2.item.idChildren.includes(ctx_r2.idSideMenuVisivel[ctx_r2.idSideMenuVisivel.length - 1]));
} }
class ItemMenuComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = RegraExibicaoMenu.SEMPRE;
        this.LOGADO = RegraExibicaoMenu.LOGADO;
        this.NAO_LOGADO = RegraExibicaoMenu.NAO_LOGADO;
        this.TIPOLINK_ROTA = TipoLink.ROTA;
        this.TIPOLINK_URL = TipoLink.URL;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // o EventEmitter de fechamento do menu é passado para os grupos e depois para os itens
        // de menu a fim de que seja chamado quando um item de menu de rota (sem uma função que
        // trate o click) for clicado
        this.closeMenu = null;
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = null;
        // se o item tiver subitens, essa propriedade determina se os subitens estão expandidos
        // ou colapsados
        this.expandido = false;
    }
    // SE TIVER SUBITENS: o click no elemento inverte a condição de expandido ou não do próprio componente
    // SEM SUBITENS, COM CLICK SETADO: invoca a função associada ao click passando o próprio item como argumento
    // SEM SUBITENS NEM CLICK SETADO: Chama 'emit' do EventEmitter recebido em 'closeMenu'
    onClickComponent(event) {
        if (this.item.subItens && this.item.subItens.length > 0) {
            this.expandido = !this.expandido;
            this.mudancaExibicaoSideMenu.emit(this.expandido ? this.item.id : null);
        }
        //Se tiver uma função associada ao atributo 'click', invoca-a
        else if (this.item.click) {
            this.item.click(this.item);
        }
        else if (this.closeMenu != null) {
            this.closeMenu.emit(event);
        }
    }
}
ItemMenuComponent.ɵfac = function ItemMenuComponent_Factory(t) { return new (t || ItemMenuComponent)(); };
ItemMenuComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: ItemMenuComponent, selectors: [["br-item-menu"]], inputs: { item: "item", idSideMenuVisivel: "idSideMenuVisivel", closeMenu: "closeMenu", mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu", expandido: "expandido" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 2, consts: [[4, "ngIf", "ngIfElse"], ["itemAgrupador", ""], ["class", "menu-item", 3, "routerLink", "href", "target", "click", 4, "ngIf"], [1, "menu-item", 3, "routerLink", "href", "target", "click"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], ["class", "content", 4, "ngIf"], ["aria-hidden", "true"], [1, "content"], [3, "class", 4, "ngIf"], ["href", "javascript: void(0)", "class", "menu-item", 3, "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["href", "javascript: void(0)", 1, "menu-item", 3, "click"], ["class", "icon", 4, "ngIf"], [1, "support"], ["aria-hidden", "true", 1, "fas", "fa-angle-right"], [1, "icon"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function ItemMenuComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(0, ItemMenuComponent_li_0_Template, 2, 1, "li", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, ItemMenuComponent_ng_template_1_Template, 1, 1, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        const _r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.item.subItens == null || ctx.item.subItens.length == 0)("ngIfElse", _r1);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLinkWithHref"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], ItemMenuComponent], styles: ["a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(ItemMenuComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-item-menu',
                templateUrl: './item-menu.component.html',
                styles: [
                    `
      a {
        text-decoration: none;
        font-weight: normal;
      }
    `,
                ],
            }]
    }], function () { return []; }, { item: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], idSideMenuVisivel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], mudancaExibicaoSideMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], expandido: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class TipoAgrupamentoLista {
}
TipoAgrupamentoLista.EXPANSAO = 'expansao';
TipoAgrupamentoLista.ROTULO = 'rotulo';
TipoAgrupamentoLista.DIVIDER = 'divider';

function GrupoMenuExpansaoComponent_a_1_span_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "i", 8);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r2.grupo.classIconeFontAwesome);
} }
function GrupoMenuExpansaoComponent_a_1_i_5_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "i", 9);
} }
function GrupoMenuExpansaoComponent_a_1_Template(rf, ctx) { if (rf & 1) {
    const _r5 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "a", 2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function GrupoMenuExpansaoComponent_a_1_Template_a_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r5); const ctx_r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return ctx_r4.onClickComponent($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoMenuExpansaoComponent_a_1_span_1_Template, 2, 2, "span", 3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "span", 4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "span", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(5, GrupoMenuExpansaoComponent_a_1_i_5_Template, 1, 0, "i", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r0.grupo.classIconeFontAwesome);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r0.grupo.texto);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", (ctx_r0.grupo == null ? null : ctx_r0.grupo.itens.length) > 0);
} }
function GrupoMenuExpansaoComponent_ng_container_3_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "br-item-menu", 11);
} if (rf & 2) {
    const item_r6 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    const ctx_r7 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("item", item_r6)("closeMenu", ctx_r7.closeMenu)("mudancaExibicaoSideMenu", ctx_r7.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r7.idSideMenuVisivel);
} }
function GrupoMenuExpansaoComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoMenuExpansaoComponent_ng_container_3_br_item_menu_1_Template, 1, 4, "br-item-menu", 10);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", item_r6.exibicao == null || item_r6.exibicao == ctx_r1.SEMPRE || item_r6.exibicao == ctx_r1.LOGADO && ctx_r1.usuario != null || item_r6.exibicao == ctx_r1.NAO_LOGADO && ctx_r1.usuario == null);
} }
class GrupoMenuExpansaoComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = RegraExibicaoMenu.SEMPRE;
        this.LOGADO = RegraExibicaoMenu.LOGADO;
        this.NAO_LOGADO = RegraExibicaoMenu.NAO_LOGADO;
        //Indica se o grupo de menu está expandido ou colapsado
        this.expandido = true;
        // o EventEmitter de fechamento do menu é passado para os grupos a fim de que seja chamado
        // quando um item de menu de rota (sem uma função que trate o click) for clicado
        this.closeMenu = null;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    // o click no grupo inverte a condição de expandido ou não do próprio componente de Grupo e,
    // havendo uma função a ser acionada no click do grupo, também é invocada
    onClickComponent(event) {
        this.expandido = !this.expandido;
        //Se o grupo tiver uma função associada ao atributo 'click', invoca-a
        if (this.grupo.click) {
            this.grupo.click(this.grupo);
        }
    }
}
GrupoMenuExpansaoComponent.ɵfac = function GrupoMenuExpansaoComponent_Factory(t) { return new (t || GrupoMenuExpansaoComponent)(); };
GrupoMenuExpansaoComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: GrupoMenuExpansaoComponent, selectors: [["br-grupo-menu-expansao"]], inputs: { grupo: "grupo", usuario: "usuario", expandido: "expandido", closeMenu: "closeMenu", idSideMenuVisivel: "idSideMenuVisivel" }, outputs: { mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 4, vars: 4, consts: [["class", "menu-item", "href", "javascript: void(0)", 3, "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["href", "javascript: void(0)", 1, "menu-item", 3, "click"], ["class", "icon", 4, "ngIf"], [1, "content"], [1, "support"], ["class", "fas fa-angle-down", "aria-hidden", "true", 4, "ngIf"], [1, "icon"], ["aria-hidden", "true"], ["aria-hidden", "true", 1, "fas", "fa-angle-down"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function GrupoMenuExpansaoComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoMenuExpansaoComponent_a_1_Template, 6, 3, "a", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "ul");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, GrupoMenuExpansaoComponent_ng_container_3_Template, 2, 1, "ng-container", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx.expandido ? "divisor-menu menu-folder drop-menu active" : "menu-folder drop-menu");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.idSideMenuVisivel.length == 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx.grupo.itens);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], ItemMenuComponent], styles: ["div.divisor-menu.menu-folder[_ngcontent-%COMP%] {\n    border-bottom: 1px solid var(--menu-divider);", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(GrupoMenuExpansaoComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-grupo-menu-expansao',
                templateUrl: './grupo-menu-expansao.component.html',
                styles: [
                    `div.divisor-menu.menu-folder {
    border-bottom: 1px solid var(--menu-divider);`,
                    `
      a {
        text-decoration: none;
        font-weight: normal;
      }
    `,
                ],
            }]
    }], function () { return []; }, { grupo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], usuario: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], expandido: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], idSideMenuVisivel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], mudancaExibicaoSideMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();

function GrupoMenuRotulosComponent_div_1_span_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "span", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(1, "i", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r2.grupo.classIconeFontAwesome);
} }
const _c0$4 = function () { return { cursor: "pointer" }; };
function GrupoMenuRotulosComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function GrupoMenuRotulosComponent_div_1_Template_div_click_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r4); const ctx_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return ctx_r3.onClickComponent($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoMenuRotulosComponent_div_1_span_1_Template, 2, 2, "span", 4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "span", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngStyle", ctx_r0.grupo.click != null ? Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"])(3, _c0$4) : ctx_r0._);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r0.grupo.classIconeFontAwesome);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r0.grupo.texto);
} }
function GrupoMenuRotulosComponent_ng_container_3_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "br-item-menu", 9);
} if (rf & 2) {
    const item_r5 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    const ctx_r6 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("item", item_r5)("closeMenu", ctx_r6.closeMenu)("mudancaExibicaoSideMenu", ctx_r6.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r6.idSideMenuVisivel);
} }
function GrupoMenuRotulosComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoMenuRotulosComponent_ng_container_3_br_item_menu_1_Template, 1, 4, "br-item-menu", 8);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    const ctx_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", item_r5.exibicao == null || item_r5.exibicao == ctx_r1.SEMPRE || item_r5.exibicao == ctx_r1.LOGADO && ctx_r1.usuario != null || item_r5.exibicao == ctx_r1.NAO_LOGADO && ctx_r1.usuario == null);
} }
class GrupoMenuRotulosComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = RegraExibicaoMenu.SEMPRE;
        this.LOGADO = RegraExibicaoMenu.LOGADO;
        this.NAO_LOGADO = RegraExibicaoMenu.NAO_LOGADO;
        // o EventEmitter de fechamento do menu é passado para os grupos a fim de que seja chamado
        // quando um item de menu de rota (sem uma função que trate o click) for clicado
        this.closeMenu = null;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    // havendo uma função a ser acionada no click do grupo, também é invocada
    onClickComponent(event) {
        //Se o grupo tiver uma função associada ao atributo 'click', invoca-a
        if (this.grupo.click) {
            this.grupo.click(this.grupo);
        }
    }
}
GrupoMenuRotulosComponent.ɵfac = function GrupoMenuRotulosComponent_Factory(t) { return new (t || GrupoMenuRotulosComponent)(); };
GrupoMenuRotulosComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: GrupoMenuRotulosComponent, selectors: [["br-grupo-menu-rotulos"]], inputs: { grupo: "grupo", usuario: "usuario", closeMenu: "closeMenu", idSideMenuVisivel: "idSideMenuVisivel" }, outputs: { mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 4, vars: 2, consts: [[1, "menu-folder", "divisor-menu"], ["class", "menu-item", 3, "ngStyle", "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "menu-item", 3, "ngStyle", "click"], ["class", "icon", 4, "ngIf"], [1, "content"], [1, "icon"], ["aria-hidden", "true"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function GrupoMenuRotulosComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoMenuRotulosComponent_div_1_Template, 4, 4, "div", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "ul");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, GrupoMenuRotulosComponent_ng_container_3_Template, 2, 1, "ng-container", 2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.idSideMenuVisivel.length == 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx.grupo.itens);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgStyle"], ItemMenuComponent], styles: ["div.divisor-menu.menu-folder[_ngcontent-%COMP%] {\n    border-bottom: 1px solid var(--menu-divider);", "div.divisor-menu.menu-folder[_ngcontent-%COMP%]   div.menu-item[_ngcontent-%COMP%] {\n    color: black;", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(GrupoMenuRotulosComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-grupo-menu-rotulos',
                templateUrl: './grupo-menu-rotulos.component.html',
                styles: [
                    `div.divisor-menu.menu-folder {
    border-bottom: 1px solid var(--menu-divider);`,
                    `div.divisor-menu.menu-folder div.menu-item {
    color: black;`,
                    `
      a {
        text-decoration: none;
        font-weight: normal;
      }
    `,
                ],
            }]
    }], function () { return []; }, { grupo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], usuario: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], idSideMenuVisivel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], mudancaExibicaoSideMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();

function GrupoMenuDividersComponent_ng_container_2_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(0, "br-item-menu", 3);
} if (rf & 2) {
    const item_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("item", item_r1)("closeMenu", ctx_r2.closeMenu)("mudancaExibicaoSideMenu", ctx_r2.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r2.idSideMenuVisivel);
} }
function GrupoMenuDividersComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, GrupoMenuDividersComponent_ng_container_2_br_item_menu_1_Template, 1, 4, "br-item-menu", 2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", item_r1.exibicao == null || item_r1.exibicao == ctx_r0.SEMPRE || item_r1.exibicao == ctx_r0.LOGADO && ctx_r0.usuario != null || item_r1.exibicao == ctx_r0.NAO_LOGADO && ctx_r0.usuario == null);
} }
class GrupoMenuDividersComponent extends BaseComponent {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = RegraExibicaoMenu.SEMPRE;
        this.LOGADO = RegraExibicaoMenu.LOGADO;
        this.NAO_LOGADO = RegraExibicaoMenu.NAO_LOGADO;
        // o EventEmitter de fechamento do menu é passado para os grupos a fim de que seja chamado
        // quando um item de menu de rota (sem uma função que trate o click) for clicado
        this.closeMenu = null;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
}
GrupoMenuDividersComponent.ɵfac = function GrupoMenuDividersComponent_Factory(t) { return new (t || GrupoMenuDividersComponent)(); };
GrupoMenuDividersComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: GrupoMenuDividersComponent, selectors: [["br-grupo-menu-dividers"]], inputs: { grupo: "grupo", usuario: "usuario", closeMenu: "closeMenu", idSideMenuVisivel: "idSideMenuVisivel" }, outputs: { mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 1, consts: [[1, "menu-folder", "divisor-menu"], [4, "ngFor", "ngForOf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function GrupoMenuDividersComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 0);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "ul");
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, GrupoMenuDividersComponent_ng_container_2_Template, 2, 1, "ng-container", 1);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx.grupo.itens);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], ItemMenuComponent], styles: ["div.divisor-menu.menu-folder[_ngcontent-%COMP%] {\n      border-bottom: 1px solid var(--menu-divider);", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(GrupoMenuDividersComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-grupo-menu-dividers',
                templateUrl: './grupo-menu-dividers.component.html',
                styles: [
                    `div.divisor-menu.menu-folder {
      border-bottom: 1px solid var(--menu-divider);`,
                    `
      a {
        text-decoration: none;
        font-weight: normal;
      }
    `,
                ],
            }]
    }], function () { return []; }, { grupo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], usuario: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], idSideMenuVisivel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], mudancaExibicaoSideMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }] }); })();

function MenuComponent_div_0_ng_container_14_br_grupo_menu_expansao_1_Template(rf, ctx) { if (rf & 1) {
    const _r8 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-grupo-menu-expansao", 17);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("mudancaExibicaoSideMenu", function MenuComponent_div_0_ng_container_14_br_grupo_menu_expansao_1_Template_br_grupo_menu_expansao_mudancaExibicaoSideMenu_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r8); const ctx_r7 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3); return ctx_r7.onMudancaExibicaoSideMenu($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const grupo_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    const ctx_r4 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("grupo", grupo_r3)("usuario", ctx_r4.usuario)("closeMenu", ctx_r4.closeMenu)("idSideMenuVisivel", ctx_r4.idSideMenuVisivel);
} }
function MenuComponent_div_0_ng_container_14_br_grupo_menu_rotulos_2_Template(rf, ctx) { if (rf & 1) {
    const _r11 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-grupo-menu-rotulos", 17);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("mudancaExibicaoSideMenu", function MenuComponent_div_0_ng_container_14_br_grupo_menu_rotulos_2_Template_br_grupo_menu_rotulos_mudancaExibicaoSideMenu_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r11); const ctx_r10 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3); return ctx_r10.onMudancaExibicaoSideMenu($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const grupo_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    const ctx_r5 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("grupo", grupo_r3)("usuario", ctx_r5.usuario)("closeMenu", ctx_r5.closeMenu)("idSideMenuVisivel", ctx_r5.idSideMenuVisivel);
} }
function MenuComponent_div_0_ng_container_14_br_grupo_menu_dividers_3_Template(rf, ctx) { if (rf & 1) {
    const _r14 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "br-grupo-menu-dividers", 17);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("mudancaExibicaoSideMenu", function MenuComponent_div_0_ng_container_14_br_grupo_menu_dividers_3_Template_br_grupo_menu_dividers_mudancaExibicaoSideMenu_0_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r14); const ctx_r13 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3); return ctx_r13.onMudancaExibicaoSideMenu($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const grupo_r3 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])().$implicit;
    const ctx_r6 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("grupo", grupo_r3)("usuario", ctx_r6.usuario)("closeMenu", ctx_r6.closeMenu)("idSideMenuVisivel", ctx_r6.idSideMenuVisivel);
} }
function MenuComponent_div_0_ng_container_14_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, MenuComponent_div_0_ng_container_14_br_grupo_menu_expansao_1_Template, 1, 4, "br-grupo-menu-expansao", 16);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(2, MenuComponent_div_0_ng_container_14_br_grupo_menu_rotulos_2_Template, 1, 4, "br-grupo-menu-rotulos", 16);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(3, MenuComponent_div_0_ng_container_14_br_grupo_menu_dividers_3_Template, 1, 4, "br-grupo-menu-dividers", 16);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const ctx_r1 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r1.tipoAgrupamentoMenu == ctx_r1.AGRUPAMENTO_EXPANSAO);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r1.tipoAgrupamentoMenu == ctx_r1.AGRUPAMENTO_ROTULO);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r1.tipoAgrupamentoMenu == ctx_r1.AGRUPAMENTO_DIVIDER);
} }
function MenuComponent_div_0_div_15_div_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"])(0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "a", 23);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "span", 24);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(4, "i", 25);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"])();
} if (rf & 2) {
    const link_r18 = ctx.$implicit;
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("href", link_r18.url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(link_r18.texto);
} }
function MenuComponent_div_0_div_15_div_1_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 22);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, MenuComponent_div_0_div_15_div_1_ng_container_1_Template, 5, 2, "ng-container", 13);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r16 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx_r16.linksExternos);
} }
function MenuComponent_div_0_div_15_Template(rf, ctx) { if (rf & 1) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 18);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(1, MenuComponent_div_0_div_15_div_1_Template, 2, 1, "div", 19);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "div", 20);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "div", 21);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "strong");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r2 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r2.linksExternos.length > 0);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"])(" ", ctx_r2.informacaoLicenca.label, " ");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r2.informacaoLicenca.nomeLicenca);
} }
function MenuComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r20 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(0, "div", 1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(1, "div", 2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(2, "div", 3);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(3, "div", 4);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(4, "div", 5);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(5, "div", 6);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(6, "div", 7);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(7, "button", 8);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"])("click", function MenuComponent_div_0_Template_button_click_7_listener($event) { Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"])(_r20); const ctx_r19 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])(); return ctx_r19.onCloseMenu($event); });
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(8, "i", 9);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(9, "div", 10);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(10, "img", 11);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(11, "span");
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"])(12);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"])(13, "nav", 12);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(14, MenuComponent_div_0_ng_container_14_Template, 4, 3, "ng-container", 13);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(15, MenuComponent_div_0_div_15_Template, 7, 3, "div", 14);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"])(16, "div", 15);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"])();
} if (rf & 2) {
    const ctx_r0 = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"])();
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"])(ctx_r0.jc(ctx_r0.ngClass, "br-menu active", ctx_r0.densidade == "medium" ? "" : ctx_r0.densidade));
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(10);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("src", ctx_r0.urlImagem || ctx_r0.base64LogoDefault, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"])(ctx_r0.titulo);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(2);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngForOf", ctx_r0.grupos);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"])(1);
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx_r0.exibeInformacaoLicenca);
} }
class MenuComponent extends BaseComponent {
    constructor(domSanitizer) {
        super();
        this.domSanitizer = domSanitizer;
        //constantes usadas no template
        this.SEMPRE = RegraExibicaoMenu.SEMPRE;
        this.LOGADO = RegraExibicaoMenu.LOGADO;
        this.NAO_LOGADO = RegraExibicaoMenu.NAO_LOGADO;
        this.AGRUPAMENTO_EXPANSAO = TipoAgrupamentoLista.EXPANSAO;
        this.AGRUPAMENTO_ROTULO = TipoAgrupamentoLista.ROTULO;
        this.AGRUPAMENTO_DIVIDER = TipoAgrupamentoLista.DIVIDER;
        // Tipo do agrupamento do menu
        this.tipoAgrupamentoMenu = TipoAgrupamentoLista.EXPANSAO;
        // Densidade dos itens de menu. Default: densidade normal
        this.densidade = Densidade.MEDIA;
        // controle endógeno da exibição do menu
        this.visivel = false;
        // evento disparado quando o menu é fechado
        this.closeMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Links externos exibidos no menu, abaixo dos itens
        this.linksExternos = [];
        // Indica a exibição ou não da informação sobre licença no menu
        this.exibeInformacaoLicenca = true;
        // Label de apresentação e nome da licença utilizada
        this.informacaoLicenca = new InformacaoLicenca();
        // Pilha com IDs de side-menus (um menu com subitens de um item) ativos no momento
        // o ID da ponta da pilha é em exibição no momento. Ao fechar o side-menu, ocorre
        // um POP nesta pilha
        this.idSideMenuVisivel = [];
        //logo gov.br
        this.base64LogoDefault = this.domSanitizer.bypassSecurityTrustUrl(base64LogoGovBr);
    }
    ngOnInit() {
        // setando ids para os grupos e itens de menu
        // utilizado no controle de exibição/ocultação de side-menus
        this.grupos.forEach((g, i) => {
            this.setIDs([i.toString()], g.itens);
        });
    }
    setIDs(idParents, itens) {
        itens.forEach((item, i) => {
            item.idParents = idParents;
            item.id = item.idParents[item.idParents.length - 1].concat('_', i.toString());
            if (item.subItens != null) {
                this.setIDs(item.idParents.concat(item.id), item.subItens);
                item.idChildren = item.subItens.map((si) => si.id);
            }
        });
    }
    onCloseMenu(event) {
        this.closeMenu.emit(event);
    }
    onMudancaExibicaoSideMenu(id) {
        // Se passar null, significa que está saindo de um side menu
        // remove então o último elemento (caso seja uma situação de
        // menus aninhados, voltará para o nível anterior)
        if (id == null) {
            this.idSideMenuVisivel.pop();
        }
        // passando um identificador, acrescenta id do side menu à pilha
        else {
            this.idSideMenuVisivel.push(id);
        }
    }
}
MenuComponent.ɵfac = function MenuComponent_Factory(t) { return new (t || MenuComponent)(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"])(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"])); };
MenuComponent.ɵcmp = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"])({ type: MenuComponent, selectors: [["br-menu"]], inputs: { tipoAgrupamentoMenu: "tipoAgrupamentoMenu", densidade: "densidade", visivel: "visivel", usuario: "usuario", grupos: "grupos", urlImagem: "urlImagem", titulo: "titulo", linksExternos: "linksExternos", exibeInformacaoLicenca: "exibeInformacaoLicenca", informacaoLicenca: "informacaoLicenca" }, outputs: { closeMenu: "closeMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 1, vars: 1, consts: [["id", "main-navigation", 3, "class", 4, "ngIf"], ["id", "main-navigation"], [1, "menu-container"], [1, "row"], [1, "col-sm-4", "col-lg-3"], [1, "menu-panel"], [1, "menu-header"], [1, "menu-close"], ["type", "button", "aria-label", "Fechar o menu", "data-dismiss", "menu", 1, "br-button", "circle", 3, "click"], ["aria-hidden", "true", 1, "fas", "fa-times"], [1, "menu-title"], ["alt", "logo", 3, "src"], [1, "menu-body"], [4, "ngFor", "ngForOf"], ["class", "menu-footer", 4, "ngIf"], ["data-dismiss", "menu", "tabindex", "0", 1, "menu-scrim"], [3, "grupo", "usuario", "closeMenu", "idSideMenuVisivel", "mudancaExibicaoSideMenu", 4, "ngIf"], [3, "grupo", "usuario", "closeMenu", "idSideMenuVisivel", "mudancaExibicaoSideMenu"], [1, "menu-footer"], ["class", "menu-links", 4, "ngIf"], [1, "menu-info"], [1, "text-center", "text-down-01"], [1, "menu-links"], ["target", "_blank", 3, "href"], [1, "mr-1"], ["aria-hidden", "true", 1, "fas", "fa-external-link-square-alt"]], template: function MenuComponent_Template(rf, ctx) { if (rf & 1) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"])(0, MenuComponent_div_0_Template, 17, 6, "div", 0);
    } if (rf & 2) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"])("ngIf", ctx.visivel);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], GrupoMenuExpansaoComponent, GrupoMenuRotulosComponent, GrupoMenuDividersComponent], styles: [".br-menu[_ngcontent-%COMP%]   .menu-header[_ngcontent-%COMP%]   .menu-title[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]    + *[_ngcontent-%COMP%] {\n        margin-left: var(--spacing-scale-base);\n      }", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(MenuComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'br-menu',
                templateUrl: './menu.component.html',
                styles: [
                    `
      .br-menu .menu-header .menu-title img + * {
        margin-left: var(--spacing-scale-base);
      }
    `,
                    `
      a {
        text-decoration: none;
        font-weight: normal;
      }
    `,
                ],
            }]
    }], function () { return [{ type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"] }]; }, { tipoAgrupamentoMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], densidade: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], visivel: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], usuario: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], closeMenu: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }], grupos: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], urlImagem: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], titulo: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], linksExternos: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], exibeInformacaoLicenca: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }], informacaoLicenca: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }] }); })();

class MenuModule {
}
MenuModule.ɵfac = function MenuModule_Factory(t) { return new (t || MenuModule)(); };
MenuModule.ɵmod = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"])({ type: MenuModule });
MenuModule.ɵinj = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"])({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"])(MenuModule, { declarations: [MenuComponent, ItemMenuComponent, GrupoMenuExpansaoComponent, GrupoMenuRotulosComponent, GrupoMenuDividersComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]], exports: [MenuComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"])(MenuModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [MenuComponent, ItemMenuComponent, GrupoMenuExpansaoComponent, GrupoMenuRotulosComponent, GrupoMenuDividersComponent],
                imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
                exports: [MenuComponent],
            }]
    }], null, null); })();

/*
 * Public API Surface of dsgov-components
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ }),

/***/ "4UVQ":
/*!**********************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/breadcrumb/item-breadcrumb.interface.ts ***!
  \**********************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "4yHK":
/*!*******************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/divider/divider/divider.component.ts ***!
  \*******************************************************************************************/
/*! exports provided: DividerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DividerComponent", function() { return DividerComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");



class DividerComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        //Vertical ou horizontal
        this.orientacao = '';
    }
}
DividerComponent.ɵfac = function DividerComponent_Factory(t) { return new (t || DividerComponent)(); };
DividerComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DividerComponent, selectors: [["br-divider"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 1, vars: 1, consts: [[3, "ngClass"]], template: function DividerComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "span", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.jc(ctx.ngClass, "br-divider", ctx.orientacao));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"]], encapsulation: 2 });


/***/ }),

/***/ "75Kr":
/*!***************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/redesSociais.json ***!
  \***************************************************************/
/*! exports provided: 0, 1, 2, 3, 4, default */
/***/ (function(module) {

module.exports = JSON.parse("[{\"classIconeFontAwesome\":\"fab fa-facebook-f\",\"texto\":\"Facebook\",\"url\":\"http://facebook.com/ancinegovbr\"},{\"classIconeFontAwesome\":\"fab fa-twitter\",\"texto\":\"Twitter\",\"url\":\"http://twitter.com/ancinegovbr\"},{\"classIconeFontAwesome\":\"fab fa-instagram\",\"texto\":\"Instagram\",\"url\":\"http://instagram.com/ancine\"},{\"classIconeFontAwesome\":\"fab fa-linkedin\",\"texto\":\"Linkedin\",\"url\":\"https://www.linkedin.com/company/ancine/\"},{\"classIconeFontAwesome\":\"fab fa-youtube\",\"texto\":\"Youtube\",\"url\":\"http://youtube.com/ancinegov\"}]");

/***/ }),

/***/ "77wy":
/*!**********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/item/item/item.component.ts ***!
  \**********************************************************************************/
/*! exports provided: ItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemComponent", function() { return ItemComponent; });
/* harmony import */ var _tipo_item_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../tipo-item.enum */ "0joH");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");




function ItemComponent_div_0_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainer"](0);
} }
function ItemComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ItemComponent_div_0_ng_container_1_Template, 1, 0, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", ctx_r0.jc(ctx_r0.ngClass, "br-item"))("disabled", ctx_r0.isDisabled ? "disabled" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngTemplateOutlet", _r4);
} }
function ItemComponent_div_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainer"](0);
} }
function ItemComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ItemComponent_div_1_ng_container_1_Template, 1, 0, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", ctx_r1.jc(ctx_r1.ngClass, "br-item"))("disabled", ctx_r1.isDisabled ? "disabled" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngTemplateOutlet", _r4);
} }
function ItemComponent_a_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainer"](0);
} }
function ItemComponent_a_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "a", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ItemComponent_a_2_ng_container_1_Template, 1, 0, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", ctx_r2.jc(ctx_r2.ngClass, "br-item"))("href", ctx_r2.href, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("target", ctx_r2.target)("disabled", ctx_r2.isDisabled ? "disabled" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngTemplateOutlet", _r4);
} }
function ItemComponent_br_button_3_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainer"](0);
} }
function ItemComponent_br_button_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "br-button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ItemComponent_br_button_3_ng_container_1_Template, 1, 0, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", ctx_r3.jc(ctx_r3.ngClass, "br-item"))("click", ctx_r3.click)("isActive", ctx_r3.isActive)("isDisabled", ctx_r3.isDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngTemplateOutlet", _r4);
} }
function ItemComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojection"](0);
} }
const _c0 = ["*"];
class ItemComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.PADRAO = _tipo_item_enum__WEBPACK_IMPORTED_MODULE_0__["TipoItem"].PADRAO;
        this.LINK = _tipo_item_enum__WEBPACK_IMPORTED_MODULE_0__["TipoItem"].LINK;
        this.BUTTON = _tipo_item_enum__WEBPACK_IMPORTED_MODULE_0__["TipoItem"].BUTTON;
        this.SELECTION = _tipo_item_enum__WEBPACK_IMPORTED_MODULE_0__["TipoItem"].SELECTION;
        this.tipoItem = this.PADRAO;
        /*** Os Estados são representados em propriedades específicas ***/
        //se true, aplica a classe 'disabled'
        this.isDisabled = false;
        //se true, aplica a classe 'active'
        this.isActive = false;
        //se true, Aplica estilo selecionado
        this.isSelected = false;
    }
}
ItemComponent.ɵfac = function ItemComponent_Factory(t) { return new (t || ItemComponent)(); };
ItemComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: ItemComponent, selectors: [["br-item"]], inputs: { href: "href", target: "target", tipoItem: "tipoItem", click: "click", divider: "divider", isDisabled: "isDisabled", isActive: "isActive", isSelected: "isSelected" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c0, decls: 6, vars: 4, consts: [["role", "listitem", 3, "ngClass", "disabled", 4, "ngIf"], ["data-toggle", "selection", "role", "listitem", 3, "ngClass", "disabled", 4, "ngIf"], [3, "ngClass", "href", "target", "disabled", 4, "ngIf"], ["role", "listitem", 3, "ngClass", "click", "isActive", "isDisabled", 4, "ngIf"], ["innerHTML", ""], ["role", "listitem", 3, "ngClass", "disabled"], [4, "ngTemplateOutlet"], ["data-toggle", "selection", "role", "listitem", 3, "ngClass", "disabled"], [3, "ngClass", "href", "target", "disabled"], ["role", "listitem", 3, "ngClass", "click", "isActive", "isDisabled"]], template: function ItemComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, ItemComponent_div_0_Template, 2, 3, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ItemComponent_div_1_Template, 2, 3, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, ItemComponent_a_2_Template, 2, 5, "a", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, ItemComponent_br_button_3_Template, 2, 5, "br-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, ItemComponent_ng_template_4_Template, 1, 0, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.tipoItem == ctx.PADRAO);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.tipoItem == ctx.SELECTION);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.tipoItem == ctx.LINK);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.tipoItem == ctx.BUTTON);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgClass"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgTemplateOutlet"]], styles: ["a[_ngcontent-%COMP%] {\n        text-decoration: none;\n      }"] });


/***/ }),

/***/ "8cX5":
/*!******************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/signin/signin.module.ts ***!
  \******************************************************************************/
/*! exports provided: SigninModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninModule", function() { return SigninModule; });
/* harmony import */ var _button_button_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../button/button.module */ "e18e");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _signin_signin_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./signin/signin.component */ "aAU5");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class SigninModule {
}
SigninModule.ɵfac = function SigninModule_Factory(t) { return new (t || SigninModule)(); };
SigninModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: SigninModule });
SigninModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SigninModule, { declarations: [_signin_signin_component__WEBPACK_IMPORTED_MODULE_2__["SigninComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"]], exports: [_signin_signin_component__WEBPACK_IMPORTED_MODULE_2__["SigninComponent"]] }); })();


/***/ }),

/***/ "91Fn":
/*!***************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/regra-exibicao-menu.enum.ts ***!
  \***************************************************************************************/
/*! exports provided: RegraExibicaoMenu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegraExibicaoMenu", function() { return RegraExibicaoMenu; });
class RegraExibicaoMenu {
}
RegraExibicaoMenu.SEMPRE = 'sempre';
RegraExibicaoMenu.LOGADO = 'logado';
RegraExibicaoMenu.NAO_LOGADO = 'naoLogado';


/***/ }),

/***/ "AZfE":
/*!******************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header-bottom/header-bottom.component.ts ***!
  \******************************************************************************************************/
/*! exports provided: HeaderBottomComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderBottomComponent", function() { return HeaderBottomComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");



class HeaderBottomComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        // texto do Título
        this.titulo = 'Título';
        // texto do Subtítulo
        this.subtitulo = 'Subtítulo';
        //texto do label do campo de pesquisa
        this.labelPesquisa = 'Texto da pesquisa';
        // Evento do clique para abrir o menu
        this.clickMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    onClickMenu(event) {
        this.clickMenu.emit(event);
    }
}
HeaderBottomComponent.ɵfac = function HeaderBottomComponent_Factory(t) { return new (t || HeaderBottomComponent)(); };
HeaderBottomComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: HeaderBottomComponent, selectors: [["br-header-bottom"]], inputs: { titulo: "titulo", subtitulo: "subtitulo", labelPesquisa: "labelPesquisa" }, outputs: { clickMenu: "clickMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 18, vars: 3, consts: [[1, "header-menu"], [1, "header-menu-trigger"], ["type", "button", "aria-label", "Menu", "data-toggle", "menu", "data-target", "#main-navigation", "id", "navigation", 1, "br-button", "small", "circle", 3, "click"], ["aria-hidden", "true", 1, "fas", "fa-bars"], [1, "header-info"], [1, "header-title"], [1, "header-subtitle"], [1, "header-search"], [1, "br-input", "has-icon"], ["for", "searchbox-56953"], ["id", "searchbox-56953", "type", "text", "placeholder", "O que voc\u00EA procura?", 1, "has-icon"], ["type", "button", "aria-label", "Pesquisar", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-search"], ["type", "button", "aria-label", "Fechar Busca", "data-dismiss", "search", 1, "br-button", "circle", "search-close", "ml-1"], ["aria-hidden", "true", 1, "fas", "fa-times"]], template: function HeaderBottomComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function HeaderBottomComponent_Template_button_click_2_listener($event) { return ctx.onClickMenu($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "i", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](13, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](17, "i", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.titulo);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.subtitulo);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.labelPesquisa);
    } }, encapsulation: 2 });


/***/ }),

/***/ "ApSJ":
/*!**********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/menu/menu.component.ts ***!
  \**********************************************************************************/
/*! exports provided: MenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony import */ var _base_logoGovBr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/logoGovBr */ "s3Ha");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../regra-exibicao-menu.enum */ "91Fn");
/* harmony import */ var _list_tipo_agrupamento_lista_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../list/tipo-agrupamento-lista.enum */ "h+bN");
/* harmony import */ var _base_densidade_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../base/densidade.enum */ "ICPe");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _grupo_menu_expansao_grupo_menu_expansao_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../grupo-menu-expansao/grupo-menu-expansao.component */ "lKyZ");
/* harmony import */ var _grupo_menu_rotulos_grupo_menu_rotulos_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../grupo-menu-rotulos/grupo-menu-rotulos.component */ "CwvZ");
/* harmony import */ var _grupo_menu_dividers_grupo_menu_dividers_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../grupo-menu-dividers/grupo-menu-dividers.component */ "mhda");












function MenuComponent_div_0_ng_container_14_br_grupo_menu_expansao_1_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "br-grupo-menu-expansao", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("mudancaExibicaoSideMenu", function MenuComponent_div_0_ng_container_14_br_grupo_menu_expansao_1_Template_br_grupo_menu_expansao_mudancaExibicaoSideMenu_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3); return ctx_r7.onMudancaExibicaoSideMenu($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const grupo_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("grupo", grupo_r3)("usuario", ctx_r4.usuario)("closeMenu", ctx_r4.closeMenu)("idSideMenuVisivel", ctx_r4.idSideMenuVisivel);
} }
function MenuComponent_div_0_ng_container_14_br_grupo_menu_rotulos_2_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "br-grupo-menu-rotulos", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("mudancaExibicaoSideMenu", function MenuComponent_div_0_ng_container_14_br_grupo_menu_rotulos_2_Template_br_grupo_menu_rotulos_mudancaExibicaoSideMenu_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3); return ctx_r10.onMudancaExibicaoSideMenu($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const grupo_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("grupo", grupo_r3)("usuario", ctx_r5.usuario)("closeMenu", ctx_r5.closeMenu)("idSideMenuVisivel", ctx_r5.idSideMenuVisivel);
} }
function MenuComponent_div_0_ng_container_14_br_grupo_menu_dividers_3_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "br-grupo-menu-dividers", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("mudancaExibicaoSideMenu", function MenuComponent_div_0_ng_container_14_br_grupo_menu_dividers_3_Template_br_grupo_menu_dividers_mudancaExibicaoSideMenu_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3); return ctx_r13.onMudancaExibicaoSideMenu($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const grupo_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("grupo", grupo_r3)("usuario", ctx_r6.usuario)("closeMenu", ctx_r6.closeMenu)("idSideMenuVisivel", ctx_r6.idSideMenuVisivel);
} }
function MenuComponent_div_0_ng_container_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, MenuComponent_div_0_ng_container_14_br_grupo_menu_expansao_1_Template, 1, 4, "br-grupo-menu-expansao", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, MenuComponent_div_0_ng_container_14_br_grupo_menu_rotulos_2_Template, 1, 4, "br-grupo-menu-rotulos", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, MenuComponent_div_0_ng_container_14_br_grupo_menu_dividers_3_Template, 1, 4, "br-grupo-menu-dividers", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.tipoAgrupamentoMenu == ctx_r1.AGRUPAMENTO_EXPANSAO);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.tipoAgrupamentoMenu == ctx_r1.AGRUPAMENTO_ROTULO);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.tipoAgrupamentoMenu == ctx_r1.AGRUPAMENTO_DIVIDER);
} }
function MenuComponent_div_0_div_15_div_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "a", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "i", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const link_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("href", link_r18.url, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](link_r18.texto);
} }
function MenuComponent_div_0_div_15_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, MenuComponent_div_0_div_15_div_1_ng_container_1_Template, 5, 2, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r16.linksExternos);
} }
function MenuComponent_div_0_div_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, MenuComponent_div_0_div_15_div_1_Template, 2, 1, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r2.linksExternos.length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx_r2.informacaoLicenca.label, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r2.informacaoLicenca.nomeLicenca);
} }
function MenuComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function MenuComponent_div_0_Template_button_click_7_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r20); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r19.onCloseMenu($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](8, "i", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "img", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "nav", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](14, MenuComponent_div_0_ng_container_14_Template, 4, 3, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](15, MenuComponent_div_0_div_15_Template, 7, 3, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx_r0.jc(ctx_r0.ngClass, "br-menu active", ctx_r0.densidade == "medium" ? "" : ctx_r0.densidade));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", ctx_r0.urlImagem || ctx_r0.base64LogoDefault, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.titulo);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.grupos);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.exibeInformacaoLicenca);
} }
class MenuComponent extends _base__WEBPACK_IMPORTED_MODULE_2__["BaseComponent"] {
    constructor(domSanitizer) {
        super();
        this.domSanitizer = domSanitizer;
        //constantes usadas no template
        this.SEMPRE = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_3__["RegraExibicaoMenu"].SEMPRE;
        this.LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_3__["RegraExibicaoMenu"].LOGADO;
        this.NAO_LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_3__["RegraExibicaoMenu"].NAO_LOGADO;
        this.AGRUPAMENTO_EXPANSAO = _list_tipo_agrupamento_lista_enum__WEBPACK_IMPORTED_MODULE_4__["TipoAgrupamentoLista"].EXPANSAO;
        this.AGRUPAMENTO_ROTULO = _list_tipo_agrupamento_lista_enum__WEBPACK_IMPORTED_MODULE_4__["TipoAgrupamentoLista"].ROTULO;
        this.AGRUPAMENTO_DIVIDER = _list_tipo_agrupamento_lista_enum__WEBPACK_IMPORTED_MODULE_4__["TipoAgrupamentoLista"].DIVIDER;
        // Tipo do agrupamento do menu
        this.tipoAgrupamentoMenu = _list_tipo_agrupamento_lista_enum__WEBPACK_IMPORTED_MODULE_4__["TipoAgrupamentoLista"].EXPANSAO;
        // Densidade dos itens de menu. Default: densidade normal
        this.densidade = _base_densidade_enum__WEBPACK_IMPORTED_MODULE_5__["Densidade"].MEDIA;
        // controle endógeno da exibição do menu
        this.visivel = false;
        // evento disparado quando o menu é fechado
        this.closeMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        //Links externos exibidos no menu, abaixo dos itens
        this.linksExternos = [];
        // Indica a exibição ou não da informação sobre licença no menu
        this.exibeInformacaoLicenca = true;
        // Label de apresentação e nome da licença utilizada
        this.informacaoLicenca = new _base__WEBPACK_IMPORTED_MODULE_2__["InformacaoLicenca"]();
        // Pilha com IDs de side-menus (um menu com subitens de um item) ativos no momento
        // o ID da ponta da pilha é em exibição no momento. Ao fechar o side-menu, ocorre
        // um POP nesta pilha
        this.idSideMenuVisivel = [];
        //logo gov.br
        this.base64LogoDefault = this.domSanitizer.bypassSecurityTrustUrl(_base_logoGovBr__WEBPACK_IMPORTED_MODULE_0__["base64LogoGovBr"]);
    }
    ngOnInit() {
        // setando ids para os grupos e itens de menu
        // utilizado no controle de exibição/ocultação de side-menus
        this.grupos.forEach((g, i) => {
            this.setIDs([i.toString()], g.itens);
        });
    }
    setIDs(idParents, itens) {
        itens.forEach((item, i) => {
            item.idParents = idParents;
            item.id = item.idParents[item.idParents.length - 1].concat('_', i.toString());
            if (item.subItens != null) {
                this.setIDs(item.idParents.concat(item.id), item.subItens);
                item.idChildren = item.subItens.map((si) => si.id);
            }
        });
    }
    onCloseMenu(event) {
        this.closeMenu.emit(event);
    }
    onMudancaExibicaoSideMenu(id) {
        // Se passar null, significa que está saindo de um side menu
        // remove então o último elemento (caso seja uma situação de
        // menus aninhados, voltará para o nível anterior)
        if (id == null) {
            this.idSideMenuVisivel.pop();
        }
        // passando um identificador, acrescenta id do side menu à pilha
        else {
            this.idSideMenuVisivel.push(id);
        }
    }
}
MenuComponent.ɵfac = function MenuComponent_Factory(t) { return new (t || MenuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"])); };
MenuComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: MenuComponent, selectors: [["br-menu"]], inputs: { tipoAgrupamentoMenu: "tipoAgrupamentoMenu", densidade: "densidade", visivel: "visivel", usuario: "usuario", grupos: "grupos", urlImagem: "urlImagem", titulo: "titulo", linksExternos: "linksExternos", exibeInformacaoLicenca: "exibeInformacaoLicenca", informacaoLicenca: "informacaoLicenca" }, outputs: { closeMenu: "closeMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 1, vars: 1, consts: [["id", "main-navigation", 3, "class", 4, "ngIf"], ["id", "main-navigation"], [1, "menu-container"], [1, "row"], [1, "col-sm-4", "col-lg-3"], [1, "menu-panel"], [1, "menu-header"], [1, "menu-close"], ["type", "button", "aria-label", "Fechar o menu", "data-dismiss", "menu", 1, "br-button", "circle", 3, "click"], ["aria-hidden", "true", 1, "fas", "fa-times"], [1, "menu-title"], ["alt", "logo", 3, "src"], [1, "menu-body"], [4, "ngFor", "ngForOf"], ["class", "menu-footer", 4, "ngIf"], ["data-dismiss", "menu", "tabindex", "0", 1, "menu-scrim"], [3, "grupo", "usuario", "closeMenu", "idSideMenuVisivel", "mudancaExibicaoSideMenu", 4, "ngIf"], [3, "grupo", "usuario", "closeMenu", "idSideMenuVisivel", "mudancaExibicaoSideMenu"], [1, "menu-footer"], ["class", "menu-links", 4, "ngIf"], [1, "menu-info"], [1, "text-center", "text-down-01"], [1, "menu-links"], ["target", "_blank", 3, "href"], [1, "mr-1"], ["aria-hidden", "true", 1, "fas", "fa-external-link-square-alt"]], template: function MenuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, MenuComponent_div_0_Template, 17, 6, "div", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.visivel);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgForOf"], _grupo_menu_expansao_grupo_menu_expansao_component__WEBPACK_IMPORTED_MODULE_8__["GrupoMenuExpansaoComponent"], _grupo_menu_rotulos_grupo_menu_rotulos_component__WEBPACK_IMPORTED_MODULE_9__["GrupoMenuRotulosComponent"], _grupo_menu_dividers_grupo_menu_dividers_component__WEBPACK_IMPORTED_MODULE_10__["GrupoMenuDividersComponent"]], styles: [".br-menu[_ngcontent-%COMP%]   .menu-header[_ngcontent-%COMP%]   .menu-title[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]    + *[_ngcontent-%COMP%] {\n        margin-left: var(--spacing-scale-base);\n      }", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });


/***/ }),

/***/ "B20u":
/*!****************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header/header.component.ts ***!
  \****************************************************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var _BRHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BRHeader */ "w11H");
/* harmony import */ var _tamanho_header_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../tamanho-header.enum */ "v7YH");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _header_logo_header_logo_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../header-logo/header-logo.component */ "05dn");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _header_actions_header_actions_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../header-actions/header-actions.component */ "S4R4");
/* harmony import */ var _header_bottom_header_bottom_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../header-bottom/header-bottom.component */ "AZfE");











class HeaderComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__["BaseComponent"] {
    constructor(component, domSanitizer) {
        super();
        this.component = component;
        this.domSanitizer = domSanitizer;
        // texto assinatura (texto ao lado direito da logo)
        this.textoAssinatura = 'Governo Federal';
        // texto do Título
        this.titulo = 'Título';
        // texto do Subtítulo
        this.subtitulo = 'Subtítulo';
        //texto do label do campo de pesquisa
        this.labelPesquisa = 'Texto da pesquisa';
        // links do cabeçalho
        this.links = [];
        // menu de funcionalidades do cabeçalho
        this.funcionalidades = [];
        // tamanho do header
        this.tamanhoHeader = _tamanho_header_enum__WEBPACK_IMPORTED_MODULE_1__["TamanhoHeader"].DEFAULT;
        // Evento do clique para abrir o menu
        this.clickMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        //Evento de click do botão entrar (login)
        this.clickEntrar = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        //Evento de click no botão sair
        this.clickSair = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        //logo gov.br
        this.base64LogoDefault = this.domSanitizer.bypassSecurityTrustUrl(_base__WEBPACK_IMPORTED_MODULE_4__["base64LogoGovBr"]);
    }
    ngOnInit() {
        this.headerDS = new _BRHeader__WEBPACK_IMPORTED_MODULE_0__["BRHeader"]('br-header', this.component.nativeElement);
    }
    onClickMenu(event) {
        this.clickMenu.emit(event);
    }
    onClickEntrar(event) {
        this.clickEntrar.emit(event);
    }
    onClickSair(event) {
        this.clickSair.emit(event);
    }
}
HeaderComponent.ɵfac = function HeaderComponent_Factory(t) { return new (t || HeaderComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["DomSanitizer"])); };
HeaderComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: HeaderComponent, selectors: [["br-header"]], inputs: { urlImagem: "urlImagem", textoAssinatura: "textoAssinatura", titulo: "titulo", subtitulo: "subtitulo", labelPesquisa: "labelPesquisa", links: "links", funcionalidades: "funcionalidades", tamanhoHeader: "tamanhoHeader", usuario: "usuario" }, outputs: { clickMenu: "clickMenu", clickEntrar: "clickEntrar", clickSair: "clickSair" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵInheritDefinitionFeature"]], decls: 6, vars: 10, consts: [["id", "header"], [1, "container-fluid"], [1, "header-top"], ["ngClass", "header-logo", 3, "logo", "textoAssinatura"], ["ngClass", "header-actions", 3, "usuario", "links", "funcionalidades", "clickEntrar", "clickSair"], ["ngClass", "header-bottom", 3, "titulo", "subtitulo", "labelPesquisa", "clickMenu"]], template: function HeaderComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "br-header-logo", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "br-header-actions", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("clickEntrar", function HeaderComponent_Template_br_header_actions_clickEntrar_4_listener($event) { return ctx.onClickEntrar($event); })("clickSair", function HeaderComponent_Template_br_header_actions_clickSair_4_listener($event) { return ctx.onClickSair($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "br-header-bottom", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("clickMenu", function HeaderComponent_Template_br_header_bottom_clickMenu_5_listener($event) { return ctx.onClickMenu($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"]("br-header " + ctx.tamanhoHeader);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("logo", ctx.urlImagem || ctx.base64LogoDefault)("textoAssinatura", ctx.textoAssinatura);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("usuario", ctx.usuario)("links", ctx.links)("funcionalidades", ctx.funcionalidades);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("titulo", ctx.titulo)("subtitulo", ctx.subtitulo)("labelPesquisa", ctx.labelPesquisa);
    } }, directives: [_header_logo_header_logo_component__WEBPACK_IMPORTED_MODULE_6__["HeaderLogoComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgClass"], _header_actions_header_actions_component__WEBPACK_IMPORTED_MODULE_8__["HeaderActionsComponent"], _header_bottom_header_bottom_component__WEBPACK_IMPORTED_MODULE_9__["HeaderBottomComponent"]], encapsulation: 2 });


/***/ }),

/***/ "CMe2":
/*!*****************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/link.interface.ts ***!
  \*****************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "CXQa":
/*!******************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header.module.ts ***!
  \******************************************************************************/
/*! exports provided: HeaderModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderModule", function() { return HeaderModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _button_button_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../button/button.module */ "e18e");
/* harmony import */ var _divider_divider_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../divider/divider.module */ "0QCI");
/* harmony import */ var _signin_signin_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../signin/signin.module */ "8cX5");
/* harmony import */ var _header_actions_header_actions_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./header-actions/header-actions.component */ "S4R4");
/* harmony import */ var _header_bottom_header_bottom_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header-bottom/header-bottom.component */ "AZfE");
/* harmony import */ var _header_functions_header_functions_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./header-functions/header-functions.component */ "oH45");
/* harmony import */ var _header_links_header_links_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./header-links/header-links.component */ "vBmv");
/* harmony import */ var _header_login_header_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./header-login/header-login.component */ "w0x5");
/* harmony import */ var _header_logo_header_logo_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./header-logo/header-logo.component */ "05dn");
/* harmony import */ var _header_search_trigger_header_search_trigger_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./header-search-trigger/header-search-trigger.component */ "feFs");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./header/header.component */ "B20u");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ "fXoL");













class HeaderModule {
}
HeaderModule.ɵfac = function HeaderModule_Factory(t) { return new (t || HeaderModule)(); };
HeaderModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineNgModule"]({ type: HeaderModule });
HeaderModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _divider_divider_module__WEBPACK_IMPORTED_MODULE_2__["DividerModule"], _signin_signin_module__WEBPACK_IMPORTED_MODULE_3__["SigninModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_1__["ButtonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵsetNgModuleScope"](HeaderModule, { declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_11__["HeaderComponent"],
        _header_logo_header_logo_component__WEBPACK_IMPORTED_MODULE_9__["HeaderLogoComponent"],
        _header_actions_header_actions_component__WEBPACK_IMPORTED_MODULE_4__["HeaderActionsComponent"],
        _header_links_header_links_component__WEBPACK_IMPORTED_MODULE_7__["HeaderLinksComponent"],
        _header_functions_header_functions_component__WEBPACK_IMPORTED_MODULE_6__["HeaderFunctionsComponent"],
        _header_search_trigger_header_search_trigger_component__WEBPACK_IMPORTED_MODULE_10__["HeaderSearchTriggerComponent"],
        _header_login_header_login_component__WEBPACK_IMPORTED_MODULE_8__["HeaderLoginComponent"],
        _header_bottom_header_bottom_component__WEBPACK_IMPORTED_MODULE_5__["HeaderBottomComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _divider_divider_module__WEBPACK_IMPORTED_MODULE_2__["DividerModule"], _signin_signin_module__WEBPACK_IMPORTED_MODULE_3__["SigninModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_1__["ButtonModule"]], exports: [_header_header_component__WEBPACK_IMPORTED_MODULE_11__["HeaderComponent"]] }); })();


/***/ }),

/***/ "CwvZ":
/*!**************************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/grupo-menu-rotulos/grupo-menu-rotulos.component.ts ***!
  \**************************************************************************************************************/
/*! exports provided: GrupoMenuRotulosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GrupoMenuRotulosComponent", function() { return GrupoMenuRotulosComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../regra-exibicao-menu.enum */ "91Fn");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../item-menu/item-menu.component */ "vyIX");






function GrupoMenuRotulosComponent_div_1_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "i", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx_r2.grupo.classIconeFontAwesome);
} }
const _c0 = function () { return { cursor: "pointer" }; };
function GrupoMenuRotulosComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function GrupoMenuRotulosComponent_div_1_Template_div_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r3.onClickComponent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, GrupoMenuRotulosComponent_div_1_span_1_Template, 2, 2, "span", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngStyle", ctx_r0.grupo.click != null ? _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](3, _c0) : ctx_r0._);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.grupo.classIconeFontAwesome);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.grupo.texto);
} }
function GrupoMenuRotulosComponent_ng_container_3_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "br-item-menu", 9);
} if (rf & 2) {
    const item_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("item", item_r5)("closeMenu", ctx_r6.closeMenu)("mudancaExibicaoSideMenu", ctx_r6.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r6.idSideMenuVisivel);
} }
function GrupoMenuRotulosComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, GrupoMenuRotulosComponent_ng_container_3_br_item_menu_1_Template, 1, 4, "br-item-menu", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const item_r5 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", item_r5.exibicao == null || item_r5.exibicao == ctx_r1.SEMPRE || item_r5.exibicao == ctx_r1.LOGADO && ctx_r1.usuario != null || item_r5.exibicao == ctx_r1.NAO_LOGADO && ctx_r1.usuario == null);
} }
class GrupoMenuRotulosComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].SEMPRE;
        this.LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].LOGADO;
        this.NAO_LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].NAO_LOGADO;
        // o EventEmitter de fechamento do menu é passado para os grupos a fim de que seja chamado
        // quando um item de menu de rota (sem uma função que trate o click) for clicado
        this.closeMenu = null;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    // havendo uma função a ser acionada no click do grupo, também é invocada
    onClickComponent(event) {
        //Se o grupo tiver uma função associada ao atributo 'click', invoca-a
        if (this.grupo.click) {
            this.grupo.click(this.grupo);
        }
    }
}
GrupoMenuRotulosComponent.ɵfac = function GrupoMenuRotulosComponent_Factory(t) { return new (t || GrupoMenuRotulosComponent)(); };
GrupoMenuRotulosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: GrupoMenuRotulosComponent, selectors: [["br-grupo-menu-rotulos"]], inputs: { grupo: "grupo", usuario: "usuario", closeMenu: "closeMenu", idSideMenuVisivel: "idSideMenuVisivel" }, outputs: { mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 4, vars: 2, consts: [[1, "menu-folder", "divisor-menu"], ["class", "menu-item", 3, "ngStyle", "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "menu-item", 3, "ngStyle", "click"], ["class", "icon", 4, "ngIf"], [1, "content"], [1, "icon"], ["aria-hidden", "true"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function GrupoMenuRotulosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, GrupoMenuRotulosComponent_div_1_Template, 4, 4, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, GrupoMenuRotulosComponent_ng_container_3_Template, 2, 1, "ng-container", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.idSideMenuVisivel.length == 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.grupo.itens);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgStyle"], _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_4__["ItemMenuComponent"]], styles: ["div.divisor-menu.menu-folder[_ngcontent-%COMP%] {\n    border-bottom: 1px solid var(--menu-divider);", "div.divisor-menu.menu-folder[_ngcontent-%COMP%]   div.menu-item[_ngcontent-%COMP%] {\n    color: black;", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });


/***/ }),

/***/ "DAld":
/*!********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/usuario.interface.ts ***!
  \********************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "E5bW":
/*!***********************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/app.module.ts ***!
  \***********************************************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _dsgov_dsgov_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dsgov/dsgov.module */ "yJbv");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ "U6H2");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "p1lB");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");





class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ providers: [], imports: [[_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"], _dsgov_dsgov_module__WEBPACK_IMPORTED_MODULE_0__["DsgovModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"], _dsgov_dsgov_module__WEBPACK_IMPORTED_MODULE_0__["DsgovModule"]] }); })();


/***/ }),

/***/ "EbzX":
/*!*****************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/linksCabecalho.json ***!
  \*****************************************************************/
/*! exports provided: 0, 1, 2, 3, default */
/***/ (function(module) {

module.exports = JSON.parse("[{\"tipo\":\"url\",\"novaAba\":true,\"texto\":\"ANS\",\"url\":\"http://ans.gov.br\"},{\"tipo\":\"url\",\"novaAba\":true,\"texto\":\"ANP\",\"url\":\"http://anp.gov.br\"},{\"tipo\":\"url\",\"novaAba\":true,\"texto\":\"ANATEL\",\"url\":\"http://anatel.gov.br\"},{\"tipo\":\"url\",\"novaAba\":true,\"texto\":\"ANVISA\",\"url\":\"http://anvisa.gov.br\"}]");

/***/ }),

/***/ "G30h":
/*!****************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/footer/grupo-footer/grupo-footer.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: GrupoFooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GrupoFooterComponent", function() { return GrupoFooterComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _item_item_item_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../item/item/item.component */ "77wy");




function GrupoFooterComponent_div_6_br_item_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "br-item", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("href", item_r2.url);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r2.texto);
} }
function GrupoFooterComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, GrupoFooterComponent_div_6_br_item_1_Template, 3, 2, "br-item", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.links);
} }
class GrupoFooterComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        this.links = [];
        //Indica se o grupo de menu está expandido ou colapsado
        this.expandido = true;
    }
    ngOnInit() {
        //pegando tamanho da tela/janela
        this.windowWidth = window.innerWidth > 0 ? window.innerWidth : screen.width;
    }
    /**
     * Atualiza o atributo do tamanho da janela ao redimensionar a janela
     * @param event
     */
    onResize(event) {
        this.windowWidth = window.innerWidth;
    }
    // o click no grupo inverte a condição de expandido ou não do próprio componente de Grupo
    onClickComponent(event) {
        // aplica-se apenas para telas menores que 992 pois, no CSS, o ícone
        // de seta é exibido apenas em telas menores que isto:
        /*
        .br-footer .br-list.horizontal .br-item .support:last-child {
          display: none;
          pointer-events: none;
        }
        */
        if (this.windowWidth < 992) {
            this.expandido = !this.expandido;
        }
    }
}
GrupoFooterComponent.ɵfac = function GrupoFooterComponent_Factory(t) { return new (t || GrupoFooterComponent)(); };
GrupoFooterComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: GrupoFooterComponent, selectors: [["br-grupo-footer"]], hostBindings: function GrupoFooterComponent_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("resize", function GrupoFooterComponent_resize_HostBindingHandler($event) { return ctx.onResize($event); }, false, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresolveWindow"]);
    } }, inputs: { horizontal: "horizontal", grupo: "grupo", links: "links", expandido: "expandido" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 7, vars: 6, consts: [[1, "col"], ["href", "javascript:void(0)", 3, "click"], [1, "content", "text-down-01", "text-bold", "text-uppercase"], [1, "support"], ["aria-hidden", "true"], ["class", "br-list open", 4, "ngIf"], [1, "br-list", "open"], ["tipoItem", "link", "target", "_blank", 3, "href", 4, "ngFor", "ngForOf"], ["tipoItem", "link", "target", "_blank", 3, "href"], [1, "content"]], template: function GrupoFooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function GrupoFooterComponent_Template_a_click_1_listener($event) { return ctx.onClickComponent($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "i", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, GrupoFooterComponent_div_6_Template, 2, 1, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.expandido ? "br-item header open" : "br-item header");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx.grupo, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.expandido ? "fas fa-angle-up" : "fas fa-angle-down");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.expandido);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], _item_item_item_component__WEBPACK_IMPORTED_MODULE_3__["ItemComponent"]], styles: ["a[_ngcontent-%COMP%] {\n        text-decoration: none;\n      }"] });


/***/ }),

/***/ "H/oc":
/*!************************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/usuario/usuario.service.ts ***!
  \************************************************************************/
/*! exports provided: UsuarioService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuarioService", function() { return UsuarioService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


class UsuarioService {
    constructor() {
        this.userSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"](null);
    }
    getUsuario() {
        const usuarioTeste = {
            jti: 'teste',
            upn: 'jose.silva',
            groups: [],
            exp: new Date().getTime(),
            nomeCompleto: 'José da Silva',
            email: 'josedasilva@dsgov.br',
            imgAvatar: 'data:image/jpeg;base64,/9j/4QBKRXhpZgAATU0AKgAAAAgAAwEaAAUAAAABAAAAMgEbAAUAAAABAAAAOgEoAAMAAAABAAIAAAAAAAAAAAEsAAAAAQAAASwAAAAB/9sAQwAGBAUGBQQGBgUGBwcGCAoQCgoJCQoUDg8MEBcUGBgXFBYWGh0lHxobIxwWFiAsICMmJykqKRkfLTAtKDAlKCko/9sAQwEHBwcKCAoTCgoTKBoWGigoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgo/8IAEQgAZgBmAwEiAAIRAQMRAf/EABsAAAEFAQEAAAAAAAAAAAAAAAACAwQFBgEH/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAEDAgT/2gAMAwEAAhADEAAAAdiCeWjeBYptjmgcglPQ5XknqmcPnDDVzvA4KGmULaF4xsq2HS11AdezZx1uGs+krqLLMHlNqEo4A20poMnXabDaqP1Wj3qq5fUQvQbKrsZSfU0tJZwQ226ljGW1rLfk021wN3eQot0Ho1tltXB9UnqysQApIsTTc6ulTKZb0bG11Tzh/dZd7VWeVoXam2OZQkEibXzp7Q2qZy1h43dUXTjKOznrXRZszyT9qkjKAPlFBmBPSJActexQ2RooX57KeDfYwSp0CuP/xAAmEAACAgECBQUBAQAAAAAAAAABAgADBBESBRAgISIGExQxMiMw/9oACAEBAAEFAuV1qU15PqA714xma4XHiWx7kvr/AMPUeW/vYmBviY6qLMauwYeS/DshHDr1E9kDX56EAX2F66iwFuOLa+G5VuNUp1HSZxBPjcVO1pQwrrptFjG/RrX0twW1xx0mcep3VY4QLegssJpqFqnfafDB0+KOkziNb2Y2/bCre5jfGx1Dh5muswxsxoOkzP4ebIj+3YL61l+ZuCE2W8NbdjDqM0nqDH15IusxqtDwuwI3MDy5aax+y5u66s46gsukq7RJjXukRw45qNSe0uHuvm0/x2zb5KO9SxEi6pCNOadpb9UpLl1S+sBhXBXKqxERZWgM2+LeJH618n/Q+jMundAvf24lcSjWIm0M2kfvB+j9L3IPY/R/VlMC6GqrWVqIT5P5WGf/xAAeEQACAgIDAQEAAAAAAAAAAAAAAQIRECEDEiATMf/aAAgBAwEBPwEScvw+T9cWsOKY1Xjjw9eUd2iNydklT8KJHehRoaTJKnWI4vq7LJTSEr2yiGZaYs//xAAcEQACAgMBAQAAAAAAAAAAAAAAAQIRAxAgITH/2gAIAQIBAT8BEl9ZaHxZL3m+XxZFWSpD4lMxsbvjJ4XbIS18JS9EzLpEWPSP/8QAKxAAAQMCBQIFBQEAAAAAAAAAAQACEQMxEBIgIVETQSIwYXGBBDJCUmJy/9oACAEBAAY/AsDUqGGhEfT0xl5cjFQn4Qb9U0AfsFnpmR5PQB8EDZB1W3C8LQvt+Qhc0TcIOaZB3Gso9S+aStzCPT2HKyjb/S8V02jUbma10T6eQY/NshHYufyg2qUcjI9XKHbFNLTdCe2tldt6R39lKbvLuFu4ud6JvhMuwplvcTrcKZg391lK7kHhbDM/9nBZogI5VRb/AD5BNGJ4RZVEEK0qG2QQ9PJZVF7Yyi1xvonQTwiT9nZWUDGDu1SNXT/G5RA41S35Gn3Rce+EaLqQt1CCGiRdQdjjJtoGE4wbLaPldlvhCA43w//EACMQAQACAgIDAAMAAwAAAAAAAAEAESExEFFBYXEggZGx0eH/2gAIAQEAAT8h4J2e1YegmDb9qDaw7DUbiMU6+k3IqXyfiyzG3PqOV0sg3K2cPUZXAPq5/wB/sqvOzs4ueOSJi3WIx3brPstx9IXJ8ghmmnnT9dzXnRIBBLJkkARsc/isE+pw9zUgbbqUSb1DJK6LfyDRkGrDVjk2VTaD3Lgx1NYhe/7SWSHdxwyFy0ESUz9SFUHJluyripdf7ll5Q5RQYPCxSom6dOpjdBqNQYP2rzAnfPQOqgigOnUZTy1ANboEL/CxILm/RmzUREZVPiZFs9xdBtFN0Nza84cCEI82CIKpZiurYnjKRyk4a/Ya5yLOqrm0UcaI0rOnfuXQiwaJ4JcZtDqdk8VeDmgIqANmn7fUsO9I95ddE8uW8WCV2/SJvqEuGgR1Q2qidh3L/siOnyZFqd08lgNw4ZAiWkBWH/SFPpFZPbMATWaZRcTTPQwyhXCeT0hB/iVrYMVJre5v7Ij+7gDygLBajbSISmp30V6IDJNN4i6XJ7in/9oADAMBAAIAAwAAABDB5GxyD3WCF4GLAyIKCQ89at2HkQIWE9H8wAjMmNYLCCMJ3yL/AP/EAB0RAQEBAAIDAQEAAAAAAAAAAAEAESExECBBUWH/2gAIAQMBAT8Q2ayZG7YnD65HHc5OC2zLLPHE21XgmiVXXxl3L4SfIEXXpAfl+sR6+QdIjHyQ/Z6j+NZeS5lkTT4CwY9ETdvk3//EABsRAAMBAQEBAQAAAAAAAAAAAAABESExEFFh/9oACAECAQE/EBJA+cFmjeiZfDY+eV8Gt8gtE6khqdKnh2UgkKBC0YNMXlhTEPkOQ/CQgzSIQFrDo2tMpgotOxdGHQdwfTg//8QAJBABAAICAgICAwADAAAAAAAAAQARITFBUWFxgaEQkcGx0fD/2gAIAQEAAT8QCvx/IShjt8Q4OxBW9Br0yyYLoAdBWJnfwcbb6O6lEWOndO/U8cQLlskDzEVfw5ZY1GJakFobu/qKdLRZHmCS9TusqkFUKREj8SdFPDoQXI4dJkYOLmjUHGGyJcsYYNQpXyrEIemvFFiDaU0HbK2srBahKBozQ8DKgo0LFSPcRhYWYcJ4L/UGGCiOxg9QWi/iVuDf4gtFw7hNLQZG1v7IipzrheOD1lg82VGreo9EaBhXtFF0cNjGnBOIR6HxAQpZzx/zOa2IbYh+sqWY2iLsUzaALbi34afmLGBUrO8/2B+gjlW41Yzzqjg6hB3qUUWVeCZT0edmxKXW+7KmfuJLN5IEW2bs4ndqPtqKlhbfsiL8CHDFQrdmRS2l81E8GCsq4BprbuXdusAHLQQPyg7Y1CjIWOMzqisLmMVqE6dwEfEW3BCHWMNR5p6iBpLaoakLmEoDNg5hiqCkE2SrPGz/ADFb4mEVkXBxDUcw0e5mxcGFeIUqZLmfY+Y9dk7qby1xCGGFugQ7cQG74/DcyPRvfuILUqLMDRCLhWrM31ZzPB/iUhrd5lJ66BNXSZEq5SdbS/QwQyprWR6gvEdMWPUYDc00Dcp4Fixa8enMwkiyvCZiXQSyLNMOo9qN7iDLNFS3hIdH/ZxKqjbTLM6m4TGV3B4yf2y0fWeDiPUOQ8w30rNunU7MYQlC+5YMPqDioTI57PLN11N9R0W1p8T9VjgdMLgsN9RghoCO6JiDcFlnQjwyxMDYUwvWKsj6hGx5NxvCsY6QHua0G1iBsfca94S6l0tj6gBGiHw+ZZdWxIbdGLfFItPmXCxxhjmvDkq+pa3NYLivCzb5ji4H2GHeBn//2Q==',
        };
        this.userSubject.next(usuarioTeste);
        //retornando observable, é possível fazer um subscribe
        return this.userSubject.asObservable();
    }
    logout() { }
}
UsuarioService.ɵfac = function UsuarioService_Factory(t) { return new (t || UsuarioService)(); };
UsuarioService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: UsuarioService, factory: UsuarioService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "HJ80":
/*!**************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/item/item.module.ts ***!
  \**************************************************************************/
/*! exports provided: ItemModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemModule", function() { return ItemModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _item_item_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./item/item.component */ "77wy");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



class ItemModule {
}
ItemModule.ɵfac = function ItemModule_Factory(t) { return new (t || ItemModule)(); };
ItemModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ItemModule });
ItemModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ItemModule, { declarations: [_item_item_component__WEBPACK_IMPORTED_MODULE_1__["ItemComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]], exports: [_item_item_component__WEBPACK_IMPORTED_MODULE_1__["ItemComponent"]] }); })();


/***/ }),

/***/ "ICPe":
/*!*****************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/densidade.enum.ts ***!
  \*****************************************************************************/
/*! exports provided: Densidade */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Densidade", function() { return Densidade; });
class Densidade {
}
Densidade.ALTA = 'small';
Densidade.MEDIA = 'medium';
Densidade.BAIXA = 'large';


/***/ }),

/***/ "IVym":
/*!***************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/funcionalidade.interface.ts ***!
  \***************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "JaEA":
/*!**************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/usuario/index.ts ***!
  \**************************************************************/
/*! exports provided: UsuarioService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _usuario_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./usuario.service */ "H/oc");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UsuarioService", function() { return _usuario_service__WEBPACK_IMPORTED_MODULE_0__["UsuarioService"]; });




/***/ }),

/***/ "KFZd":
/*!********************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/index.ts ***!
  \********************************************************************/
/*! exports provided: InformacaoLicenca, BaseComponent, Densidade, base64LogoGovBr, TipoLink */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _informacao_licenca__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./informacao-licenca */ "slRD");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InformacaoLicenca", function() { return _informacao_licenca__WEBPACK_IMPORTED_MODULE_0__["InformacaoLicenca"]; });

/* harmony import */ var _usuario_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./usuario.interface */ "DAld");
/* empty/unused harmony star reexport *//* harmony import */ var _base_base_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base/base.component */ "qsoC");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BaseComponent", function() { return _base_base_component__WEBPACK_IMPORTED_MODULE_2__["BaseComponent"]; });

/* harmony import */ var _densidade_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./densidade.enum */ "ICPe");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Densidade", function() { return _densidade_enum__WEBPACK_IMPORTED_MODULE_3__["Densidade"]; });

/* harmony import */ var _link_interface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./link.interface */ "CMe2");
/* empty/unused harmony star reexport *//* harmony import */ var _logoGovBr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./logoGovBr */ "s3Ha");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "base64LogoGovBr", function() { return _logoGovBr__WEBPACK_IMPORTED_MODULE_5__["base64LogoGovBr"]; });

/* harmony import */ var _tipo_link_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tipo-link.enum */ "T+sX");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TipoLink", function() { return _tipo_link_enum__WEBPACK_IMPORTED_MODULE_6__["TipoLink"]; });

/* harmony import */ var _funcionalidade_interface__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./funcionalidade.interface */ "IVym");
/* empty/unused harmony star reexport */









/***/ }),

/***/ "KeFx":
/*!**************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/base.module.ts ***!
  \**************************************************************************/
/*! exports provided: BaseModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseModule", function() { return BaseModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _base_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



class BaseModule {
}
BaseModule.ɵfac = function BaseModule_Factory(t) { return new (t || BaseModule)(); };
BaseModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: BaseModule });
BaseModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](BaseModule, { declarations: [_base_base_component__WEBPACK_IMPORTED_MODULE_1__["BaseComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]] }); })();


/***/ }),

/***/ "NcNF":
/*!*********************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/rodape.json ***!
  \*********************************************************/
/*! exports provided: Órgãos de Controle, Cinema Nacional, Agentes Financeiros, Consultas, Outros sistemas, Participação Popular, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"Órgãos de Controle\":[{\"texto\":\"TCU\",\"url\":\"http://tcu.gov.br\"},{\"texto\":\"Ministério Público\",\"url\":\"http://mp.gov.br\"}],\"Cinema Nacional\":[{\"texto\":\"Cinemateca\",\"url\":\"http://cinemateca.gov.br\"},{\"texto\":\"Embrafilmes\",\"url\":\"http://embrafilmes.gov.br\"},{\"texto\":\"CSC\",\"url\":\"http://csc.gov.br\"},{\"texto\":\"Instituto Lente\",\"url\":\"http://lente.org.br\"},{\"texto\":\"FSA\",\"url\":\"http://fsa.gov.br\"}],\"Agentes Financeiros\":[{\"texto\":\"Banco do Brasil\",\"url\":\"http://bb.gov.br\"},{\"texto\":\"BRDE\",\"url\":\"http://brde.gov.br\"},{\"texto\":\"BNDES\",\"url\":\"http://bndes.gov.br\"},{\"texto\":\"Bradesco\",\"url\":\"http://bradesco.com.br\"}],\"Consultas\":[{\"texto\":\"Projetos\",\"url\":\"http://gov.br/ancine\"},{\"texto\":\"Empresas Registradas\",\"url\":\"http://gov.br/ancine\"},{\"texto\":\"Situação Cadastral\",\"url\":\"http://gov.br/ancine\"},{\"texto\":\"CRT Obras Publicitárias\",\"url\":\"http://gov.br/ancine\"},{\"texto\":\"CTR Obras não Publicitárias\",\"url\":\"http://gov.br/ancine\"},{\"texto\":\"CPB\",\"url\":\"http://gov.br/ancine\"},{\"texto\":\"ROE\",\"url\":\"http://gov.br/ancine\"}],\"Outros sistemas\":[{\"texto\":\"SAVI\",\"url\":\"http://sad.ancine.gov.br/sadis\"},{\"texto\":\"Cota de Tela\",\"url\":\"http://sad.ancine.gov.br/cota\"},{\"texto\":\"SICA\",\"url\":\"http://sad.ancine.gov.br/sica\"},{\"texto\":\"RPPF\",\"url\":\"http://sad.ancine.gov.br/rppf\"}],\"Participação Popular\":[{\"texto\":\"Chamada Pública\",\"url\":\"http://sad.ancine.gov.br/chapub\"},{\"texto\":\"Ouvidoria\",\"url\":\"http://gov.br/ancine\"}]}");

/***/ }),

/***/ "PISc":
/*!*********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/input/estado-input.enum.ts ***!
  \*********************************************************************************/
/*! exports provided: EstadoInput */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EstadoInput", function() { return EstadoInput; });
class EstadoInput {
}
EstadoInput.DEFAULT = '';
EstadoInput.SUCCESS = 'success';
EstadoInput.DANGER = 'danger';
EstadoInput.WARNING = 'warning';
EstadoInput.INFO = 'info';


/***/ }),

/***/ "R1os":
/*!****************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/breadcrumb/breadcrumb/breadcrumb.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: BreadcrumbComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbComponent", function() { return BreadcrumbComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");




function BreadcrumbComponent_ng_container_7_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "li", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "i", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r1.label);
} }
function BreadcrumbComponent_ng_container_7_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "li", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "i", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "a", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", item_r1.link);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r1.label);
} }
function BreadcrumbComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, BreadcrumbComponent_ng_container_7_ng_container_1_Template, 5, 1, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, BreadcrumbComponent_ng_container_7_ng_template_2_Template, 4, 2, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const i_r2 = ctx.index;
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](3);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", i_r2 == ctx_r0.itens.length - 1)("ngIfElse", _r4);
} }
class BreadcrumbComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        this.labelPaginaInicial = 'Página inicial';
        this.linkPaginaInicial = '/';
        this.itens = [];
    }
    ngOnInit() { }
}
BreadcrumbComponent.ɵfac = function BreadcrumbComponent_Factory(t) { return new (t || BreadcrumbComponent)(); };
BreadcrumbComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: BreadcrumbComponent, selectors: [["br-breadcrumb"]], inputs: { labelPaginaInicial: "labelPaginaInicial", linkPaginaInicial: "linkPaginaInicial", itens: "itens" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 8, vars: 3, consts: [["aria-label", "Breadcumb", 1, "br-breadcrumb"], [1, "crumb-list"], [1, "crumb", "home", 3, "routerLink"], [1, "br-button", "circle"], [1, "sr-only"], [1, "icon", "fas", "fa-home"], [4, "ngFor", "ngForOf"], [4, "ngIf", "ngIfElse"], ["breadcrumAncestral", ""], ["data-active", "active", 1, "crumb"], [1, "icon", "fas", "fa-chevron-right"], [1, "crumb"], [3, "routerLink"]], template: function BreadcrumbComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ul", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "li", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "i", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, BreadcrumbComponent_ng_container_7_Template, 4, 2, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", ctx.linkPaginaInicial);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.labelPaginaInicial);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.itens);
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLink"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLinkWithHref"]], encapsulation: 2 });


/***/ }),

/***/ "S4R4":
/*!********************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header-actions/header-actions.component.ts ***!
  \********************************************************************************************************/
/*! exports provided: HeaderActionsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderActionsComponent", function() { return HeaderActionsComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _header_links_header_links_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../header-links/header-links.component */ "vBmv");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../divider/divider/divider.component */ "4yHK");
/* harmony import */ var _header_functions_header_functions_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../header-functions/header-functions.component */ "oH45");
/* harmony import */ var _header_search_trigger_header_search_trigger_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../header-search-trigger/header-search-trigger.component */ "feFs");
/* harmony import */ var _header_login_header_login_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../header-login/header-login.component */ "w0x5");









class HeaderActionsComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        this.links = [];
        this.funcionalidades = [];
        //Evento de click do botão entrar (login)
        this.clickEntrar = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        //Evento de click no botão sair
        this.clickSair = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    onClickEntrar(event) {
        this.clickEntrar.emit(event);
    }
    onClickSair(event) {
        this.clickSair.emit(event);
    }
}
HeaderActionsComponent.ɵfac = function HeaderActionsComponent_Factory(t) { return new (t || HeaderActionsComponent)(); };
HeaderActionsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: HeaderActionsComponent, selectors: [["br-header-actions"]], inputs: { links: "links", funcionalidades: "funcionalidades", usuario: "usuario" }, outputs: { clickEntrar: "clickEntrar", clickSair: "clickSair" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 5, vars: 3, consts: [["ngClass", "header-links dropdown", 3, "links"], ["ngClass", "br-divider vertical"], ["ngClass", "header-functions dropdown", 3, "funcionalidades"], ["ngClass", "header-search-trigger"], ["ngClass", "header-login", 3, "usuario", "clickEntrar", "clickSair"]], template: function HeaderActionsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "br-header-links", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "br-divider", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "br-header-functions", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "br-header-search-trigger", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "br-header-login", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("clickEntrar", function HeaderActionsComponent_Template_br_header_login_clickEntrar_4_listener($event) { return ctx.onClickEntrar($event); })("clickSair", function HeaderActionsComponent_Template_br_header_login_clickSair_4_listener($event) { return ctx.onClickSair($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("links", ctx.links);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("funcionalidades", ctx.funcionalidades);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("usuario", ctx.usuario);
    } }, directives: [_header_links_header_links_component__WEBPACK_IMPORTED_MODULE_2__["HeaderLinksComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgClass"], _divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_4__["DividerComponent"], _header_functions_header_functions_component__WEBPACK_IMPORTED_MODULE_5__["HeaderFunctionsComponent"], _header_search_trigger_header_search_trigger_component__WEBPACK_IMPORTED_MODULE_6__["HeaderSearchTriggerComponent"], _header_login_header_login_component__WEBPACK_IMPORTED_MODULE_7__["HeaderLoginComponent"]], encapsulation: 2 });


/***/ }),

/***/ "T+sX":
/*!*****************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/tipo-link.enum.ts ***!
  \*****************************************************************************/
/*! exports provided: TipoLink */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TipoLink", function() { return TipoLink; });
class TipoLink {
}
/**
 * Rota dentro da própria aplicação tratado pelo Router
 * do Angular (sem recarregar página)
 */
TipoLink.ROTA = 'rota';
/**
 * Endereço que não representa uma rota tratada pela aplicação.
 * Tipicamente, um endereço externo
 */
TipoLink.URL = 'url';


/***/ }),

/***/ "U6H2":
/*!*******************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/app-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");



const routes = [
    { path: '', pathMatch: 'full', redirectTo: 'home' },
    {
        path: 'home',
        loadChildren: () => __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ./home/home.module */ "dV2G")).then((modulo) => modulo.HomeModule),
    },
];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "aAU5":
/*!****************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/signin/signin/signin.component.ts ***!
  \****************************************************************************************/
/*! exports provided: SigninComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninComponent", function() { return SigninComponent; });
/* harmony import */ var _base_densidade_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/densidade.enum */ "ICPe");
/* harmony import */ var _tipo_signin_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../tipo-signin.enum */ "aNr+");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _button_button_button_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../button/button/button.component */ "uADd");









function SigninComponent_br_button_0_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "br-button", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SigninComponent_br_button_0_Template_br_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r3.onClickBotao($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "i", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2, "Entrar");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r0.jc(ctx_r0.ngClass, "sign-in", ctx_r0.densidade == ctx_r0.DENSIDADE_MEDIA ? "" : ctx_r0.densidade));
} }
function SigninComponent_br_button_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "br-button", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SigninComponent_br_button_1_Template_br_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r5.onClickBotao($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "Entrar com\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3, "gov.br");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r1.jc(ctx_r1.ngClass, "sign-in ", ctx_r1.densidade == ctx_r1.DENSIDADE_MEDIA ? "" : ctx_r1.densidade));
} }
function SigninComponent_br_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "br-button", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SigninComponent_br_button_2_Template_br_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r7.onClickBotao($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "Entrar com\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r2.jc(ctx_r2.ngClass, "sign-in", ctx_r2.densidade == ctx_r2.DENSIDADE_MEDIA ? "" : ctx_r2.densidade));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r2.base64LogoDefault, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
} }
class SigninComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__["BaseComponent"] {
    constructor(domSanitizer) {
        super();
        this.domSanitizer = domSanitizer;
        //constantes usadas no template
        this.ENTRAR = _tipo_signin_enum__WEBPACK_IMPORTED_MODULE_1__["TipoSignin"].ENTRAR;
        this.ENTRAR_GOVBR_MONO = _tipo_signin_enum__WEBPACK_IMPORTED_MODULE_1__["TipoSignin"].ENTRAR_GOVBR_MONO;
        this.ENTRAR_GOVBR_COR = _tipo_signin_enum__WEBPACK_IMPORTED_MODULE_1__["TipoSignin"].ENTRAR_GOVBR_COR;
        this.DENSIDADE_MEDIA = _base_densidade_enum__WEBPACK_IMPORTED_MODULE_0__["Densidade"].MEDIA;
        //Evento de click
        this.click = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        // tipo de exibição do componente signin
        this.tipoSignin = _tipo_signin_enum__WEBPACK_IMPORTED_MODULE_1__["TipoSignin"].ENTRAR_GOVBR_COR;
        // Densidade dos itens de menu. Default: densidade alta (small)
        this.densidade = _base_densidade_enum__WEBPACK_IMPORTED_MODULE_0__["Densidade"].ALTA;
        //logo gov.br
        this.base64LogoDefault = this.domSanitizer.bypassSecurityTrustUrl(_base__WEBPACK_IMPORTED_MODULE_4__["base64LogoGovBr"]);
    }
    onClickBotao(event) {
        this.click.emit(event);
    }
}
SigninComponent.ɵfac = function SigninComponent_Factory(t) { return new (t || SigninComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["DomSanitizer"])); };
SigninComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: SigninComponent, selectors: [["br-signin"]], inputs: { tipoSignin: "tipoSignin", densidade: "densidade" }, outputs: { click: "click" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 3, consts: [[3, "ngClass", "click", 4, "ngIf"], [3, "ngClass", "click"], ["aria-hidden", "true", 1, "fas", "fa-user"], [1, "text-black"], ["alt", "gov.br", 3, "src"]], template: function SigninComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, SigninComponent_br_button_0_Template, 3, 1, "br-button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, SigninComponent_br_button_1_Template, 4, 1, "br-button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, SigninComponent_br_button_2_Template, 3, 2, "br-button", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.tipoSignin == ctx.ENTRAR);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.tipoSignin == ctx.ENTRAR_GOVBR_MONO);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.tipoSignin == ctx.ENTRAR_GOVBR_COR);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _button_button_button_component__WEBPACK_IMPORTED_MODULE_7__["ButtonComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgClass"]], encapsulation: 2 });


/***/ }),

/***/ "aNr+":
/*!*********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/signin/tipo-signin.enum.ts ***!
  \*********************************************************************************/
/*! exports provided: TipoSignin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TipoSignin", function() { return TipoSignin; });
class TipoSignin {
}
TipoSignin.ENTRAR = 'entrar';
TipoSignin.ENTRAR_GOVBR_MONO = 'entrargovbr_mono';
TipoSignin.ENTRAR_GOVBR_COR = 'entrargovbr_cor';


/***/ }),

/***/ "bE7N":
/*!*****************************************************!*\
  !*** ./projects/dsgov-components/src/public-api.ts ***!
  \*****************************************************/
/*! exports provided: InformacaoLicenca, BaseComponent, Densidade, base64LogoGovBr, TipoLink, ButtonModule, ButtonComponent, BreadcrumbModule, BreadcrumbComponent, DividerModule, DividerComponent, FooterModule, FooterComponent, HeaderModule, TamanhoHeader, HeaderComponent, InputModule, EstadoInput, InputComponent, MenuModule, MenuComponent, RegraExibicaoMenu, TipoAgrupamentoLista, SigninModule, TipoSignin, SigninComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_components_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lib/components/base */ "KFZd");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InformacaoLicenca", function() { return _lib_components_base__WEBPACK_IMPORTED_MODULE_0__["InformacaoLicenca"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BaseComponent", function() { return _lib_components_base__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Densidade", function() { return _lib_components_base__WEBPACK_IMPORTED_MODULE_0__["Densidade"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "base64LogoGovBr", function() { return _lib_components_base__WEBPACK_IMPORTED_MODULE_0__["base64LogoGovBr"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TipoLink", function() { return _lib_components_base__WEBPACK_IMPORTED_MODULE_0__["TipoLink"]; });

/* harmony import */ var _lib_components_button_button_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lib/components/button/button.module */ "e18e");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return _lib_components_button_button_module__WEBPACK_IMPORTED_MODULE_1__["ButtonModule"]; });

/* harmony import */ var _lib_components_button_button_button_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/components/button/button/button.component */ "uADd");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return _lib_components_button_button_button_component__WEBPACK_IMPORTED_MODULE_2__["ButtonComponent"]; });

/* harmony import */ var _lib_components_breadcrumb_breadcrumb_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lib/components/breadcrumb/breadcrumb.module */ "yVyG");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbModule", function() { return _lib_components_breadcrumb_breadcrumb_module__WEBPACK_IMPORTED_MODULE_3__["BreadcrumbModule"]; });

/* harmony import */ var _lib_components_breadcrumb_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./lib/components/breadcrumb/breadcrumb/breadcrumb.component */ "R1os");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbComponent", function() { return _lib_components_breadcrumb_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_4__["BreadcrumbComponent"]; });

/* harmony import */ var _lib_components_breadcrumb_item_breadcrumb_interface__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lib/components/breadcrumb/item-breadcrumb.interface */ "4UVQ");
/* empty/unused harmony star reexport *//* harmony import */ var _lib_components_divider_divider_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./lib/components/divider/divider.module */ "0QCI");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DividerModule", function() { return _lib_components_divider_divider_module__WEBPACK_IMPORTED_MODULE_6__["DividerModule"]; });

/* harmony import */ var _lib_components_divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./lib/components/divider/divider/divider.component */ "4yHK");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DividerComponent", function() { return _lib_components_divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_7__["DividerComponent"]; });

/* harmony import */ var _lib_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./lib/components/footer/footer.module */ "jNVx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FooterModule", function() { return _lib_components_footer_footer_module__WEBPACK_IMPORTED_MODULE_8__["FooterModule"]; });

/* harmony import */ var _lib_components_footer_footer_footer_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./lib/components/footer/footer/footer.component */ "dTQJ");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return _lib_components_footer_footer_footer_component__WEBPACK_IMPORTED_MODULE_9__["FooterComponent"]; });

/* harmony import */ var _lib_components_header_header_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./lib/components/header/header.module */ "CXQa");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HeaderModule", function() { return _lib_components_header_header_module__WEBPACK_IMPORTED_MODULE_10__["HeaderModule"]; });

/* harmony import */ var _lib_components_header_tamanho_header_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./lib/components/header/tamanho-header.enum */ "v7YH");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TamanhoHeader", function() { return _lib_components_header_tamanho_header_enum__WEBPACK_IMPORTED_MODULE_11__["TamanhoHeader"]; });

/* harmony import */ var _lib_components_header_header_header_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./lib/components/header/header/header.component */ "B20u");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return _lib_components_header_header_header_component__WEBPACK_IMPORTED_MODULE_12__["HeaderComponent"]; });

/* harmony import */ var _lib_components_input_input_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./lib/components/input/input.module */ "lknF");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputModule", function() { return _lib_components_input_input_module__WEBPACK_IMPORTED_MODULE_13__["InputModule"]; });

/* harmony import */ var _lib_components_input_estado_input_enum__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./lib/components/input/estado-input.enum */ "PISc");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "EstadoInput", function() { return _lib_components_input_estado_input_enum__WEBPACK_IMPORTED_MODULE_14__["EstadoInput"]; });

/* harmony import */ var _lib_components_input_input_input_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./lib/components/input/input/input.component */ "qnra");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InputComponent", function() { return _lib_components_input_input_input_component__WEBPACK_IMPORTED_MODULE_15__["InputComponent"]; });

/* harmony import */ var _lib_components_menu_menu_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./lib/components/menu/menu.module */ "v+A7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MenuModule", function() { return _lib_components_menu_menu_module__WEBPACK_IMPORTED_MODULE_16__["MenuModule"]; });

/* harmony import */ var _lib_components_menu_menu_menu_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./lib/components/menu/menu/menu.component */ "ApSJ");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return _lib_components_menu_menu_menu_component__WEBPACK_IMPORTED_MODULE_17__["MenuComponent"]; });

/* harmony import */ var _lib_components_menu_item_menu_interface__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./lib/components/menu/item-menu.interface */ "oaOO");
/* empty/unused harmony star reexport *//* harmony import */ var _lib_components_base_link_interface__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./lib/components/base/link.interface */ "CMe2");
/* empty/unused harmony star reexport *//* harmony import */ var _lib_components_menu_regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./lib/components/menu/regra-exibicao-menu.enum */ "91Fn");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RegraExibicaoMenu", function() { return _lib_components_menu_regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_20__["RegraExibicaoMenu"]; });

/* harmony import */ var _lib_components_list_tipo_agrupamento_lista_enum__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./lib/components/list/tipo-agrupamento-lista.enum */ "h+bN");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TipoAgrupamentoLista", function() { return _lib_components_list_tipo_agrupamento_lista_enum__WEBPACK_IMPORTED_MODULE_21__["TipoAgrupamentoLista"]; });

/* harmony import */ var _lib_components_signin_signin_module__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./lib/components/signin/signin.module */ "8cX5");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SigninModule", function() { return _lib_components_signin_signin_module__WEBPACK_IMPORTED_MODULE_22__["SigninModule"]; });

/* harmony import */ var _lib_components_signin_tipo_signin_enum__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./lib/components/signin/tipo-signin.enum */ "aNr+");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TipoSignin", function() { return _lib_components_signin_tipo_signin_enum__WEBPACK_IMPORTED_MODULE_23__["TipoSignin"]; });

/* harmony import */ var _lib_components_signin_signin_signin_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./lib/components/signin/signin/signin.component */ "aAU5");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SigninComponent", function() { return _lib_components_signin_signin_signin_component__WEBPACK_IMPORTED_MODULE_24__["SigninComponent"]; });

/*
 * Public API Surface of dsgov-components
 */
//Base

//Button


// Breadcrumb



// Divider


// Footer


// Header



// Input



// Menu






// Sigin





/***/ }),

/***/ "dTQJ":
/*!****************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/footer/footer/footer.component.ts ***!
  \****************************************************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../divider/divider/divider.component */ "4yHK");
/* harmony import */ var _grupo_footer_grupo_footer_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../grupo-footer/grupo-footer.component */ "G30h");







function FooterComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "br-grupo-footer", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const grupo_r2 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("horizontal", ctx_r0.horizontal)("grupo", grupo_r2)("links", ctx_r0.gruposLinks[grupo_r2]);
} }
function FooterComponent_div_8_ng_container_3_i_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "i", 21);
} if (rf & 2) {
    const perfil_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassMap"](perfil_r4.classIconeFontAwesome);
} }
function FooterComponent_div_8_ng_container_3_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const perfil_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](perfil_r4 == null ? null : perfil_r4.texto);
} }
function FooterComponent_div_8_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "a", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, FooterComponent_div_8_ng_container_3_i_2_Template, 1, 2, "i", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, FooterComponent_div_8_ng_container_3_span_3_Template, 2, 1, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const perfil_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", perfil_r4.url, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", perfil_r4.classIconeFontAwesome);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !perfil_r4.classIconeFontAwesome);
} }
function FooterComponent_div_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, "Redes Sociais");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, FooterComponent_div_8_ng_container_3_Template, 4, 3, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx_r1.linksRedesSociais);
} }
const _c0 = function () { return {}; };
const _c1 = function () { return { filter: "invert(1)" }; };
class FooterComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__["BaseComponent"] {
    constructor(domSanitizer) {
        super();
        this.domSanitizer = domSanitizer;
        // Indica se o padrão de cores é invertido. Se TRUE, será apendado ao atributo
        // "class" o valor "[inverted]", o que deixa o rodapé na cor branca com fonte azul(invertido)
        // Se FALSE, o rodapé fica padrão: fundo azul e fonte branca
        this.invertido = false;
        // Se TRUE, a classe 'horizontal' é acionada ao elemento br-list
        this.horizontal = true;
        this.alt = 'gov.br';
        this.url2 = 'http://www.acessoainformacao.gov.br/';
        this.alt2 = 'Acesso à Informação';
        this.url3 = 'http://www.brasil.gov.br/';
        this.alt3 = 'Governo Federal';
        this.gruposLinks = {};
        // links para os perfis do órgão em redes sociais
        this.linksRedesSociais = [];
        // Indica a exibição ou não da informação sobre licença no menu
        this.exibeInformacaoLicenca = true;
        // Label de apresentação e nome da licença utilizada
        this.informacaoLicenca = new _base__WEBPACK_IMPORTED_MODULE_0__["InformacaoLicenca"]();
        //gov.br negativo
        this.base64Imagem1Default = this.domSanitizer.bypassSecurityTrustUrl(`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAh8AAADFBAMAAAAGSY2CAAAALVBMVEVHcEz////////////////////////////////////////////////////////NXt0CAAAADnRSTlMAfbce9jkM61ChZ9rJihJ9h0oAAA+ySURBVHja7Z39j5RXFccvO53ZF9hm1ppaGjtZbEtBcPKoLIW2bohENNBMhuLWhshmKGirVrKFQoLGzSi21iqbpRWslW6ghL5g3EyREqS62aSGGLSTaY0vaNyws7PM7rzcv8EfZnZenvs9957nmS2JM8/9iTDPs/fezz33nHPPufc+QvxflZC0l02ipYsHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAeEA8IB4QD4gHxAPiAfGAUMX32Avnes69+ax184HsGRgY2LHexV/eMzBANrfv9LVfferVO4+4a/OG5WsWGps5f+zIzQTi/2256vwrjzr5q4GdJy9IKeX5V8/G1NF968JCXQ+/EnXc4u2/tjV427HoTQLScTJS/e/Mp2PsP7p7ovrekJ3VW8O1teVvq/7U0WMroMbt90i15P9+U4B8Ybj+h/Sp+lfDthfnFn7YWMNRJupf8v/CXt/Vym9t9p+UKef/pcTlcFVIfOqv06jnfuWxUT2Qnyu/ZG9nAdlY97+Tde90TajNvcQG8tkJSZUaSUsqP6YRkCXKY3EdkMBvQK2ZfzCAdEVoIB2wR39mAnlE6sq9tNBLNNuXKeOtnTJvwEqzcSMQv22AemullBjhEywgX5eSRWSfxGNvK8pjRR2Qh4hK05YJyI/RxCzr0ylK3i0GEBOPCpE2ibWDrYzbH5rVALGJfU35igGIMjNT1Rd+QnZlqxnIt6S5vFSal+oPCQBkDD8EgQTCdKUn9EDGaCBLNF0ZNQHpGGYAyQSFECKgjuYMAKI8FaSBPKWpNG/pgHRKXA1kVTsVY3ogvrDklHwUVzTNsboWCcQ3oav0gA6IMjFlxXnp1Hblih7I1ySvbBVCiEGO3e0mnkFAHtTWmY3SQPwaBa8f47ylA7JEcktKCNGuzqWY2ermSCCBCX2dB2kg62gg3YaeXNQAYU4YKaUsxGBVcbPV3UICecpQZ9YigahOooxSVk6VWBLIg5Jffged95TZ6o6SQIzDcZEC0gUeLneqgyHsFBDfsAMgeQuNy5ACJEwIkQrki8Y60xSQdTSQdca/miOB3C+dlANIGmeMVjdLO/7mEiSAINkiV1yK4rMIIP5hR43LWsB5zxmtbrERILMYCJwWPJUqpZQJAsj9Dlt3CDjvaaPVnW0ESD4GgSxD41WqZpDxV4sYiMnoAUOjjkzGDmQp5d27AlLSyAqQEcSuVA2rU49AIMsct64XOO92u9tPedTugOQgEKQnCqUYCeuvvguBjDluXRG8kzJZXashIPkYAJKmLdITrmqRFsteA99n0Gh3w5SScQdEBo2+eLnMCyGEmHIPxA3LQ+1GuxuhzJBLIFscAQlE3AMZc/HefLfJ7voJx901kCIXSNHZ2kwBQs2Y/XfsiIm+jxGkj5jsbjcZU3MJJBNjApkWcPnJBoJnTHYhEfMkbkQiabC7S0kr5BKIDDKB5IQQYsQ9ENi+7OtV2YetyI0b7G4/4bhrgWxb/d8XL1A/DjkBQj254uz6PY+dTmqABKDbXpsNgbHFfL/B7o4TjrsGSFkqdw2THWUBmRNCBAjbXc4twRRQGcgSXUBGs/R7TVKeKLa6s0Yg6agm11ZyuPRAtv117V8ipZqwW5atZkZ/RgJ5QhvVLQUHUAMvG+xuhMRFAKnJSBFELB2Qw+WNG31H38GJEinlezXt+zgFZByHgIwikoto7W4H5biTQO42ZkSCNJDM8foW7yXtcWWUkwSQCRQmsG+vALO6MKa1u91k9JYAMq33+0talQKS+ZutxSN0TGWhPI6B+AmtVF++Cp4a0drdpTQtDKR+40MHjolQQN6zN3iKdOmFPmljdVMrbb2XJaX8p9bu9tPzKWQWEPxQkQKiJoXQfJi0PQMj2xbw6LJqRgHZ5h9o7e445bgTQHptNbZBM4OBZJT9TQHJUATQ4bBGODMGzumc1u6GaalDQJRBgGHvGAZyUGluB+Wv1RUUU7PAREJ56+8AAU7q7G6Enk4hltpCajUe5gkIdK7UbqFMpzVhUm+Cij8VxjVj0EE67hhIrznvJ6UcDUsWTNhVtVs+sHD9PF5VqkoEvNuvsbvdGhcgRIQhzFI/GZYsG6CuLHG3gC3aYLZOZN74Rxq720467hAIqhMYCpjhy4Oe3mrwyqiwr5QbeToVejova+xuv2YCh5CHwapxNsybMainqApgykBOF28836c+eCVC292QxkkM8fT4LcBQhFnqB8Ic4mnGfl4FUMdtGqP7FdboiJDJqSYVYxEBifK8BLQJDuTsB3mNg77qzCBpdwMwVUIDQZ0CWjUdlqbIJVkFsp1gIQdkKw6BgObNtpN2t0PnFKmtzQre8BXCPN2AlikW77kQ803UvFw3OVqdtOOOgGDDpvqq2TBPNyCbCKtQp5aKKENs2Qcz2ke+266bwCHG4ozoFfivlGCZ7DysYpBRQ4EAMgHGNUlNt0HdNAwxLf0UC0iU11ioaoB5TjLfROOVViUuhfucNWi8GaY8g+Zm2KOHiurAcd9E+qegOicJTK9oAHKd6wtyx2+YOStvYQApEkCmAJA2YqgDWksQ4ilGtDpPMpvLBaJGg7hvIiB51RbnsNVNGIAk3APB6ifCiIZgIBE2EOQ9KGvgNLa6QcNfmnQPZIZpEnPMKcNFSbhTY1jFtWtdm0UFsokpIdNMpdqYhKhtjqOuFMRHByTRkA7pX2Qdos7BFOpyzh2QEY4f0ssEUmQyb8zKqEu+BHIUtwhXSpUFZFQ04piNL6ofkgYrnBlkdXuFKz8kxAECPXfguheYo5xkAwlD6Emkkjv062eupwrWWWFmsILr0SYXeS2jylwaWN2sceRnma3Nc4Ewl/8gdN7QahdEFjPA6s4bgUwzbWeaC2SKF+YBQZ6G4iEoTBtVdfesEcg8s8Z5LhBmCBFEKUeY62kYMUP/nVJ7nOB4NKwI8DRXqTKDzHsXN6Z6A83ChDr5g2brEeUN3xxXQgZdZ6zXNRB1H0Lqa0a1upYZSIq18EJ5mRQ3acLMhTWSl5lEY5FTplGB4V8M8Ub5OldCeKlMlC1tJHOXQuOYVmQ9xwAyxzOdCa6EoGR3ioOtodxuHOmWjMJoCwNInpdeH+VKCNoOsZnjCjeU/Y9B4xi1y3ovpx1xVp+CXAlBk2HefBRf4v0hQeb+EKyYUvYOxzlAEhyTKKNcCYEbmeOMzaZwB9EQT0sVselK2BBlWZJa5DibWcGVELjp7oANGtwdjPaY5XgWexbHWGYCJpUEN91FzX6qTAuuhMA6CjHzJsRGdiEO4T0WuS7Twg0C2czYM5njSwg8o3qFs5OZt09VY8bs+ivdadIOEIhtez3cVTvDl5B2Yx3E9SDMnczjklwE2u1Pph20+IG1z3z5/BntTuYrxp3CMsGXEHyVytbqA9+VBBDeXveIpOMm9rGcUrj5P1n659tRDZB6EYHbroN8CfHj7q5a+H13hASCBp91GkI7Xeu4Vdzhu3WnIWq33z5ENJYtIdS57rdL2HdRPBo4L5PQTtdabtWrFkpHYqgDRNVb/rqGCbZsCSEvU8m/PPDCtfvo9lr47FH9Zmmof05pp3ut4x6yuRsUkMq9hx1hii1fQvZKd8UihKv2zB3UP3mtx1DruHfbDRh9CHFVTAj6zN0hJxLS7R7ICByt6qnMb8P2zem9whp/edwePdWcynz4g7tOkqcyg04kxOceCL4bonJul9A/k+bpWvK2/RH7gmJRDzJTEuLqvHoJCMVy/x07vtl39B6idZY2dlTjuLcpIBf1qDslIWgzMxOIqwbmDGd9qo77iDLVXALZLBxJSKd7IMtcvDdpOh9XWfAkFWW8qNdlkBISGHYNxO9iPluG4FGlFyCA5A5INuZMQozXutFAXLw6x9VfVpfag0W8ckcjIdqZbADifLqlzGvtsnPZpk42O5AMyyAkhEMJ4VxWl5/AS9akQx5pxlq7PKxL1SyHHUiWYxBKB+ucSAjnxozNYQzE6T1mF7le4RZ1F9cNFUgnd8Y4khDOPVVxAojzm+6YXmGv6g7MqkB8EXOdvcKxhJh9s2lBAHF0WaYaHaCnXJwFhKFmy2PgSELMurGXBBJwokUKMa6Fy4CdoDMAyFJjnV8SLiTEdP9KWpBAiKsScFnJSfwuRNwVhXsdADF7QnHhQkJMlnelBoiDe9Cm+RXPAjc4AYAYDUJOuJIQvRZJo9ViRfq7IkwemTgvc1hy3NWM5CgCYjIIQeFKQvS3ma1E2i9mCssr5QAz81turU8VfgDEIKA54VJClK8k2CVdAVJjO3kBhPmYA9G01GhvVkAgnTyhdCohVDpKLlxQP6yagWrknnMBaSHKT5SVMhUjyrggIFrLe1C4lhBaFZyAeyvrMtFdZvcse8pBoqwk6cuUJQkEovkQQ83nQxxLiBCfw3/0HexS1qfmd5sUq+17QCbn/QZIGcUJIFTDpcycEg1ICPFNlO8R1sC2c8dAhORBOO+9qtdWFBQQ4ns79dd5uZAQ9KEneTlGWCH7hrjdOj2Sv52uNEl7U232SBsBhNDql/Sup1lCwHemVpHOvXJoQv3iV6Uc1n3abRw77kLUfzmmYNFAsFZ/2uCLMyRECH/dJai/P0PrPnXjTuA1PG0M35zbhx13u1zCr5hVFBn4vtblmGhcQoQQ/uV/Kvfj/TM664h23T+JPux2+DmDdetRy22KWrsktEAU+czca1ytBQW39D1/rufc84bjf/jE4c6T9TYw+5mzoqFSVmtXjQ8GdtUoo8yKxfz+Ik/1zVJWY+fCxzIz54+dbfz7oQ+skXL/Gc6TgaPlivf/y/qocYBV9oyuaXv6Bnasjy1W3fwvgX7jdM+dz64XN6F0Ytepdcs6HNtv3aJ6PqMtzcMvGzBazVjABY/RlgYCYtCxVuYB4ov5Ju/yT7WuDPNOxmYq4/MaIt3GXQ3NV0LVy/NVZxxlsTY1OZApKQuvE7+9QYe0mtvxyh7nhtEkcWFi03mifwShC+JjGc1udcNqjKykPz5B5qKbu1TDHfv/XV1tb1g+TOeim7vUhSS/v/qDnp6eng8neJtNm7I43ara7DpVuNkK28wl4GYrbDMXp0dEJj0gLRYMcbiJv+m9EKdfRT3Q9EC6vBnTCJDppufh8IuqLZCBcHRUtRBrfiCOzgGtbH4ejs5UzQsPSOvlMB0cN93aCjwYp04q69zWSGG2exq1vtzK5XGpNXhoLyUA25qbvzzOOwP0dKxVgAj/fxg8ropWKttNpyszx0VrlcD2+3Q4VrTilqENHxLpiMz7z4nWLL4frlH167YVj4oWLr6dd117ce27z0gpZfYPq4+92dI0Wr78D20zXEzc9fryAAAAAElFTkSuQmCC`);
        //Acesso à Informação
        this.base64Imagem2Default = this.domSanitizer.bypassSecurityTrustUrl(`data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20117%2049%22%20height%3D%2249%22%20width%3D%22117%22%20shape-rendering%3D%22geometricPrecision%22%20text-rendering%3D%22geometricPrecision%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%3C!%5BCDATA%5B.a%20%7Bfont%3A%20normal%20bold%2011px%20Open%20Sans%2C%20sans-serif%3B%7D%5D%5D%3E%3C%2Fstyle%3E%3C%2Fdefs%3E%3Ccircle%20cx%3D%2222%22%20cy%3D%2223%22%20r%3D%2222%22%20fill%3D%22%23222%22%2F%3E%3Cpath%20style%3D%22stroke%3A%23fff%3Bstroke-width%3A9%3Bstroke-linecap%3Around%3B%22%20d%3D%22m%2022%2C23%20v%2013%22%2F%3E%3Cpath%20style%3D%22stroke%3A%23222%3Bstroke-width%3A4%3Bstroke-linejoin%3Around%3B%22%20d%3D%22m%204%2C43%203%2C-6%204%2C3%20z%22%2F%3E%3Ccircle%20r%3D%224.5%22%20cy%3D%2211%22%20cx%3D%2222%22%20fill%3D%22%23fff%22%2F%3E%3Cg%20fill%3D%22%23222%22%3E%3Ctext%20x%3D%2247%22%20y%3D%2222%22%3E%3Ctspan%20class%3D%22a%22%20y%3D%2218%22%3EAcesso%20%C3%A0%3C%2Ftspan%3E%3Ctspan%20class%3D%22a%22%20x%3D%2247%22%20y%3D%2231%22%3EInforma%C3%A7%C3%A3o%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fsvg%3E`);
        //Logo Pátria Amada Brasil
        this.base64Imagem3Default = this.domSanitizer.bypassSecurityTrustUrl(`data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20viewBox%3D%220%200%20496.2%20143.8%22%3E%3Cstyle%3E.st0%7Bfill%3A%23575756%7D%3C%2Fstyle%3E%3Cpath%20d%3D%22M220.5%2054.5c14.5%200%2021.4%206%2021.4%2016%200%205.6-3.7%2010.4-9.2%2012.4%206.7%201.8%2012.5%207.9%2012.5%2015.5%200%209.8-7.1%2017.2-23.4%2017.2-8%200-14.4-.2-21.7-.3l-.6-.6V55.4l.6-.6c7.2-.1%2013.9-.3%2020.4-.3zm-10.7%2025.4h10.3c9.2%200%2011.3-4.9%2011.3-9.1%200-4.3-1.9-9.1-11.1-9.1-2.8%200-7.4%200-10.5-.1v18.3zm0%207.2v21.4c4.1%200%208.3-.1%2011.9-.1%2010.6%200%2012.8-6.1%2012.8-10.6%200-4.4-2.9-10.7-13.4-10.7h-11.3zM284.5%2088.7c3.2%201.1%205.6%204.1%207%207.5l4.3%2010.3c1%202.4%202.2%204.8%204.4%206.4-1.4%201.9-4.4%202.9-7.1%202.9-3.9%200-5.3-1.9-6.9-5.7l-4.9-11.9c-1.7-4.1-3.8-7.2-9.9-7.2h-8.1v24.3c-1.6.3-3.5.4-5.2.4-1.6%200-3.6-.1-5.1-.4V55.4l.6-.6c7.4-.1%2014.5-.3%2021.1-.3%2013.7%200%2022.3%206.4%2022.3%2018.1.1%208.1-5.3%2014.1-12.5%2016.1zm-21.1-5.3c3.8-.1%208.2-.2%2010.9-.2%209.6%200%2012-5.5%2012-10.6%200-5.4-2.4-10.7-12-10.7-2.9%200-7.6%200-10.9-.1v21.6zM320.8%20100.5l-5.2%2014.8c-1.3.3-2.9.4-4.5.4-1.9%200-3.7-.3-5.1-.6l-.3-.4L327.9%2055c1.6-.3%204.3-.4%206-.4%201.7%200%204.4.1%205.9.4l22%2059.7c-1.5.9-3.8%201.2-6.1%201.2-3.2%200-4.9-1.1-6.2-4.9l-3.6-10.3c-1.7%200-5.1.1-5.9.1h-13.5c-.8-.2-4-.3-5.7-.3zm2.6-7.6c1.6%200%204.2-.1%205-.1h9.8c.7%200%203.3.1%204.9.1l-4.5-12.8c-1.8-5.1-3.8-11.3-5.2-16h-.4c-1%204-2.8%209.5-3.8%2012.8l-5.8%2016zM371.1%20102.5c5.7%203.4%2013%206%2019.8%206%208%200%2012.5-3.4%2012.6-8.3%200-4.2-3.2-7.3-8.9-9.5L383%2086.2c-8.3-3.2-13.5-7.8-13.5-15.3%200-9.6%209-17.1%2022.2-17.1%208.2%200%2015.7%202.3%2020.8%204.6-.1%202.7-1.7%205.6-3.8%207.3-5.1-2.3-11.8-4.2-16.8-4.2-7.3%200-11.8%203.6-11.8%208.3%200%203.9%203.3%206.1%208.2%208l11.4%204.4c8.5%203.2%2014.7%208.6%2014.7%2016.4%200%2010.2-7.9%2017.8-24.1%2017.8-8.2%200-17-2.5-23.6-6.6.3-2.8%202.2-5.7%204.4-7.3zM426.6%2054.9c1.5-.3%203.6-.4%205.2-.4s3.6.1%205.2.4v60.3c-1.6.3-3.6.4-5.2.4s-3.7-.1-5.2-.4V54.9zM492.9%20107.1c0%201-.1%202.6-.3%203.7-.6%203-3%204.5-6.8%204.5h-25.7c-3.5%200-6.1-2-6.1-5.8V55l.7-.5h3.9c4.3%200%205.9%201.9%205.9%206v46.9c3-.3%206.1-.4%208.7-.4h19.7zM209.6%2034.6h-4.1v10.1c-.9.2-2.1.2-3%20.2-.8%200-2%200-3-.2V14.5l.3-.3c3.6-.1%206.5-.2%209.7-.2%206.1%200%2010.6%203.3%2010.6%2010.3%200%206.8-4.4%2010.3-10.5%2010.3zm-4.1-4.6c1.5%200%203.1-.1%203.7-.1%204%200%204.8-3.2%204.8-5.6%200-2.4-.8-5.6-4.8-5.6h-3.7V30zM227.2%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.7%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H227.2zm1.5-4.7H236.4l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM252.3%2022.5v-3.3H244.7c-.2-.9-.2-1.8-.2-2.5s0-1.6.2-2.5H266c.2.6.3%201.6.3%202.3%200%202-1%202.7-3.2%202.7H258.3v25.5c-1%20.2-2.1.2-3%20.2-.8%200-2%200-3-.2V22.5zM285.4%2031.6c1.6.6%202.7%202.1%203.3%203.9l1.6%204.5c.4%201.2%201.1%202.4%202.1%203.2-.8%201.1-2.4%201.8-4%201.8-2.2%200-2.9-1.2-3.8-3.5l-1.9-5.3c-.7-1.8-1.6-3.2-4.1-3.2H276v11.7c-1%20.2-2.1.2-3%20.2-.8%200-2%200-2.9-.2V14.5l.3-.3c3.6-.1%206.9-.2%2010.2-.2%206.2%200%2010.5%203.1%2010.5%209.4-.1%204.3-2.8%207.2-5.7%208.2zm-9.4-3.2c1.6-.1%203.2-.1%204.1-.1%203.9%200%204.8-2.4%204.8-4.8%200-2.5-.9-4.8-4.8-4.8H276v9.7zM297.3%2014.3c.9-.2%202.2-.2%203-.2.8%200%202%200%203%20.2v30.4c-1%20.2-2.1.2-3%20.2-.8%200-2.1%200-3-.2V14.3zM315.4%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.8%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1h-10.7zm1.5-4.7H324.6l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM353.1%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.7%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H353.1zm1.4-4.7H362.2l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM377.7%2014.3c1.3-.2%203-.3%204-.3%201.1%200%202.5.1%203.8.3l3.4%2012.3c.3%201.2%201.4%205.8%201.7%207.6h.3c.3-1.8%201.4-6.4%201.7-7.6l3.4-12.3c1.3-.2%202.8-.3%203.8-.3%201.1%200%202.7.1%204.1.3l2.4%2030.3c-.8.2-2%20.3-3%20.3-.9%200-1.8%200-2.6-.2l-.8-14.3c-.2-2.8-.4-6.9-.4-9.7h-.3L394%2040.1c-.9.1-2.2.2-3.1.2-.8%200-2.1-.1-3-.2l-5.2-19.4h-.3c0%202.8-.2%206.9-.4%209.7l-1%2014.3c-.8.1-1.7.2-2.7.2-.9%200-2.1-.1-3-.3l2.4-30.3zM417.4%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.7%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H417.4zm1.5-4.7H426.6l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM459.4%2042.7c-2%201.6-5.6%202.2-8%202.2-3.7%200-6.6-.1-10.5-.2l-.3-.3v-30l.3-.3c3.8-.1%206.8-.2%2010.5-.2%202.4%200%206%20.6%208%202.2%204.1%203.3%204.9%208%204.9%2013.2-.1%205.4-.8%2010.1-4.9%2013.4zm-8-23.9h-4.9v21.5h4.9c5.8%200%206.7-5.8%206.7-10.7%200-5-.9-10.8-6.7-10.8zM474%2037.8l-2.1%206.9c-.8.2-1.6.2-2.6.2-.9%200-2.1-.1-2.8-.4l-.2-.3%209.9-30c1-.1%202.4-.2%203.5-.2.9%200%202.5.1%203.4.3l9.8%2030c-.8.5-2.3.8-3.4.8-1.9%200-2.8-.7-3.6-3.2l-1.2-4.1H474zm1.5-4.7H483.2l-1.3-4.5c-.8-2.5-1.7-6-2.4-8.6h-.3c-.4%202.3-1.4%205.5-2%207.5l-1.7%205.6zM238.2%203.9c.9.5%202.1%201.9%202.4%203.2l-7.4%204.4c-.7-.3-1.4-1.3-1.6-2l6.6-5.6z%22%2F%3E%3Cg%3E%3Cpath%20d%3D%22M206.9%20133.7h3.4c1.5%200%202.3.7%202.3%202.2v5.7c-1.9.6-3.8.9-5.9.9-1%200-2-.2-2.8-.5-.8-.3-1.5-.8-2-1.5-.5-.6-.9-1.4-1.2-2.4-.3-.9-.4-2-.4-3.2%200-1.3.2-2.5.6-3.4s.9-1.8%201.5-2.4c.6-.6%201.4-1.1%202.2-1.5.8-.3%201.7-.5%202.6-.5%201.9%200%203.6.5%205.3%201.6%200%20.2-.1.5-.2.7-.1.2-.2.5-.3.7-.1.2-.3.4-.5.6-.2.2-.4.3-.6.5-1.2-.8-2.4-1.2-3.6-1.2-2.4%200-3.5%201.6-3.5%204.9%200%203.3%201.2%204.9%203.6%204.9h1c.3%200%20.6-.1.9-.1v-1.4-.9-.6h-1.1c-.6%200-1-.1-1.3-.4-.2-.2-.4-.6-.4-1.1.1-.6.2-1.1.4-1.6zM224.2%20141.1c-1.5-1.3-2.3-3.4-2.3-6.3%200-1.3.1-2.4.4-3.3.3-1%20.7-1.8%201.3-2.4.6-.6%201.2-1.1%202-1.5.8-.3%201.7-.5%202.7-.5%201%200%201.9.2%202.7.5.8.3%201.5.8%202%201.5.6.7%201%201.5%201.3%202.4.3%201%20.4%202.1.4%203.3%200%201.3-.1%202.4-.4%203.3-.3%201-.7%201.8-1.3%202.4-.6.6-1.2%201.1-2%201.5-.8.3-1.7.5-2.7.5-1.7-.1-3-.5-4.1-1.4zm1.7-3c.4%201.1%201.2%201.7%202.4%201.7.6%200%201.1-.1%201.4-.4.4-.3.7-.7.9-1.1.2-.5.3-1%20.4-1.5.1-.6.1-1.1.1-1.7%200-.5%200-1.1-.1-1.7%200-.6-.1-1.2-.3-1.7-.2-.5-.4-1-.8-1.4-.4-.4-.9-.6-1.6-.6-.7%200-1.2.2-1.6.5-.4.4-.6.8-.8%201.3-.2.5-.3%201.1-.3%201.7%200%20.6-.1%201.1-.1%201.5%200%20.7%200%201.3.1%201.8%200%20.5.1%201%20.3%201.6zM249.6%20139.2l2.8-11.9c.3-.1.8-.1%201.3-.1.8%200%201.3.1%201.8.2l.1.2-4%2014.5c-.8.1-1.6.1-2.5.1-.8%200-1.4-.1-1.8-.3-.4-.2-.6-.6-.8-1.2l-3.6-13.1c.8-.3%201.4-.5%201.9-.5.6%200%201.1.1%201.3.4.3.3.5.7.7%201.3l1.7%206.2c.3%201%20.5%202.3.8%203.9.1.2.1.3.3.3zM268.3%20137.7v1.6h6.6c0%20.5%200%20.9-.1%201.2-.2%201.1-.9%201.7-2.2%201.7h-5.8c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.7l.2-.2h9.3c.1.4.1.9.1%201.4s-.1%201-.3%201.5h-5.9v3.1h4.8c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4h-4.8v1.6zM295.3%20131.9c0%20.5-.1.9-.2%201.4-.1.4-.3.8-.6%201.1-.2.3-.5.6-.8.9-.3.3-.7.4-1%20.6.8.3%201.3.9%201.7%202l.6%201.8c.2.7.6%201.3%201.1%201.6-.2.3-.5.5-1%20.7-.4.2-.9.3-1.4.3-.5%200-.9-.1-1.2-.4-.3-.3-.6-.8-.8-1.5l-.8-2.3c-.2-.4-.4-.8-.6-1-.3-.2-.7-.3-1.2-.3h-.9v5.4c-.5.1-1%20.1-1.7.1s-1.3%200-1.7-.1v-14.7l.2-.2c1.3%200%202.3%200%203.2-.1h2c.8%200%201.5.1%202.2.3.6.2%201.2.5%201.7.9s.8.9%201.1%201.5c0%20.5.1%201.2.1%202zm-7.1-2.1v4.3h1.7c.5%200%20.8-.1%201.1-.3.3-.2.5-.4.6-.6.1-.3.2-.7.2-1.2%200-1.4-.7-2.1-2-2.1h-.9c-.3-.1-.5-.1-.7-.1zM317.1%20127.2l.2.2V142c-.6.1-1.3.2-2%20.2s-1.5%200-2.1-.1l-3.4-7.7c-.4-.9-.8-1.9-1.2-3.1h-.1c.2%202.1.3%204.3.3%206.5v4.3c-.4.1-1%20.1-1.6.1-.6%200-1.2%200-1.6-.1v-14.7c.5-.1%201.2-.2%202-.2s1.5%200%202.1.1l3.4%207.7c.6%201.4%201.1%202.5%201.3%203.3h.1c-.2-2-.3-4.1-.3-6.4v-2.6c0-.8.2-1.3.5-1.6.3-.3.8-.5%201.5-.5h.9zM329.4%20141.1c-1.5-1.3-2.3-3.4-2.3-6.3%200-1.3.1-2.4.4-3.3.3-1%20.7-1.8%201.3-2.4.6-.6%201.2-1.1%202-1.5.8-.3%201.7-.5%202.7-.5%201%200%201.9.2%202.7.5.8.3%201.5.8%202%201.5.6.7%201%201.5%201.3%202.4.3%201%20.4%202.1.4%203.3%200%201.3-.1%202.4-.4%203.3-.3%201-.7%201.8-1.3%202.4-.6.6-1.2%201.1-2%201.5-.8.3-1.7.5-2.7.5-1.6-.1-3-.5-4.1-1.4zm1.7-3c.4%201.1%201.2%201.7%202.4%201.7.6%200%201.1-.1%201.4-.4.4-.3.7-.7.9-1.1.2-.5.3-1%20.4-1.5.1-.6.1-1.1.1-1.7%200-.5%200-1.1-.1-1.7%200-.6-.1-1.2-.3-1.7-.2-.5-.4-1-.8-1.4-.4-.4-.9-.6-1.6-.6-.7%200-1.2.2-1.6.5-.4.4-.6.8-.8%201.3-.2.5-.3%201.1-.3%201.7%200%20.6-.1%201.1-.1%201.5%200%20.7%200%201.3.1%201.8s.2%201%20.3%201.6zM365.4%20130.3V133.4h4.7c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4h-4.7v6c-.5.1-1%20.1-1.7.1s-1.3%200-1.7-.1v-14.7l.2-.1h9.3c.1.4.1.8.1%201.4s-.1.9-.4%201.2c-.3.3-.8.4-1.4.4h-4.4zM384.4%20137.7v1.6h6.6c0%20.5%200%20.9-.1%201.2-.2%201.1-.9%201.7-2.2%201.7H383c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.7l.2-.2h9.3c.1.4.1.9.1%201.4s-.1%201-.3%201.5h-5.9v3.1h4.8c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4h-4.8v1.6zM410.4%20141.2c-.5.4-1.1.6-1.8.8-.8.2-1.6.3-2.5.3h-1.9c-.8%200-1.9%200-3.2-.1l-.2-.2v-14.6l.2-.2c.8%200%201.7%200%202.6-.1h2.8c1.2%200%202.3.2%203.1.6.8.4%201.5.9%202%201.6s.8%201.5%201%202.4c.2.9.3%201.9.3%203%200%201.4-.2%202.7-.5%203.7-.3%201.1-1%202-1.9%202.8zm-4-1.7c1.9%200%202.9-1.6%202.9-4.8%200-3.2-1-4.8-2.9-4.8h-2.1v9.7h.9c.3-.1.7-.1%201.2-.1zM426.1%20137.7v1.6h6.6c0%20.5%200%20.9-.1%201.2-.2%201.1-.9%201.7-2.2%201.7h-5.8c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.7l.2-.2h9.3c.1.4.1.9.1%201.4s-.1%201-.3%201.5H426v3.1h4.8c.1.4.2.9.2%201.4%200%20.5-.1%201-.2%201.4H426v1.6zM453.1%20131.9c0%20.5-.1.9-.2%201.4s-.3.8-.6%201.1c-.2.3-.5.6-.8.9-.3.3-.7.4-1%20.6.8.3%201.3.9%201.7%202l.6%201.8c.2.7.6%201.3%201.1%201.6-.2.3-.5.5-1%20.7-.4.2-.9.3-1.4.3-.5%200-.9-.1-1.2-.4-.3-.3-.6-.8-.8-1.5l-.8-2.3c-.2-.4-.4-.8-.6-1-.3-.2-.7-.3-1.2-.3h-.9v5.4c-.5.1-1%20.1-1.7.1s-1.3%200-1.7-.1v-14.7l.2-.2c1.3%200%202.3%200%203.2-.1h2c.8%200%201.5.1%202.2.3.6.2%201.2.5%201.7.9s.8.9%201.1%201.5c0%20.5.1%201.2.1%202zm-7.2-2.1v4.3h1.7c.5%200%20.8-.1%201.1-.3.3-.2.5-.4.6-.6.1-.3.2-.7.2-1.2%200-1.4-.7-2.1-2-2.1h-.9c-.2-.1-.5-.1-.7-.1zM466.8%20139h-.9l-.9%203.1c-.3.1-.8.1-1.4.1-.7%200-1.3-.1-1.7-.2l-.1-.2%204.8-14.5c.6-.1%201.2-.1%202-.1.9%200%201.5.1%202%20.2l4.7%2014.5c-.5.3-1.1.4-1.7.4-.8%200-1.3-.1-1.6-.4-.3-.3-.6-.8-.8-1.5l-.4-1.4h-4zm0-2.7h3.3l-.4-1.3c-.3-1.2-.7-2.7-1.2-4.5h-.1c-.1.6-.5%202-1%204.1l-.6%201.7zM489.9%20139.2h3.8c0%20.6%200%201.1-.1%201.5-.1.4-.3.8-.7%201.1-.4.3-.9.4-1.5.4h-4.9c-.6%200-1.1-.2-1.5-.5-.4-.4-.5-.9-.5-1.5v-12.8l.2-.2h1.3c1.3%200%202%20.7%202%202.2v9.9c.5-.1%201.2-.1%201.9-.1z%22%2F%3E%3C%2Fg%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M.7%2014v69.8l72.1-58.2%20109.1%2048.1V14z%22%2F%3E%3Cpath%20d%3D%22M.7%2083.8v49.4s5.8-5%2016.5-12.2C22.4%2089.1%2050%2064.8%2083.3%2064.8c15.1%200%2029%205%2040.2%2013.4%2017.9-3.3%2037.4-5.1%2058.3-4.5l-109-48.1L.7%2083.8z%22%20fill%3D%22%23c6c6c6%22%2F%3E%3Cpath%20d%3D%22M83.3%2064.8c-33.3%200-60.9%2024.3-66%2056.2%2019.9-13.2%2057-33.7%20106.3-42.8-11.2-8.4-25.2-13.4-40.3-13.4z%22%2F%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M140.2%2096.5C79.3%20100%2037.4%20119.4%2016.4%20131.8%206%20137.9.7%20142.3.7%20142.3h181.1V96.6c-14.7-.9-28.5-.9-41.6-.1z%22%2F%3E%3C%2Fsvg%3E`);
    }
    ngOnInit() {
        this.grupos = Object.keys(this.gruposLinks);
    }
}
FooterComponent.ɵfac = function FooterComponent_Factory(t) { return new (t || FooterComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"])); };
FooterComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: FooterComponent, selectors: [["br-footer"]], inputs: { invertido: "invertido", horizontal: "horizontal", urlImagem: "urlImagem", alt: "alt", urlImagem2: "urlImagem2", url2: "url2", alt2: "alt2", urlImagem3: "urlImagem3", url3: "url3", alt3: "alt3", gruposLinks: "gruposLinks", linksRedesSociais: "linksRedesSociais", exibeInformacaoLicenca: "exibeInformacaoLicenca", informacaoLicenca: "informacaoLicenca" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵInheritDefinitionFeature"]], decls: 21, vars: 20, consts: [["id", "footer"], [1, "container-fluid"], [1, "logo"], [3, "src", "alt"], ["data-toggle", "data-toggle", "data-unique", "data-unique", 3, "ngClass"], [4, "ngFor", "ngForOf"], [1, "d-none", "d-sm-block"], [1, "row", "align-items-end", "justify-content-between", "py-5"], ["class", "col social-network", 4, "ngIf"], ["id", "footer-brasil", 1, "col", "assigns", "text-right", 3, "ngStyle"], ["target", "_blank", 3, "href", "title"], [1, "ml-4", 3, "alt", "src"], ["ngClass", "br-divider my-3"], [1, "info"], [1, "text-down-01", "text-medium", "pb-3", "text-center"], [3, "horizontal", "grupo", "links"], [1, "col", "social-network"], [1, "text-up-01", "text-extra-bold", "text-uppercase"], ["target", "_blank", 1, "mr-3", 3, "href"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], [4, "ngIf"], ["aria-hidden", "true"]], template: function FooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "footer", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "img", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, FooterComponent_ng_container_5_Template, 2, 3, "ng-container", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](8, FooterComponent_div_8_Template, 4, 1, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](11, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](13, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](14, "br-divider", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassMap"]("br-footer " + (ctx.invertido ? "inverted" : ""));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", ctx.urlImagem || ctx.base64Imagem1Default, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("alt", ctx.alt);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", ctx.jc(ctx.ngClass, "br-list ", ctx.horizontal ? " horizontal " : ""));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.grupos);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", (ctx.linksRedesSociais == null ? null : ctx.linksRedesSociais.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngStyle", ctx.invertido ? _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](18, _c0) : _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](19, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", ctx.url2, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("title", ctx.alt2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("alt", ctx.alt2)("src", ctx.urlImagem2 || ctx.base64Imagem2Default, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("href", ctx.url3, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("title", ctx.alt3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("alt", ctx.alt3)("src", ctx.urlImagem3 || ctx.base64Imagem3Default, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", ctx.informacaoLicenca.label, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.informacaoLicenca.nomeLicenca);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgClass"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgStyle"], _divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_5__["DividerComponent"], _grupo_footer_grupo_footer_component__WEBPACK_IMPORTED_MODULE_6__["GrupoFooterComponent"]], encapsulation: 2 });


/***/ }),

/***/ "e18e":
/*!******************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/button/button.module.ts ***!
  \******************************************************************************/
/*! exports provided: ButtonModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony import */ var _base_base_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../base/base.module */ "KeFx");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _button_button_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./button/button.component */ "uADd");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class ButtonModule {
}
ButtonModule.ɵfac = function ButtonModule_Factory(t) { return new (t || ButtonModule)(); };
ButtonModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ButtonModule });
ButtonModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _base_base_module__WEBPACK_IMPORTED_MODULE_0__["BaseModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ButtonModule, { declarations: [_button_button_component__WEBPACK_IMPORTED_MODULE_2__["ButtonComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _base_base_module__WEBPACK_IMPORTED_MODULE_0__["BaseModule"]], exports: [_button_button_component__WEBPACK_IMPORTED_MODULE_2__["ButtonComponent"]] }); })();


/***/ }),

/***/ "feFs":
/*!**********************************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header-search-trigger/header-search-trigger.component.ts ***!
  \**********************************************************************************************************************/
/*! exports provided: HeaderSearchTriggerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderSearchTriggerComponent", function() { return HeaderSearchTriggerComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


class HeaderSearchTriggerComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
    }
    ngOnInit() { }
}
HeaderSearchTriggerComponent.ɵfac = function HeaderSearchTriggerComponent_Factory(t) { return new (t || HeaderSearchTriggerComponent)(); };
HeaderSearchTriggerComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: HeaderSearchTriggerComponent, selectors: [["br-header-search-trigger"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 0, consts: [[1, "header-search-trigger"], ["type", "button", "aria-label", "Abrir Busca", "data-toggle", "search", "data-target", ".header-search", 1, "br-button", "circle"], ["aria-hidden", "true", 1, "fas", "fa-search"]], template: function HeaderSearchTriggerComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } }, encapsulation: 2 });


/***/ }),

/***/ "h+bN":
/*!******************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/list/tipo-agrupamento-lista.enum.ts ***!
  \******************************************************************************************/
/*! exports provided: TipoAgrupamentoLista */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TipoAgrupamentoLista", function() { return TipoAgrupamentoLista; });
class TipoAgrupamentoLista {
}
TipoAgrupamentoLista.EXPANSAO = 'expansao';
TipoAgrupamentoLista.ROTULO = 'rotulo';
TipoAgrupamentoLista.DIVIDER = 'divider';


/***/ }),

/***/ "jNVx":
/*!******************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/footer/footer.module.ts ***!
  \******************************************************************************/
/*! exports provided: FooterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterModule", function() { return FooterModule; });
/* harmony import */ var _item_item_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../item/item.module */ "HJ80");
/* harmony import */ var _divider_divider_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../divider/divider.module */ "0QCI");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./footer/footer.component */ "dTQJ");
/* harmony import */ var _grupo_footer_grupo_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./grupo-footer/grupo-footer.component */ "G30h");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");






class FooterModule {
}
FooterModule.ɵfac = function FooterModule_Factory(t) { return new (t || FooterModule)(); };
FooterModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: FooterModule });
FooterModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _divider_divider_module__WEBPACK_IMPORTED_MODULE_1__["DividerModule"], _item_item_module__WEBPACK_IMPORTED_MODULE_0__["ItemModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](FooterModule, { declarations: [_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__["FooterComponent"], _grupo_footer_grupo_footer_component__WEBPACK_IMPORTED_MODULE_4__["GrupoFooterComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _divider_divider_module__WEBPACK_IMPORTED_MODULE_1__["DividerModule"], _item_item_module__WEBPACK_IMPORTED_MODULE_0__["ItemModule"]], exports: [_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__["FooterComponent"]] }); })();


/***/ }),

/***/ "lKyZ":
/*!****************************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/grupo-menu-expansao/grupo-menu-expansao.component.ts ***!
  \****************************************************************************************************************/
/*! exports provided: GrupoMenuExpansaoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GrupoMenuExpansaoComponent", function() { return GrupoMenuExpansaoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../base/base/base.component */ "qsoC");
/* harmony import */ var _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../regra-exibicao-menu.enum */ "91Fn");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../item-menu/item-menu.component */ "vyIX");






function GrupoMenuExpansaoComponent_a_1_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r2.grupo.classIconeFontAwesome);
} }
function GrupoMenuExpansaoComponent_a_1_i_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "i", 9);
} }
function GrupoMenuExpansaoComponent_a_1_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GrupoMenuExpansaoComponent_a_1_Template_a_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r4.onClickComponent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GrupoMenuExpansaoComponent_a_1_span_1_Template, 2, 2, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GrupoMenuExpansaoComponent_a_1_i_5_Template, 1, 0, "i", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.grupo.classIconeFontAwesome);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.grupo.texto);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx_r0.grupo == null ? null : ctx_r0.grupo.itens.length) > 0);
} }
function GrupoMenuExpansaoComponent_ng_container_3_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "br-item-menu", 11);
} if (rf & 2) {
    const item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("item", item_r6)("closeMenu", ctx_r7.closeMenu)("mudancaExibicaoSideMenu", ctx_r7.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r7.idSideMenuVisivel);
} }
function GrupoMenuExpansaoComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GrupoMenuExpansaoComponent_ng_container_3_br_item_menu_1_Template, 1, 4, "br-item-menu", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r6.exibicao == null || item_r6.exibicao == ctx_r1.SEMPRE || item_r6.exibicao == ctx_r1.LOGADO && ctx_r1.usuario != null || item_r6.exibicao == ctx_r1.NAO_LOGADO && ctx_r1.usuario == null);
} }
class GrupoMenuExpansaoComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].SEMPRE;
        this.LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].LOGADO;
        this.NAO_LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].NAO_LOGADO;
        //Indica se o grupo de menu está expandido ou colapsado
        this.expandido = true;
        // o EventEmitter de fechamento do menu é passado para os grupos a fim de que seja chamado
        // quando um item de menu de rota (sem uma função que trate o click) for clicado
        this.closeMenu = null;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    // o click no grupo inverte a condição de expandido ou não do próprio componente de Grupo e,
    // havendo uma função a ser acionada no click do grupo, também é invocada
    onClickComponent(event) {
        this.expandido = !this.expandido;
        //Se o grupo tiver uma função associada ao atributo 'click', invoca-a
        if (this.grupo.click) {
            this.grupo.click(this.grupo);
        }
    }
}
GrupoMenuExpansaoComponent.ɵfac = function GrupoMenuExpansaoComponent_Factory(t) { return new (t || GrupoMenuExpansaoComponent)(); };
GrupoMenuExpansaoComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: GrupoMenuExpansaoComponent, selectors: [["br-grupo-menu-expansao"]], inputs: { grupo: "grupo", usuario: "usuario", expandido: "expandido", closeMenu: "closeMenu", idSideMenuVisivel: "idSideMenuVisivel" }, outputs: { mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 4, vars: 4, consts: [["class", "menu-item", "href", "javascript: void(0)", 3, "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["href", "javascript: void(0)", 1, "menu-item", 3, "click"], ["class", "icon", 4, "ngIf"], [1, "content"], [1, "support"], ["class", "fas fa-angle-down", "aria-hidden", "true", 4, "ngIf"], [1, "icon"], ["aria-hidden", "true"], ["aria-hidden", "true", 1, "fas", "fa-angle-down"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function GrupoMenuExpansaoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GrupoMenuExpansaoComponent_a_1_Template, 6, 3, "a", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, GrupoMenuExpansaoComponent_ng_container_3_Template, 2, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.expandido ? "divisor-menu menu-folder drop-menu active" : "menu-folder drop-menu");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.idSideMenuVisivel.length == 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.grupo.itens);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"], _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_4__["ItemMenuComponent"]], styles: ["div.divisor-menu.menu-folder[_ngcontent-%COMP%] {\n    border-bottom: 1px solid var(--menu-divider);", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });


/***/ }),

/***/ "lknF":
/*!****************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/input/input.module.ts ***!
  \****************************************************************************/
/*! exports provided: InputModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputModule", function() { return InputModule; });
/* harmony import */ var _button_button_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../button/button.module */ "e18e");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _input_input_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./input/input.component */ "qnra");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");





class InputModule {
}
InputModule.ɵfac = function InputModule_Factory(t) { return new (t || InputModule)(); };
InputModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: InputModule });
InputModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](InputModule, { declarations: [_input_input_component__WEBPACK_IMPORTED_MODULE_2__["InputComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _button_button_module__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]], exports: [_input_input_component__WEBPACK_IMPORTED_MODULE_2__["InputComponent"]] }); })();


/***/ }),

/***/ "mhda":
/*!****************************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/grupo-menu-dividers/grupo-menu-dividers.component.ts ***!
  \****************************************************************************************************************/
/*! exports provided: GrupoMenuDividersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GrupoMenuDividersComponent", function() { return GrupoMenuDividersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../regra-exibicao-menu.enum */ "91Fn");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../item-menu/item-menu.component */ "vyIX");






function GrupoMenuDividersComponent_ng_container_2_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "br-item-menu", 3);
} if (rf & 2) {
    const item_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("item", item_r1)("closeMenu", ctx_r2.closeMenu)("mudancaExibicaoSideMenu", ctx_r2.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r2.idSideMenuVisivel);
} }
function GrupoMenuDividersComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GrupoMenuDividersComponent_ng_container_2_br_item_menu_1_Template, 1, 4, "br-item-menu", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r1.exibicao == null || item_r1.exibicao == ctx_r0.SEMPRE || item_r1.exibicao == ctx_r0.LOGADO && ctx_r0.usuario != null || item_r1.exibicao == ctx_r0.NAO_LOGADO && ctx_r0.usuario == null);
} }
class GrupoMenuDividersComponent extends _base__WEBPACK_IMPORTED_MODULE_1__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].SEMPRE;
        this.LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].LOGADO;
        this.NAO_LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_2__["RegraExibicaoMenu"].NAO_LOGADO;
        // o EventEmitter de fechamento do menu é passado para os grupos a fim de que seja chamado
        // quando um item de menu de rota (sem uma função que trate o click) for clicado
        this.closeMenu = null;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
}
GrupoMenuDividersComponent.ɵfac = function GrupoMenuDividersComponent_Factory(t) { return new (t || GrupoMenuDividersComponent)(); };
GrupoMenuDividersComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: GrupoMenuDividersComponent, selectors: [["br-grupo-menu-dividers"]], inputs: { grupo: "grupo", usuario: "usuario", closeMenu: "closeMenu", idSideMenuVisivel: "idSideMenuVisivel" }, outputs: { mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 1, consts: [[1, "menu-folder", "divisor-menu"], [4, "ngFor", "ngForOf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function GrupoMenuDividersComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GrupoMenuDividersComponent_ng_container_2_Template, 2, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.grupo.itens);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_4__["ItemMenuComponent"]], styles: ["div.divisor-menu.menu-folder[_ngcontent-%COMP%] {\n      border-bottom: 1px solid var(--menu-divider);", "a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });


/***/ }),

/***/ "oH45":
/*!************************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header-functions/header-functions.component.ts ***!
  \************************************************************************************************************/
/*! exports provided: HeaderFunctionsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderFunctionsComponent", function() { return HeaderFunctionsComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");




function HeaderFunctionsComponent_ng_container_7_i_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "i", 11);
} if (rf & 2) {
    const funcionalidade_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassMap"](funcionalidade_r1.classIconeFontAwesome);
} }
function HeaderFunctionsComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function HeaderFunctionsComponent_ng_container_7_Template_button_click_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5); const funcionalidade_r1 = ctx.$implicit; const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return funcionalidade_r1.funcao ? funcionalidade_r1.funcao($event) : ctx_r4._; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, HeaderFunctionsComponent_ng_container_7_i_3_Template, 1, 2, "i", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const funcionalidade_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("aria-label", funcionalidade_r1.texto);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", funcionalidade_r1.classIconeFontAwesome);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](funcionalidade_r1.texto);
} }
class HeaderFunctionsComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.TIPOLINK_ROTA = _base__WEBPACK_IMPORTED_MODULE_1__["TipoLink"].ROTA;
        this.TIPOLINK_URL = _base__WEBPACK_IMPORTED_MODULE_1__["TipoLink"].URL;
        this.funcionalidades = [];
    }
}
HeaderFunctionsComponent.ɵfac = function HeaderFunctionsComponent_Factory(t) { return new (t || HeaderFunctionsComponent)(); };
HeaderFunctionsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: HeaderFunctionsComponent, selectors: [["br-header-functions"]], inputs: { funcionalidades: "funcionalidades" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵInheritDefinitionFeature"]], decls: 8, vars: 1, consts: [[1, "header-functions", "dropdown"], ["type", "button", "data-toggle", "dropdown", "aria-label", "Abrir Funcionalidades do Sistema", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-th"], [1, "br-list"], [1, "header"], [1, "title"], [4, "ngFor", "ngForOf"], [1, "align-items-center", "br-item"], ["type", "button", 1, "br-button", "circle", "small", 3, "aria-label", "click"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], [1, "text"], ["aria-hidden", "true"]], template: function HeaderFunctionsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Funcionalidades do Sistema");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](7, HeaderFunctionsComponent_ng_container_7_Template, 6, 3, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.funcionalidades);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"]], encapsulation: 2 });


/***/ }),

/***/ "oaOO":
/*!**********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/item-menu.interface.ts ***!
  \**********************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "p1lB":
/*!**************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/app.component.ts ***!
  \**************************************************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var dsgov_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! dsgov-components */ "3dAS");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _usuario__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./usuario */ "JaEA");
/* harmony import */ var _dsgov_components_src_lib_components_header_header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../dsgov-components/src/lib/components/header/header/header.component */ "B20u");
/* harmony import */ var _dsgov_components_src_lib_components_menu_menu_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../dsgov-components/src/lib/components/menu/menu/menu.component */ "ApSJ");
/* harmony import */ var _dsgov_components_src_lib_components_breadcrumb_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../dsgov-components/src/lib/components/breadcrumb/breadcrumb/breadcrumb.component */ "R1os");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _dsgov_components_src_lib_components_footer_footer_footer_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../dsgov-components/src/lib/components/footer/footer/footer.component */ "dTQJ");









const _c0 = function () { return { tipo: "url", texto: "Portal", url: "http://gov.br/ancine" }; };
const _c1 = function () { return { tipo: "url", texto: "SAVI", url: "http://savi.ancine.gov.br" }; };
const _c2 = function (a0, a1) { return [a0, a1]; };
class AppComponent {
    constructor(userService, document) {
        this.userService = userService;
        this.document = document;
        // Constantes utilizadas no template
        this.AGRUPAMENTO_EXPANSAO = dsgov_components__WEBPACK_IMPORTED_MODULE_1__["TipoAgrupamentoLista"].EXPANSAO;
        this.AGRUPAMENTO_ROTULO = dsgov_components__WEBPACK_IMPORTED_MODULE_1__["TipoAgrupamentoLista"].ROTULO;
        this.AGRUPAMENTO_DIVIDER = dsgov_components__WEBPACK_IMPORTED_MODULE_1__["TipoAgrupamentoLista"].DIVIDER;
        this.usarContraste = false;
        this.menuVisivel = false;
        this.linksCabecalho = [];
        this.funcionalidadesCabecalho = [];
        this.linksRodape = {};
        this.linksRedesSociaisRodape = [];
        this.itensMenu = [];
        this.itensBreadcrumb = [
            { label: 'Página Ancestral 01', link: 'http://ancestral01' },
            { label: 'Página Ancestral 02', link: 'http://ancestral02' },
            { label: 'Página atual', link: 'http://paginatual' },
        ];
        this.titulo = 'DSGov Angular Demo';
        __webpack_require__(/*! ./menu.json */ "0BJg").forEach((item) => {
            this.itensMenu.push(item);
        });
        //menu logout
        const logout = {
            texto: 'Sair',
            exibicao: dsgov_components__WEBPACK_IMPORTED_MODULE_1__["RegraExibicaoMenu"].LOGADO,
            classIconeFontAwesome: 'fas fa-door-open',
            click: this.logout.bind(this),
            itens: [],
        };
        this.itensMenu.push(logout);
        //definindo Usuario
        //this.user = { jti: 'testonildo', exp: new Date().getTime(), groups: [], upn: 'xxx' };
        //Links cabeçalho
        this.linksCabecalho = __webpack_require__(/*! ./linksCabecalho.json */ "EbzX");
        // funcionalidades cabecalho
        this.funcionalidadesCabecalho = [
            {
                classIconeFontAwesome: 'fas fa-comment',
                texto: 'Chat',
                funcao: () => {
                    alert('O chat ainda não está implementado');
                },
            },
            {
                classIconeFontAwesome: 'fas fa-adjust',
                texto: 'Mudar para o modo de alto contraste',
                funcao: this.aplicarContraste.bind(this),
            },
        ];
        // Links rodape
        this.linksRodape = __webpack_require__(/*! ./rodape.json */ "NcNF");
        // Links rodape
        this.linksRedesSociaisRodape = __webpack_require__(/*! ./redesSociais.json */ "75Kr");
    }
    onClickMenu(event) {
        this.menuVisivel = true;
    }
    fechaMenu() {
        this.menuVisivel = false;
    }
    signin(event) {
        //this.document.location.href = `https://ssodev.ancine.gov.br/cas/login?redirect_uri=${this.document.location.href}`;
        this.user$ = this.userService.getUsuario();
        this.user$.subscribe((user) => {
            if (user == null) {
                this.user = {};
            }
            else {
                this.user = user;
            }
            this.user.nomeCompleto = 'José da Silva';
            this.user.email = 'josedasilva@dsgov.br';
            this.user.imgAvatar =
                'data:image/jpeg;base64,/9j/4QBKRXhpZgAATU0AKgAAAAgAAwEaAAUAAAABAAAAMgEbAAUAAAABAAAAOgEoAAMAAAABAAIAAAAAAAAAAAEsAAAAAQAAASwAAAAB/9sAQwAGBAUGBQQGBgUGBwcGCAoQCgoJCQoUDg8MEBcUGBgXFBYWGh0lHxobIxwWFiAsICMmJykqKRkfLTAtKDAlKCko/9sAQwEHBwcKCAoTCgoTKBoWGigoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgo/8IAEQgAZgBmAwEiAAIRAQMRAf/EABsAAAEFAQEAAAAAAAAAAAAAAAACAwQFBgEH/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAEDAgT/2gAMAwEAAhADEAAAAdiCeWjeBYptjmgcglPQ5XknqmcPnDDVzvA4KGmULaF4xsq2HS11AdezZx1uGs+krqLLMHlNqEo4A20poMnXabDaqP1Wj3qq5fUQvQbKrsZSfU0tJZwQ226ljGW1rLfk021wN3eQot0Ho1tltXB9UnqysQApIsTTc6ulTKZb0bG11Tzh/dZd7VWeVoXam2OZQkEibXzp7Q2qZy1h43dUXTjKOznrXRZszyT9qkjKAPlFBmBPSJActexQ2RooX57KeDfYwSp0CuP/xAAmEAACAgECBQUBAQAAAAAAAAABAgADBBESBRAgISIGExQxMiMw/9oACAEBAAEFAuV1qU15PqA714xma4XHiWx7kvr/AMPUeW/vYmBviY6qLMauwYeS/DshHDr1E9kDX56EAX2F66iwFuOLa+G5VuNUp1HSZxBPjcVO1pQwrrptFjG/RrX0twW1xx0mcep3VY4QLegssJpqFqnfafDB0+KOkziNb2Y2/bCre5jfGx1Dh5muswxsxoOkzP4ebIj+3YL61l+ZuCE2W8NbdjDqM0nqDH15IusxqtDwuwI3MDy5aax+y5u66s46gsukq7RJjXukRw45qNSe0uHuvm0/x2zb5KO9SxEi6pCNOadpb9UpLl1S+sBhXBXKqxERZWgM2+LeJH618n/Q+jMundAvf24lcSjWIm0M2kfvB+j9L3IPY/R/VlMC6GqrWVqIT5P5WGf/xAAeEQACAgIDAQEAAAAAAAAAAAAAAQIRECEDEiATMf/aAAgBAwEBPwEScvw+T9cWsOKY1Xjjw9eUd2iNydklT8KJHehRoaTJKnWI4vq7LJTSEr2yiGZaYs//xAAcEQACAgMBAQAAAAAAAAAAAAAAAQIRAxAgITH/2gAIAQIBAT8BEl9ZaHxZL3m+XxZFWSpD4lMxsbvjJ4XbIS18JS9EzLpEWPSP/8QAKxAAAQMCBQIFBQEAAAAAAAAAAQACEQMxEBIgIVETQSIwYXGBBDJCUmJy/9oACAEBAAY/AsDUqGGhEfT0xl5cjFQn4Qb9U0AfsFnpmR5PQB8EDZB1W3C8LQvt+Qhc0TcIOaZB3Gso9S+aStzCPT2HKyjb/S8V02jUbma10T6eQY/NshHYufyg2qUcjI9XKHbFNLTdCe2tldt6R39lKbvLuFu4ud6JvhMuwplvcTrcKZg391lK7kHhbDM/9nBZogI5VRb/AD5BNGJ4RZVEEK0qG2QQ9PJZVF7Yyi1xvonQTwiT9nZWUDGDu1SNXT/G5RA41S35Gn3Rce+EaLqQt1CCGiRdQdjjJtoGE4wbLaPldlvhCA43w//EACMQAQACAgIDAAMAAwAAAAAAAAEAESExEFFBYXEggZGx0eH/2gAIAQEAAT8h4J2e1YegmDb9qDaw7DUbiMU6+k3IqXyfiyzG3PqOV0sg3K2cPUZXAPq5/wB/sqvOzs4ueOSJi3WIx3brPstx9IXJ8ghmmnnT9dzXnRIBBLJkkARsc/isE+pw9zUgbbqUSb1DJK6LfyDRkGrDVjk2VTaD3Lgx1NYhe/7SWSHdxwyFy0ESUz9SFUHJluyripdf7ll5Q5RQYPCxSom6dOpjdBqNQYP2rzAnfPQOqgigOnUZTy1ANboEL/CxILm/RmzUREZVPiZFs9xdBtFN0Nza84cCEI82CIKpZiurYnjKRyk4a/Ya5yLOqrm0UcaI0rOnfuXQiwaJ4JcZtDqdk8VeDmgIqANmn7fUsO9I95ddE8uW8WCV2/SJvqEuGgR1Q2qidh3L/siOnyZFqd08lgNw4ZAiWkBWH/SFPpFZPbMATWaZRcTTPQwyhXCeT0hB/iVrYMVJre5v7Ij+7gDygLBajbSISmp30V6IDJNN4i6XJ7in/9oADAMBAAIAAwAAABDB5GxyD3WCF4GLAyIKCQ89at2HkQIWE9H8wAjMmNYLCCMJ3yL/AP/EAB0RAQEBAAIDAQEAAAAAAAAAAAEAESExECBBUWH/2gAIAQMBAT8Q2ayZG7YnD65HHc5OC2zLLPHE21XgmiVXXxl3L4SfIEXXpAfl+sR6+QdIjHyQ/Z6j+NZeS5lkTT4CwY9ETdvk3//EABsRAAMBAQEBAQAAAAAAAAAAAAABESExEFFh/9oACAECAQE/EBJA+cFmjeiZfDY+eV8Gt8gtE6khqdKnh2UgkKBC0YNMXlhTEPkOQ/CQgzSIQFrDo2tMpgotOxdGHQdwfTg//8QAJBABAAICAgICAwADAAAAAAAAAQARITFBUWFxgaEQkcGx0fD/2gAIAQEAAT8QCvx/IShjt8Q4OxBW9Br0yyYLoAdBWJnfwcbb6O6lEWOndO/U8cQLlskDzEVfw5ZY1GJakFobu/qKdLRZHmCS9TusqkFUKREj8SdFPDoQXI4dJkYOLmjUHGGyJcsYYNQpXyrEIemvFFiDaU0HbK2srBahKBozQ8DKgo0LFSPcRhYWYcJ4L/UGGCiOxg9QWi/iVuDf4gtFw7hNLQZG1v7IipzrheOD1lg82VGreo9EaBhXtFF0cNjGnBOIR6HxAQpZzx/zOa2IbYh+sqWY2iLsUzaALbi34afmLGBUrO8/2B+gjlW41Yzzqjg6hB3qUUWVeCZT0edmxKXW+7KmfuJLN5IEW2bs4ndqPtqKlhbfsiL8CHDFQrdmRS2l81E8GCsq4BprbuXdusAHLQQPyg7Y1CjIWOMzqisLmMVqE6dwEfEW3BCHWMNR5p6iBpLaoakLmEoDNg5hiqCkE2SrPGz/ADFb4mEVkXBxDUcw0e5mxcGFeIUqZLmfY+Y9dk7qby1xCGGFugQ7cQG74/DcyPRvfuILUqLMDRCLhWrM31ZzPB/iUhrd5lJ66BNXSZEq5SdbS/QwQyprWR6gvEdMWPUYDc00Dcp4Fixa8enMwkiyvCZiXQSyLNMOo9qN7iDLNFS3hIdH/ZxKqjbTLM6m4TGV3B4yf2y0fWeDiPUOQ8w30rNunU7MYQlC+5YMPqDioTI57PLN11N9R0W1p8T9VjgdMLgsN9RghoCO6JiDcFlnQjwyxMDYUwvWKsj6hGx5NxvCsY6QHua0G1iBsfca94S6l0tj6gBGiHw+ZZdWxIbdGLfFItPmXCxxhjmvDkq+pa3NYLivCzb5ji4H2GHeBn//2Q==';
        });
    }
    logout(event) {
        this.fechaMenu();
        this.user = null;
        this.userService.logout();
    }
    aplicarContraste() {
        this.usarContraste = !this.usarContraste;
        if (this.usarContraste) {
            this.document.body.classList.add('contraste-dsgov');
            this.document.body.style.backgroundColor = '#000000';
        }
        else {
            this.document.body.classList.remove('contraste-dsgov');
            this.document.body.style.backgroundColor = '#FFFFFF';
        }
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_usuario__WEBPACK_IMPORTED_MODULE_3__["UsuarioService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_0__["DOCUMENT"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 25, vars: 17, consts: [[1, "template-base"], ["id", "skip-links"], ["aria-label", "Acesso r\u00E1pido", 1, "skip-links"], ["accesskey", "1", "href", "#main-content"], [1, "accesskey"], ["accesskey", "2", "href", "#main-navigation"], ["accesskey", "3", "href", "#main-searchbox"], ["subtitulo", "Vers\u00E3o: 1.0.0", 3, "links", "funcionalidades", "usuario", "titulo", "onOpenMenu", "clickEntrar", "clickSair", "clickMenu"], ["id", "main", 1, "d-flex", "flex-fill"], [1, "container-fluid", "d-flex"], [1, "row"], ["titulo", "Sistema Demo", 3, "visivel", "usuario", "grupos", "linksExternos", "tipoAgrupamentoMenu", "closeMenu"], [1, "col", "pt-3", "pb-5"], [3, "itens"], ["id", "main-content", 1, "main-content", "pl-sm-3"], ["urlImagem", "assets/govbr-negativo.png", 3, "gruposLinks", "linksRedesSociais"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "nav", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, " Ir para o Conte\u00FAdo");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "strong", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "1");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "a", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, " Ir para para Navega\u00E7\u00E3o");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "strong", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "2");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "a", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12, " Ir para para Busca");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "strong", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14, "3");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "br-header", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("onOpenMenu", function AppComponent_Template_br_header_onOpenMenu_15_listener() { return ctx.menuVisivel = true; })("clickEntrar", function AppComponent_Template_br_header_clickEntrar_15_listener($event) { return ctx.signin($event); })("clickSair", function AppComponent_Template_br_header_clickSair_15_listener($event) { return ctx.logout($event); })("clickMenu", function AppComponent_Template_br_header_clickMenu_15_listener($event) { return ctx.onClickMenu($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "main", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "br-menu", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("closeMenu", function AppComponent_Template_br_menu_closeMenu_19_listener() { return ctx.fechaMenu(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](21, "br-breadcrumb", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](23, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](24, "br-footer", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("links", ctx.linksCabecalho)("funcionalidades", ctx.funcionalidadesCabecalho)("usuario", ctx.user)("titulo", ctx.titulo);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("visivel", ctx.menuVisivel)("usuario", ctx.user)("grupos", ctx.itensMenu)("linksExternos", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction2"](14, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](12, _c0), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](13, _c1)))("tipoAgrupamentoMenu", ctx.AGRUPAMENTO_EXPANSAO);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("itens", ctx.itensBreadcrumb);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("gruposLinks", ctx.linksRodape)("linksRedesSociais", ctx.linksRedesSociaisRodape);
    } }, directives: [_dsgov_components_src_lib_components_header_header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"], _dsgov_components_src_lib_components_menu_menu_menu_component__WEBPACK_IMPORTED_MODULE_5__["MenuComponent"], _dsgov_components_src_lib_components_breadcrumb_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_6__["BreadcrumbComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterOutlet"], _dsgov_components_src_lib_components_footer_footer_footer_component__WEBPACK_IMPORTED_MODULE_8__["FooterComponent"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ "qnra":
/*!*************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/input/input/input.component.ts ***!
  \*************************************************************************************/
/*! exports provided: InputComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InputComponent", function() { return InputComponent; });
/* harmony import */ var _base_densidade_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/densidade.enum */ "ICPe");
/* harmony import */ var _estado_input_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../estado-input.enum */ "PISc");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _button_button_button_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../button/button/button.component */ "uADd");








function InputComponent_label_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "label", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("for", ctx_r0.id)("ngClass", ctx_r0.ngClassLabel);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r0.textoLabel);
} }
function InputComponent_br_button_3_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "br-button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function InputComponent_br_button_3_Template_br_button_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r3.onClickButton($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "i", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r1.jc(ctx_r1.ngClassButton, "circle", "small"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](ctx_r1.classIconeFontAwesomeBotao);
} }
function InputComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "i", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"]("feedback mt-1 " + ctx_r2.estado);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](ctx_r2.iconesEstado[ctx_r2.estado]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r2.textoFeedback);
} }
const _c0 = ["*"];
class InputComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.ESTADO_DEFAULT = _estado_input_enum__WEBPACK_IMPORTED_MODULE_1__["EstadoInput"].DEFAULT;
        //ícones feedback
        this.iconesEstado = {
            success: 'fas fa-check-circle',
            danger: 'fas fa-times-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle',
        };
        //Evento de click
        this.click = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        // Evento de mudança de valor
        this.change = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        // Evento de pressiona tecla
        this.keypress = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        //Evento de click do botao dentro do input
        this.clickButton = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        //atributos input HTML
        this.type = 'text';
        this.placeHolder = '';
        this.required = false;
        // Estado do componente input
        this.estado = _estado_input_enum__WEBPACK_IMPORTED_MODULE_1__["EstadoInput"].DEFAULT;
        // Densidade dos itens de menu. Default: densidade medium
        this.densidade = _base_densidade_enum__WEBPACK_IMPORTED_MODULE_0__["Densidade"].MEDIA;
        // classes aplicáveis ao <label></label>
        this.ngClassLabel = '';
        // classes aplicáveis ao <input></input>
        this.ngClassInput = '';
        // classes aplicáveis ao <button></button>
        this.ngClassButton = '';
    }
    ngOnInit() {
        if (!this.id) {
            this.id = this.textoLabel;
        }
    }
    onClickButton(event) {
        //The mouseEvent propagates from the child component to the parent component by default.
        //You can stop propagation of event to parent component.
        event.stopPropagation();
        this.clickButton.emit(event);
    }
}
InputComponent.ɵfac = function InputComponent_Factory(t) { return new (t || InputComponent)(); };
InputComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: InputComponent, selectors: [["br-input"]], inputs: { type: "type", maxLength: "maxLength", min: "min", max: "max", pattern: "pattern", placeHolder: "placeHolder", step: "step", required: "required", formControlName: "formControlName", textoLabel: "textoLabel", classIconeFontAwesomeBotao: "classIconeFontAwesomeBotao", ariaLabelButton: "ariaLabelButton", textoFeedback: "textoFeedback", estado: "estado", isDisabled: "isDisabled", densidade: "densidade", ngClassLabel: "ngClassLabel", ngClassInput: "ngClassInput", ngClassButton: "ngClassButton" }, outputs: { click: "click", change: "change", keypress: "keypress", clickButton: "clickButton" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c0, decls: 6, vars: 20, consts: [[3, "for", "ngClass", 4, "ngIf"], [3, "ngClass", "id", "type", "disabled", "maxLength", "min", "max", "pattern", "placeholder", "step"], [3, "ngClass", "click", 4, "ngIf"], ["role", "alert", 3, "class", 4, "ngIf"], [3, "for", "ngClass"], [3, "ngClass", "click"], ["aria-hidden", "true"], ["role", "alert"]], template: function InputComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, InputComponent_label_1_Template, 2, 3, "label", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, InputComponent_br_button_3_Template, 2, 3, "br-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, InputComponent_span_4_Template, 3, 5, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵprojection"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](ctx.jc(ctx.ngClass, "br-input", ctx.densidade, ctx.estado, ctx.classIconeFontAwesomeBotao != null ? " has-icon " : ""));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.textoLabel);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("disabled", ctx.isDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx.jc(ctx.ngClassInput, ctx.estado, ctx.densidade, ctx.classIconeFontAwesomeBotao != null ? "has-icon" : ""))("id", ctx.id)("type", ctx.type)("ngClass", ctx.ngClassInput)("disabled", ctx.isDisabled ? "disabled" : "")("maxLength", ctx.maxLength)("min", ctx.min)("max", ctx.max)("pattern", ctx.pattern)("placeholder", ctx.placeHolder)("step", ctx.step);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("formControlName", ctx.formControlName)("required", ctx.required);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.classIconeFontAwesomeBotao);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.estado != ctx.ESTADO_DEFAULT && ctx.textoFeedback);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgClass"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControlName"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["PatternValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["RequiredValidator"], _button_button_button_component__WEBPACK_IMPORTED_MODULE_6__["ButtonComponent"]], encapsulation: 2 });


/***/ }),

/***/ "qsoC":
/*!**********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/base/base.component.ts ***!
  \**********************************************************************************/
/*! exports provided: BaseComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseComponent", function() { return BaseComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class BaseComponent {
    constructor() {
        /*** Classes aplicáveis ao componente (setadas em sua declaração no template do componente/página onde é utilizado) ***/
        this.ngClass = '';
    }
    /**
     * Recebe um {ngClass}, que pode ser uma string, array ou set de strings, e uma sequência de
     * parâmetros do tipo string. Filtra os nulos e realizada uma concatenação separada por espaços.
     * Utilizada para aplicar coleção de classes CSS em determinado elemento HTML
     *
     * @param ngClass string, array ou set de strings com classes CSS
     * @param classesCSS sequência de nomes de classes CSS
     * @returns classes CSS aplicáveis separadas por espaço
     */
    jc(ngClass, ...classesCSS) {
        return (classesCSS.filter((classe) => classe != null).join(' ') +
            (ngClass ? ' ' + ngClass : ''));
    }
}
BaseComponent.ɵfac = function BaseComponent_Factory(t) { return new (t || BaseComponent)(); };
BaseComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: BaseComponent, selectors: [["br-base"]], inputs: { id: "id", ngClass: "ngClass" }, decls: 0, vars: 0, template: function BaseComponent_Template(rf, ctx) { }, encapsulation: 2 });


/***/ }),

/***/ "s3Ha":
/*!************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/logoGovBr.ts ***!
  \************************************************************************/
/*! exports provided: base64LogoGovBr */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "base64LogoGovBr", function() { return base64LogoGovBr; });
//logo gov.br
const base64LogoGovBr = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG8AAAAoCAMAAADHRlSGAAAAeFBMVEUAAAD5vRAoZK0oZK4odpQnY676vRD6vRAxd5IoZK8oY65GrUQnY64nZqolZa8oY677vRAmY6//vxBErUP6vRBFrUNFrUQnZK75vBBFrEP8vBD6vxBFrENFqkYnY676vRAoYq3/vxBErURGrEO7tyIoZK76vRBGrUS/9hXBAAAAJXRSTlMAwYDAEPDw1iBAoH/QcDDgf1AQZ2TawLCqmEUw8LCQkGAgOFCUOz6uWgAAAthJREFUWMPtltt2qjAQQIeEewUFsQh47wn9/z88NZkLINaX6pP7yWjIdiYzs4A/wjgUPODte/vevlvyJEnyV/l8tbS7lycA0O5JcLTHqL/irbrr8sOxBuRCa/HFmb4elRZ2Q7WyXD95Yd9H8EMRGGLhj3yrqBeiFmD/7fDRh+sP8Sk+TF83ee5ZKO1J1ncyA5a++Dq0MdvyC30U4M4tY/alRghi8eFRHkAcmCE1+7qwnxKVKGicDvWffH94FmeLfFXPvtrMAiXrhsLGGXbO13C0ZhZFvpB9Mf+YZlkaiG/b49aqLdsjCf9hQi/Wt+HbHGRR6yUvfG9yI5DRNtsN8YJ2dqTrXJ3SEhUfdrckV/41/JDRKvNE1Z7hfIZ61DlymxRRBY7jOMAN/LB2n7/QxzoRavTJORQQVTgVWITxAHKmvznoiL3cpZkcQyn1OJEIlRIuuTv4gokQv/jkGvEHtUrxAHKY+OytzG1Mxr4V+zz0YRL33A2XuXmmxr4Q7sVXPPBF/o6y2OBNPvRJmiTRtE4f5RMaCmtDiRVfzfm859P4wwlHdzCul+imXiiNzQVn2dAXALK451M8OO2yNpN+aHHfiusa49qs8R4t3HDjKtA3vpznQuFDoQ3R8cgEABmmYclTDNNZ1DoTX5DYLFF4B/FJ5LOAR8IKoKzCQf3E38JOuWqTB9MiOQS0iG99yR3fGRWMRLsR3x7TaGap4cYnpTR+kkamIMN0LT7cntJ9mSGBP/FJC8j8Yx+04TS6DouYdRvMjqL8BUNdDrM+SJZUpAXEg/4vt0NjKL2/J18DC3cy/ct8IboCJj4hV6mu1XVDMZpvZYXKaFuBcPlEYogX9mTOip/hu5eyDXb0LEe4h6abFs5tCb8Q5zfvlirJf3sAhBP37fMwacEvogbJ4XnY+0qVOkg1a3gW8w2fAPMK3wGEF/gUPJN8ORl6OTyZ+KS0Duyrqjr58Ez+A7sTAiW6Xr/YAAAAAElFTkSuQmCC';


/***/ }),

/***/ "slRD":
/*!*********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/base/informacao-licenca.ts ***!
  \*********************************************************************************/
/*! exports provided: InformacaoLicenca */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InformacaoLicenca", function() { return InformacaoLicenca; });
/**
 * Estrutura com o texto de apresentação da licença e o nome da própria licença,
 * que vem em negrito em determinados componentes do DSGov
 */
class InformacaoLicenca {
    constructor() {
        this.label = 'Todo o conteúdo deste site está publicado sob a licença';
        this.nomeLicenca = 'Creative Commons Atribuição-SemDerivações 3.0';
    }
}


/***/ }),

/***/ "uADd":
/*!****************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/button/button/button.component.ts ***!
  \****************************************************************************************/
/*! exports provided: ButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonComponent", function() { return ButtonComponent; });
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");




const _c0 = ["*"];
class ButtonComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_0__["BaseComponent"] {
    constructor() {
        super();
        //Evento de click
        this.click = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    ngOnInit() { }
    onClickComponent(event) {
        this.click.emit(event);
    }
}
ButtonComponent.ɵfac = function ButtonComponent_Factory(t) { return new (t || ButtonComponent)(); };
ButtonComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ButtonComponent, selectors: [["br-button"]], inputs: { isDisabled: "isDisabled", isActive: "isActive", isLoading: "isLoading" }, outputs: { click: "click" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], ngContentSelectors: _c0, decls: 2, vars: 7, consts: [["type", "button", 3, "ngClass", "click"]], template: function ButtonComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ButtonComponent_Template_button_click_0_listener($event) { return ctx.onClickComponent($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵprojection"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("disabled", ctx.isDisabled)("active", ctx.isActive)("loading", ctx.isLoading);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.jc(ctx.ngClass, "br-button"));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"]], encapsulation: 2 });


/***/ }),

/***/ "v+A7":
/*!**************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/menu.module.ts ***!
  \**************************************************************************/
/*! exports provided: MenuModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuModule", function() { return MenuModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./item-menu/item-menu.component */ "vyIX");
/* harmony import */ var _menu_menu_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./menu/menu.component */ "ApSJ");
/* harmony import */ var _grupo_menu_expansao_grupo_menu_expansao_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./grupo-menu-expansao/grupo-menu-expansao.component */ "lKyZ");
/* harmony import */ var _grupo_menu_rotulos_grupo_menu_rotulos_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./grupo-menu-rotulos/grupo-menu-rotulos.component */ "CwvZ");
/* harmony import */ var _grupo_menu_dividers_grupo_menu_dividers_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./grupo-menu-dividers/grupo-menu-dividers.component */ "mhda");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








class MenuModule {
}
MenuModule.ɵfac = function MenuModule_Factory(t) { return new (t || MenuModule)(); };
MenuModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: MenuModule });
MenuModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](MenuModule, { declarations: [_menu_menu_component__WEBPACK_IMPORTED_MODULE_3__["MenuComponent"], _item_menu_item_menu_component__WEBPACK_IMPORTED_MODULE_2__["ItemMenuComponent"], _grupo_menu_expansao_grupo_menu_expansao_component__WEBPACK_IMPORTED_MODULE_4__["GrupoMenuExpansaoComponent"], _grupo_menu_rotulos_grupo_menu_rotulos_component__WEBPACK_IMPORTED_MODULE_5__["GrupoMenuRotulosComponent"], _grupo_menu_dividers_grupo_menu_dividers_component__WEBPACK_IMPORTED_MODULE_6__["GrupoMenuDividersComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_menu_menu_component__WEBPACK_IMPORTED_MODULE_3__["MenuComponent"]] }); })();


/***/ }),

/***/ "v7YH":
/*!************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/tamanho-header.enum.ts ***!
  \************************************************************************************/
/*! exports provided: TamanhoHeader */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TamanhoHeader", function() { return TamanhoHeader; });
class TamanhoHeader {
}
TamanhoHeader.DEFAULT = '';
TamanhoHeader.LARGE = 'large';
TamanhoHeader.SMALL = 'small';
TamanhoHeader.COMPACT = 'compact';


/***/ }),

/***/ "vBmv":
/*!****************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header-links/header-links.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: HeaderLinksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderLinksComponent", function() { return HeaderLinksComponent; });
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");




function HeaderLinksComponent_ng_container_7_i_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "i", 10);
} if (rf & 2) {
    const link_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassMap"](link_r1.classIconeFontAwesome);
} }
function HeaderLinksComponent_ng_container_7_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const link_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](link_r1.texto);
} }
function HeaderLinksComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "a", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, HeaderLinksComponent_ng_container_7_i_2_Template, 1, 2, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, HeaderLinksComponent_ng_container_7_span_3_Template, 2, 1, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const link_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("routerLink", link_r1.tipo == ctx_r0.TIPOLINK_ROTA ? link_r1.url : null)("href", link_r1.tipo == ctx_r0.TIPOLINK_URL ? link_r1.url : null, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("target", link_r1.tipo == ctx_r0.TIPOLINK_URL && link_r1.novaAba ? "_blank" : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", link_r1.classIconeFontAwesome);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", link_r1.texto);
} }
class HeaderLinksComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_1__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.TIPOLINK_ROTA = _base__WEBPACK_IMPORTED_MODULE_0__["TipoLink"].ROTA;
        this.TIPOLINK_URL = _base__WEBPACK_IMPORTED_MODULE_0__["TipoLink"].URL;
        this.links = [];
    }
}
HeaderLinksComponent.ɵfac = function HeaderLinksComponent_Factory(t) { return new (t || HeaderLinksComponent)(); };
HeaderLinksComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: HeaderLinksComponent, selectors: [["br-header-links"]], inputs: { links: "links" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵInheritDefinitionFeature"]], decls: 8, vars: 1, consts: [[1, "header-links", "dropdown"], ["type", "button", "data-toggle", "dropdown", "aria-label", "Abrir Acesso R\u00E1pido", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-ellipsis-v"], [1, "br-list"], [1, "header"], [1, "title"], [4, "ngFor", "ngForOf"], [1, "br-item", 3, "routerLink", "href", "target"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], ["class", "text", 4, "ngIf"], ["aria-hidden", "true"], [1, "text"]], template: function HeaderLinksComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Acesso R\u00E1pido");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](7, HeaderLinksComponent_ng_container_7_Template, 4, 5, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.links);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"]], encapsulation: 2 });


/***/ }),

/***/ "vyIX":
/*!********************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/menu/item-menu/item-menu.component.ts ***!
  \********************************************************************************************/
/*! exports provided: ItemMenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemMenuComponent", function() { return ItemMenuComponent; });
/* harmony import */ var _base_tipo_link_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../base/tipo-link.enum */ "T+sX");
/* harmony import */ var _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../regra-exibicao-menu.enum */ "91Fn");
/* harmony import */ var _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../base/base/base.component */ "qsoC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");






function ItemMenuComponent_li_0_a_1_i_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "i", 6);
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](ctx_r4.item == null ? null : ctx_r4.item.link == null ? null : ctx_r4.item.link.classIconeFontAwesome);
} }
function ItemMenuComponent_li_0_a_1_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r5.item.link.texto);
} }
function ItemMenuComponent_li_0_a_1_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "a", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ItemMenuComponent_li_0_a_1_Template_a_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2); return ctx_r6.onClickComponent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ItemMenuComponent_li_0_a_1_i_1_Template, 1, 2, "i", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, ItemMenuComponent_li_0_a_1_span_2_Template, 2, 1, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("routerLink", (ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.tipo) == ctx_r3.TIPOLINK_ROTA ? ctx_r3.item.link.url : null)("href", (ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.tipo) == ctx_r3.TIPOLINK_URL ? ctx_r3.item.link.url : null, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"])("target", (ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.tipo) == ctx_r3.TIPOLINK_URL && ctx_r3.item.link.novaAba ? "_blank" : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.classIconeFontAwesome);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r3.item == null ? null : ctx_r3.item.link == null ? null : ctx_r3.item.link.texto);
} }
function ItemMenuComponent_li_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ItemMenuComponent_li_0_a_1_Template, 3, 5, "a", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.idSideMenuVisivel.length == 0 || ctx_r0.idSideMenuVisivel[ctx_r0.idSideMenuVisivel.length - 1] == ctx_r0.item.id || ctx_r0.item.idParents.includes(ctx_r0.idSideMenuVisivel[ctx_r0.idSideMenuVisivel.length - 1]));
} }
function ItemMenuComponent_ng_template_1_li_0_a_1_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "i", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](ctx_r11.item.link.classIconeFontAwesome);
} }
function ItemMenuComponent_ng_template_1_li_0_a_1_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r12.item.link.texto);
} }
function ItemMenuComponent_ng_template_1_li_0_a_1_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "a", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ItemMenuComponent_ng_template_1_li_0_a_1_Template_a_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3); return ctx_r13.onClickComponent($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ItemMenuComponent_ng_template_1_li_0_a_1_span_1_Template, 2, 2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, ItemMenuComponent_ng_template_1_li_0_a_1_span_2_Template, 2, 1, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "i", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r9.item.link.classIconeFontAwesome);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r9.item.link.texto);
} }
function ItemMenuComponent_ng_template_1_li_0_ng_container_3_br_item_menu_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "br-item-menu", 17);
} if (rf & 2) {
    const subItem_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("item", subItem_r15)("closeMenu", ctx_r16.closeMenu)("mudancaExibicaoSideMenu", ctx_r16.mudancaExibicaoSideMenu)("idSideMenuVisivel", ctx_r16.idSideMenuVisivel);
} }
function ItemMenuComponent_ng_template_1_li_0_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ItemMenuComponent_ng_template_1_li_0_ng_container_3_br_item_menu_1_Template, 1, 4, "br-item-menu", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const subItem_r15 = ctx.$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", subItem_r15.exibicao == null || subItem_r15.exibicao == ctx_r10.SEMPRE || subItem_r15.exibicao == ctx_r10.LOGADO && ctx_r10.usuario != null || subItem_r15.exibicao == ctx_r10.NAO_LOGADO && ctx_r10.usuario == null);
} }
function ItemMenuComponent_ng_template_1_li_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ItemMenuComponent_ng_template_1_li_0_a_1_Template, 5, 2, "a", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, ItemMenuComponent_ng_template_1_li_0_ng_container_3_Template, 2, 1, "ng-container", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassMap"](ctx_r8.expandido ? "side-menu active" : "side-menu");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r8.idSideMenuVisivel.length == 0 || ctx_r8.idSideMenuVisivel[ctx_r8.idSideMenuVisivel.length - 1] == ctx_r8.item.id || ctx_r8.item.idParents.includes(ctx_r8.idSideMenuVisivel[ctx_r8.idSideMenuVisivel.length - 1]));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r8.item.subItens);
} }
function ItemMenuComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, ItemMenuComponent_ng_template_1_li_0_Template, 4, 4, "li", 8);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.idSideMenuVisivel.length == 0 || ctx_r2.idSideMenuVisivel[ctx_r2.idSideMenuVisivel.length - 1] == ctx_r2.item.id || ctx_r2.item.idParents.includes(ctx_r2.idSideMenuVisivel[ctx_r2.idSideMenuVisivel.length - 1]) || ctx_r2.item.idChildren.includes(ctx_r2.idSideMenuVisivel[ctx_r2.idSideMenuVisivel.length - 1]));
} }
class ItemMenuComponent extends _base_base_base_component__WEBPACK_IMPORTED_MODULE_2__["BaseComponent"] {
    constructor() {
        super();
        //constantes usadas no template
        this.SEMPRE = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_1__["RegraExibicaoMenu"].SEMPRE;
        this.LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_1__["RegraExibicaoMenu"].LOGADO;
        this.NAO_LOGADO = _regra_exibicao_menu_enum__WEBPACK_IMPORTED_MODULE_1__["RegraExibicaoMenu"].NAO_LOGADO;
        this.TIPOLINK_ROTA = _base_tipo_link_enum__WEBPACK_IMPORTED_MODULE_0__["TipoLink"].ROTA;
        this.TIPOLINK_URL = _base_tipo_link_enum__WEBPACK_IMPORTED_MODULE_0__["TipoLink"].URL;
        //ID do side-menu (um menu com subitens de um item) sendo exibido no momento
        this.idSideMenuVisivel = [];
        // o EventEmitter de fechamento do menu é passado para os grupos e depois para os itens
        // de menu a fim de que seja chamado quando um item de menu de rota (sem uma função que
        // trate o click) for clicado
        this.closeMenu = null;
        // evento disparado quando um side menu é exibido ou escondido
        // side-menu é um menu formado por subItens de um item de menu
        this.mudancaExibicaoSideMenu = null;
        // se o item tiver subitens, essa propriedade determina se os subitens estão expandidos
        // ou colapsados
        this.expandido = false;
    }
    // SE TIVER SUBITENS: o click no elemento inverte a condição de expandido ou não do próprio componente
    // SEM SUBITENS, COM CLICK SETADO: invoca a função associada ao click passando o próprio item como argumento
    // SEM SUBITENS NEM CLICK SETADO: Chama 'emit' do EventEmitter recebido em 'closeMenu'
    onClickComponent(event) {
        if (this.item.subItens && this.item.subItens.length > 0) {
            this.expandido = !this.expandido;
            this.mudancaExibicaoSideMenu.emit(this.expandido ? this.item.id : null);
        }
        //Se tiver uma função associada ao atributo 'click', invoca-a
        else if (this.item.click) {
            this.item.click(this.item);
        }
        else if (this.closeMenu != null) {
            this.closeMenu.emit(event);
        }
    }
}
ItemMenuComponent.ɵfac = function ItemMenuComponent_Factory(t) { return new (t || ItemMenuComponent)(); };
ItemMenuComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: ItemMenuComponent, selectors: [["br-item-menu"]], inputs: { item: "item", idSideMenuVisivel: "idSideMenuVisivel", closeMenu: "closeMenu", mudancaExibicaoSideMenu: "mudancaExibicaoSideMenu", expandido: "expandido" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 2, consts: [[4, "ngIf", "ngIfElse"], ["itemAgrupador", ""], ["class", "menu-item", 3, "routerLink", "href", "target", "click", 4, "ngIf"], [1, "menu-item", 3, "routerLink", "href", "target", "click"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], ["class", "content", 4, "ngIf"], ["aria-hidden", "true"], [1, "content"], [3, "class", 4, "ngIf"], ["href", "javascript: void(0)", "class", "menu-item", 3, "click", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["href", "javascript: void(0)", 1, "menu-item", 3, "click"], ["class", "icon", 4, "ngIf"], [1, "support"], ["aria-hidden", "true", 1, "fas", "fa-angle-right"], [1, "icon"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel", 4, "ngIf"], [3, "item", "closeMenu", "mudancaExibicaoSideMenu", "idSideMenuVisivel"]], template: function ItemMenuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, ItemMenuComponent_li_0_Template, 2, 1, "li", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ItemMenuComponent_ng_template_1_Template, 1, 1, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.item.subItens == null || ctx.item.subItens.length == 0)("ngIfElse", _r1);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterLinkWithHref"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgForOf"], ItemMenuComponent], styles: ["a[_ngcontent-%COMP%] {\n        text-decoration: none;\n        font-weight: normal;\n      }"] });


/***/ }),

/***/ "w0x5":
/*!****************************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header-login/header-login.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: HeaderLoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderLoginComponent", function() { return HeaderLoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../base */ "KFZd");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _signin_signin_signin_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../signin/signin/signin.component */ "aAU5");
/* harmony import */ var _divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../divider/divider/divider.component */ "4yHK");
/* harmony import */ var _button_button_button_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../button/button/button.component */ "uADd");







function HeaderLoginComponent_img_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "img", 19);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx_r0.usuario == null ? null : ctx_r0.usuario.imgAvatar, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
} }
function HeaderLoginComponent_div_24_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "nav", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "li", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "i", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Item");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "li", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "i", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Item");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "i", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Link de Acesso");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "span", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](25, "i", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Link de Acesso");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "span", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "i", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Link de Acesso ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "span", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, "T\u00EDtulo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "span", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "25 de out");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Nostrud consequat culpa ex mollit aute. Ex ex veniam ea labore laboris duis duis elit. Ex aute dolor enim aute Lorem dolor. Duis labore ad anim culpa. Non aliqua excepteur sunt eiusmod ex consectetur ex esse laborum velit ut aute.");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](41, "span", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](44, "T\u00EDtulo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "span", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](46, "24 de out");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, "Labore nulla elit laborum nulla duis. Deserunt ad nulla commodo occaecat nulla proident ea proident aliquip dolore sunt nulla. Do sit eu consectetur quis culpa. Eiusmod minim irure sint nulla incididunt occaecat ipsum mollit in ut. Minim adipisicing veniam adipisicing velit nostrud duis consectetur aute nulla deserunt culpa aliquip.");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](49, "span", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](51, "span", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](53, "T\u00EDtulo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "span", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](55, "03 de out");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](57, "Duis qui dolor dolor qui sint consectetur. Ipsum eu dolore ex anim reprehenderit laborum commodo. Labore do ut nulla eiusmod consectetur.");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "span", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "T\u00EDtulo");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "span", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](63, "16 de mai");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](65, "Sunt velit dolor enim mollit incididunt irure est. Ad ea Lorem culpa quis occaecat sunt in exercitation nisi. Sit laborum laborum dolor culpa ipsum velit. Non nulla nisi dolore et anim consequat officia deserunt amet qui. Incididunt exercitation irure labore ut Lorem culpa. Dolore ea irure pariatur ullamco culpa veniam amet dolor in fugiat pariatur ut. Sit non ut enim et incididunt tempor irure pariatur ex proident labore cillum dolore nisi.");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class HeaderLoginComponent extends _base__WEBPACK_IMPORTED_MODULE_1__["BaseComponent"] {
    constructor() {
        super();
        //Evento de click no botão signin
        this.clickEntrar = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        //Evento de click no botão sair
        this.clickSair = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    onClickEntrar(event) {
        this.clickEntrar.emit(event);
    }
    onClickSair(event) {
        this.clickSair.emit(event);
    }
}
HeaderLoginComponent.ɵfac = function HeaderLoginComponent_Factory(t) { return new (t || HeaderLoginComponent)(); };
HeaderLoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HeaderLoginComponent, selectors: [["br-header-login"]], inputs: { usuario: "usuario" }, outputs: { clickEntrar: "clickEntrar", clickSair: "clickSair" }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 25, vars: 7, consts: [[1, "header-login"], [3, "ngClass"], ["tipoSignin", "entrar", 3, "click"], [1, "avatar", "dropdown"], [1, "br-avatar", 3, "title"], [1, "image"], ["alt", "Avatar", 3, "src", 4, "ngIf"], ["type", "button", "aria-label", "Abrir Menu de usu\u00E1rio", "data-toggle", "dropdown", 1, "br-button", "circle", "small"], ["aria-hidden", "true", 1, "fas", "fa-angle-down"], [1, "br-notification"], [1, "notification-header"], [1, "row"], [1, "col-10"], [1, "text-bold"], [1, "notification-body"], ["ngClass", "br-divider"], ["id", "divBotaoSair", 1, "col-10"], ["ngClass", "secondary small", 3, "click"], ["class", "br-tab", 4, "ngIf"], ["alt", "Avatar", 3, "src"], [1, "br-tab"], [1, "tab-nav"], [1, "tab-item"], ["type", "button", "data-panel", "notif-item783", "aria-label", "notif-item783"], [1, "name"], [1, "icon"], ["aria-hidden", "true", 1, "fas", "fa-image"], [1, "tab-item", "is-active"], ["type", "button", "data-panel", "notif-item784", "aria-label", "notif-item784"], [1, "tab-content"], ["id", "notif-item783", 1, "tab-panel"], [1, "br-list"], ["type", "button", 1, "br-item"], ["aria-hidden", "true", 1, "fas", "fa-heartbeat"], [1, "br-divider"], ["id", "notif-item784", 1, "tab-panel", "is-active"], [1, "br-tag", "status", "small", "warning"], [1, "text-medium", "mb-2"]], template: function HeaderLoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "br-signin", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HeaderLoginComponent_Template_br_signin_click_2_listener($event) { return ctx.onClickEntrar($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, HeaderLoginComponent_img_7_Template, 1, 1, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "small");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "br-divider", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "br-button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HeaderLoginComponent_Template_br_button_click_22_listener($event) { return ctx.onClickSair($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "Sair");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, HeaderLoginComponent_div_24_Template, 66, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "header-sign-in " + (ctx.usuario == null ? "" : "d-none"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "header-avatar " + (ctx.usuario != null ? "" : "d-none"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("title", (ctx.usuario == null ? null : ctx.usuario.nomeCompleto) || (ctx.usuario == null ? null : ctx.usuario.upn));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.usuario == null ? null : ctx.usuario.imgAvatar);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"]((ctx.usuario == null ? null : ctx.usuario.nomeCompleto) || (ctx.usuario == null ? null : ctx.usuario.upn));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"]((ctx.usuario == null ? null : ctx.usuario.email) || (ctx.usuario == null ? null : ctx.usuario.upn));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", false);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], _signin_signin_signin_component__WEBPACK_IMPORTED_MODULE_3__["SigninComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _divider_divider_divider_component__WEBPACK_IMPORTED_MODULE_4__["DividerComponent"], _button_button_button_component__WEBPACK_IMPORTED_MODULE_5__["ButtonComponent"]], styles: ["#divBotaoSair[_ngcontent-%COMP%] {\n        margin-top: 10px;\n        margin-bottom: 10px;\n      }"] });


/***/ }),

/***/ "w11H":
/*!********************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/header/header/BRHeader.ts ***!
  \********************************************************************************/
/*! exports provided: BRHeader */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BRHeader", function() { return BRHeader; });
/**
 * Código copiado de: https://dsgov.estaleiro.serpro.gov.br/components/header?tab=desenvolvedor
 * na versão 2.1.0-BETA e convertido para Typescript
 */
class BRHeader {
    constructor(name, component) {
        this.name = name;
        this.component = component;
        this.componentSearch = this.component.querySelector('.header-search');
        this.componentSearchInput = this.component.querySelector('.header-search input');
        this.componentSearchTrigger = this.component.querySelector('[data-toggle="search"]');
        this.componentSearchDismiss = this.component.querySelector('[data-dismiss="search"]');
        this.hideDrop = null;
        this.menuTrigger = this.component.querySelector('[data-target="#main-navigation"]');
        this._setBehavior();
    }
    _setBehavior() {
        this._setLoginBehavior();
        this._setLogoutBehavior();
        this._setSearchBehaviors();
        this._setKeyboardBehaviors();
        this._setDropdownBehavior();
        this._setSticky();
    }
    _setLoginBehavior() {
        for (const login of this.component.querySelectorAll('[data-trigger="login"]')) {
            login.addEventListener('click', () => {
                const loginParent = login.closest('.header-login');
                loginParent.querySelector('.header-sign-in').classList.add('d-none');
                loginParent.querySelector('.header-avatar').classList.remove('d-none');
            });
        }
    }
    _setLogoutBehavior() {
        for (const logout of this.component.querySelectorAll('[data-trigger="logout"]')) {
            logout.addEventListener('click', () => {
                const logoutParent = logout.closest('.header-login');
                logoutParent.querySelector('.avatar').classList.remove('show');
                logoutParent
                    .querySelector('[data-toggle="dropdown"]')
                    .classList.remove('active');
                logoutParent
                    .querySelector('.header-sign-in')
                    .classList.remove('d-none');
                logoutParent.querySelector('.header-avatar').classList.add('d-none');
            });
        }
    }
    _setSearchBehaviors() {
        // Abrir busca
        if (this.componentSearchTrigger) {
            this.componentSearchTrigger.addEventListener('focus', () => {
                this._cleanDropDownHeader();
            });
            this.componentSearchTrigger.addEventListener('click', () => {
                this._openSearch();
            });
        }
        // Fechar busca
        if (this.componentSearchDismiss) {
            this.componentSearchDismiss.addEventListener('click', () => {
                this._closeSearch();
            });
        }
    }
    _setKeyboardBehaviors() {
        if (this.componentSearchInput) {
            this.componentSearchInput.addEventListener('keydown', (event) => {
                switch (event.keyCode) {
                    // Tecla ESC
                    case 27:
                        this._closeSearch();
                        break;
                    default:
                        break;
                }
            });
        }
        for (const trigger of this.component.querySelectorAll('.dropdown [data-toggle="dropdown"]')) {
            trigger.addEventListener('keydown', (event) => {
                switch (event.keyCode) {
                    // Tecla ESC
                    case 32:
                        if (event.target.parentNode.classList.contains('show')) {
                            event.target.parentNode.click();
                            event.target.parentNode.classList.remove('show');
                            event.target.classList.remove('active');
                            event.stopPropagation();
                        }
                        break;
                    default:
                        break;
                }
            });
        }
    }
    _openSearch() {
        if (this.componentSearch) {
            this.componentSearch.classList.add('active');
            this.componentSearch.querySelector('input').focus();
        }
    }
    _closeSearch() {
        if (this.componentSearch) {
            this.componentSearch.classList.remove('active');
            //this.componentSearchTrigger.focus()
            this._nextFocusElement().focus();
        }
    }
    _setDropdownBehavior() {
        let hideDrop;
        for (const trigger of this.component.querySelectorAll('.dropdown [data-toggle="dropdown"]')) {
            trigger.addEventListener('click', (event) => {
                clearTimeout(hideDrop);
                // Toggle de abrir / fechar
                const hasShow = event.target.parentNode.classList.contains('active');
                if (hasShow) {
                    event.target.parentNode.classList.remove('active');
                    event.target.parentNode.parentNode.classList.remove('show');
                }
                else {
                    this._cleanDropDownHeader();
                    trigger.classList.add('active');
                    trigger.parentNode.classList.add('show');
                    // Evita que o componente feche o drop ao navegar pelo teclado
                    const next = this._nextFocusElement();
                    next.addEventListener('focus', (event) => {
                        clearTimeout(hideDrop);
                    });
                }
                event.stopPropagation();
            });
            // Faz o drop fechar ao clicar fora
            trigger.addEventListener('blur', (event) => {
                hideDrop = setTimeout(this._cleanDropDownHeaderRef, 500, this.component);
            });
        }
        this.menuTrigger.addEventListener('focus', (event) => {
            this._cleanDropDownHeader();
        });
    }
    _cleanDropDownHeaderRef(ref) {
        for (const trigger of ref.querySelectorAll('.dropdown.show')) {
            trigger.classList.remove('show');
            trigger.parentNode.classList.remove('show');
            for (const button of ref.querySelectorAll('.br-button')) {
                button.classList.remove('active');
            }
        }
    }
    _cleanDropDownHeader() {
        this._cleanDropDownHeaderRef(this.component);
    }
    _setSticky() {
        if (this.component.hasAttribute('data-sticky')) {
            window.onscroll = () => {
                if (window.pageYOffset > this.component.offsetHeight) {
                    this.component.classList.add('sticky', 'compact');
                }
                else {
                    this.component.classList.remove('sticky', 'compact');
                }
            };
        }
    }
    _nextFocusElement() {
        //add all elements we want to include in our selection
        const focussableElements = 'a:not([disabled]), button:not([disabled]), input[type=text]:not([disabled]), [tabindex]:not([disabled]):not([tabindex="-1"])';
        if (document.activeElement) {
            const focussable = Array.prototype.filter.call(document.body.querySelectorAll(focussableElements), (element) => {
                //check for visibility while always include the current activeElement
                return (element.offsetWidth > 0 ||
                    element.offsetHeight > 0 ||
                    element === document.activeElement);
            });
            const index = focussable.indexOf(document.activeElement);
            if (index > -1) {
                const nextElement = focussable[index + 1] || focussable[0];
                //nextElement.focus();
                return nextElement;
            }
        }
        return null;
    }
}


/***/ }),

/***/ "yJbv":
/*!*******************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/dsgov/dsgov.module.ts ***!
  \*******************************************************************/
/*! exports provided: DsgovModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DsgovModule", function() { return DsgovModule; });
/* harmony import */ var projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! projects/dsgov-components/src/public-api */ "bE7N");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");


class DsgovModule {
}
DsgovModule.ɵfac = function DsgovModule_Factory(t) { return new (t || DsgovModule)(); };
DsgovModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: DsgovModule });
DsgovModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"],
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["BreadcrumbModule"],
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["DividerModule"],
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["InputModule"],
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["MenuModule"],
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["FooterModule"],
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["HeaderModule"],
            projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["SigninModule"],
        ], projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["BreadcrumbModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["DividerModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["MenuModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["FooterModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["HeaderModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["InputModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["SigninModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](DsgovModule, { imports: [projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["BreadcrumbModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["DividerModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["InputModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["MenuModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["FooterModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["HeaderModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["SigninModule"]], exports: [projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["ButtonModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["BreadcrumbModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["DividerModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["MenuModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["FooterModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["HeaderModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["InputModule"],
        projects_dsgov_components_src_public_api__WEBPACK_IMPORTED_MODULE_0__["SigninModule"]] }); })();


/***/ }),

/***/ "yVyG":
/*!**************************************************************************************!*\
  !*** ./projects/dsgov-components/src/lib/components/breadcrumb/breadcrumb.module.ts ***!
  \**************************************************************************************/
/*! exports provided: BreadcrumbModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BreadcrumbModule", function() { return BreadcrumbModule; });
/* harmony import */ var _base_base_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../base/base.module */ "KeFx");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./breadcrumb/breadcrumb.component */ "R1os");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");





class BreadcrumbModule {
}
BreadcrumbModule.ɵfac = function BreadcrumbModule_Factory(t) { return new (t || BreadcrumbModule)(); };
BreadcrumbModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: BreadcrumbModule });
BreadcrumbModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"], _base_base_module__WEBPACK_IMPORTED_MODULE_0__["BaseModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](BreadcrumbModule, { declarations: [_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__["BreadcrumbComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"], _base_base_module__WEBPACK_IMPORTED_MODULE_0__["BaseModule"]], exports: [_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_2__["BreadcrumbComponent"]] }); })();


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map
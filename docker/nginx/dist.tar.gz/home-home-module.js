(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "MVaj":
/*!*************************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/home/home-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: routes, HomeRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeRoutingModule", function() { return HomeRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _home_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.component */ "ijQz");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _home_component__WEBPACK_IMPORTED_MODULE_1__["HomeComponent"] }];
class HomeRoutingModule {
}
HomeRoutingModule.ɵfac = function HomeRoutingModule_Factory(t) { return new (t || HomeRoutingModule)(); };
HomeRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: HomeRoutingModule });
HomeRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](HomeRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "dV2G":
/*!*****************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/home/home.module.ts ***!
  \*****************************************************************/
/*! exports provided: HomeModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeModule", function() { return HomeModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _dsgov_dsgov_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../dsgov/dsgov.module */ "yJbv");
/* harmony import */ var _home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.component */ "ijQz");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home-routing.module */ "MVaj");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");





class HomeModule {
}
HomeModule.ɵfac = function HomeModule_Factory(t) { return new (t || HomeModule)(); };
HomeModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: HomeModule });
HomeModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_3__["HomeRoutingModule"], _dsgov_dsgov_module__WEBPACK_IMPORTED_MODULE_1__["DsgovModule"]]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](HomeModule, { declarations: [_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_3__["HomeRoutingModule"], _dsgov_dsgov_module__WEBPACK_IMPORTED_MODULE_1__["DsgovModule"]] }); })();


/***/ }),

/***/ "ijQz":
/*!********************************************************************!*\
  !*** ./projects/dsgov-angular-demo/src/app/home/home.component.ts ***!
  \********************************************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _usuario__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../usuario */ "JaEA");
/* harmony import */ var _dsgov_components_src_lib_components_signin_signin_signin_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../dsgov-components/src/lib/components/signin/signin/signin.component */ "aAU5");
/* harmony import */ var _dsgov_components_src_lib_components_breadcrumb_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../dsgov-components/src/lib/components/breadcrumb/breadcrumb/breadcrumb.component */ "R1os");
/* harmony import */ var _dsgov_components_src_lib_components_button_button_button_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../dsgov-components/src/lib/components/button/button/button.component */ "uADd");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _dsgov_components_src_lib_components_input_input_input_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../dsgov-components/src/lib/components/input/input/input.component */ "qnra");
/* harmony import */ var _dsgov_components_src_lib_components_header_header_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../dsgov-components/src/lib/components/header/header/header.component */ "B20u");
/* harmony import */ var _dsgov_components_src_lib_components_footer_footer_footer_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../dsgov-components/src/lib/components/footer/footer/footer.component */ "dTQJ");
/* harmony import */ var _dsgov_components_src_lib_components_menu_menu_menu_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../dsgov-components/src/lib/components/menu/menu/menu.component */ "ApSJ");










const _c0 = function () { return { label: "A", link: "/a" }; };
const _c1 = function () { return { label: "B", link: "/b" }; };
const _c2 = function () { return { label: "C", link: "/c" }; };
const _c3 = function (a0, a1, a2) { return [a0, a1, a2]; };
const _c4 = function () { return { texto: "Link A", url: "/a" }; };
const _c5 = function () { return { texto: "Link B", link: "/b" }; };
const _c6 = function () { return { texto: "Link C", link: "/c" }; };
const _c7 = function (a1) { return { classIconeFontAwesome: "fas fa-ambulance", funcao: a1 }; };
const _c8 = function (a1) { return { classIconeFontAwesome: "fas fa-business-time", funcao: a1 }; };
const _c9 = function (a0, a1) { return [a0, a1]; };
const _c10 = function () { return { texto: "TCU", url: "http://tcu.gov.br" }; };
const _c11 = function () { return { texto: "Minist\u00E9rio P\u00FAblico", url: "http://mp.gov.br" }; };
const _c12 = function () { return { texto: "SAVI", url: "http://sad.ancine.gov.br/sadis" }; };
const _c13 = function () { return { texto: "Cota de Tela", url: "http://sad.ancine.gov.br/cota" }; };
const _c14 = function () { return { texto: "SICA", url: "http://sad.ancine.gov.br/sica" }; };
const _c15 = function () { return { texto: "RPPF", url: "http://sad.ancine.gov.br/rppf" }; };
const _c16 = function (a0, a1, a2, a3) { return [a0, a1, a2, a3]; };
const _c17 = function (a0, a1) { return { "\u00D3rg\u00E3os de Controle": a0, "Outros sistemas": a1 }; };
const _c18 = function () { return { classIconeFontAwesome: "fab fa-facebook-f", texto: "Facebook", url: "http://facebook.com/ancinegovbr" }; };
const _c19 = function () { return { classIconeFontAwesome: "fab fa-twitter", texto: "Twitter", url: "http://twitter.com/ancinegovbr" }; };
const _c20 = function () { return { classIconeFontAwesome: "fab fa-youtube", texto: "Youtube", url: "http://youtube.com/ancinegov" }; };
const _c21 = function () { return { tipo: "rota", classIconeFontAwesome: "fas fa-users", texto: "Entidade", url: "/entidade" }; };
const _c22 = function (a0) { return { link: a0 }; };
const _c23 = function () { return { tipo: "rota", classIconeFontAwesome: "fas fa-map-signs", texto: "Qualquer coisa" }; };
const _c24 = function () { return { tipo: "rota", classIconeFontAwesome: "fas fa-university", texto: "Subgrupo 1.1" }; };
const _c25 = function () { return { tipo: "rota", classIconeFontAwesome: "fas fa-photo-video", texto: "Obras publicit\u00E1rias", url: "http://oglobo.com.br" }; };
const _c26 = function () { return { tipo: "rota", classIconeFontAwesome: "fas fa-money-bill-alt", texto: "Fomento", url: "http://ge.com.br" }; };
const _c27 = function () { return { tipo: "rota", classIconeFontAwesome: "fas fa-film", texto: "Esse tem subitens" }; };
const _c28 = function () { return { tipo: "rota", classIconeFontAwesome: "fas fa-allergies", texto: "Teste ", url: "/entidade" }; };
const _c29 = function (a0) { return [a0]; };
const _c30 = function (a0, a1) { return { link: a0, subItens: a1 }; };
const _c31 = function (a2) { return { classIconeFontAwesome: "fas fa-film", texto: "Grupo 1", itens: a2 }; };
const _c32 = function () { return { classIconeFontAwesome: "fas fa-users", texto: "Entidade", url: "/entidade" }; };
const _c33 = function (a1) { return { exibicao: "sempre", link: a1 }; };
const _c34 = function (a2) { return { classIconeFontAwesome: "fas fa-futbol", texto: "Grupo 2", itens: a2 }; };
const _c35 = function () { return { tipo: "url", texto: "Portal", url: "http://gov.br/ancine" }; };
const _c36 = function () { return { tipo: "url", texto: "SAVI", url: "http://savi.ancine.gov.br" }; };
class HomeComponent {
    constructor(usuarioService) {
        this.usuarioService = usuarioService;
        this.menuExpansaoVisivel = false;
        this.menuRotuloVisivel = false;
        this.menuDividerVisivel = false;
    }
    ngOnInit() { }
    alerta() {
        alert('au au ');
    }
    sirene() {
        alert('uéééénnn uéééénn');
    }
    relogio() {
        alert('tic tac, tic tac');
    }
    signin(event) {
        //this.document.location.href = `https://ssodev.ancine.gov.br/cas/login?redirect_uri=${this.document.location.href}`;
        this.user$ = this.usuarioService.getUsuario();
        this.user$.subscribe((user) => {
            if (user == null) {
                this.user = {};
            }
            else {
                this.user = user;
            }
            this.user.nomeCompleto = 'José da Silva';
            this.user.email = 'josedasilva@dsgov.br';
            this.user.imgAvatar =
                'data:image/jpeg;base64,/9j/4QBKRXhpZgAATU0AKgAAAAgAAwEaAAUAAAABAAAAMgEbAAUAAAABAAAAOgEoAAMAAAABAAIAAAAAAAAAAAEsAAAAAQAAASwAAAAB/9sAQwAGBAUGBQQGBgUGBwcGCAoQCgoJCQoUDg8MEBcUGBgXFBYWGh0lHxobIxwWFiAsICMmJykqKRkfLTAtKDAlKCko/9sAQwEHBwcKCAoTCgoTKBoWGigoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgo/8IAEQgAZgBmAwEiAAIRAQMRAf/EABsAAAEFAQEAAAAAAAAAAAAAAAACAwQFBgEH/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAEDAgT/2gAMAwEAAhADEAAAAdiCeWjeBYptjmgcglPQ5XknqmcPnDDVzvA4KGmULaF4xsq2HS11AdezZx1uGs+krqLLMHlNqEo4A20poMnXabDaqP1Wj3qq5fUQvQbKrsZSfU0tJZwQ226ljGW1rLfk021wN3eQot0Ho1tltXB9UnqysQApIsTTc6ulTKZb0bG11Tzh/dZd7VWeVoXam2OZQkEibXzp7Q2qZy1h43dUXTjKOznrXRZszyT9qkjKAPlFBmBPSJActexQ2RooX57KeDfYwSp0CuP/xAAmEAACAgECBQUBAQAAAAAAAAABAgADBBESBRAgISIGExQxMiMw/9oACAEBAAEFAuV1qU15PqA714xma4XHiWx7kvr/AMPUeW/vYmBviY6qLMauwYeS/DshHDr1E9kDX56EAX2F66iwFuOLa+G5VuNUp1HSZxBPjcVO1pQwrrptFjG/RrX0twW1xx0mcep3VY4QLegssJpqFqnfafDB0+KOkziNb2Y2/bCre5jfGx1Dh5muswxsxoOkzP4ebIj+3YL61l+ZuCE2W8NbdjDqM0nqDH15IusxqtDwuwI3MDy5aax+y5u66s46gsukq7RJjXukRw45qNSe0uHuvm0/x2zb5KO9SxEi6pCNOadpb9UpLl1S+sBhXBXKqxERZWgM2+LeJH618n/Q+jMundAvf24lcSjWIm0M2kfvB+j9L3IPY/R/VlMC6GqrWVqIT5P5WGf/xAAeEQACAgIDAQEAAAAAAAAAAAAAAQIRECEDEiATMf/aAAgBAwEBPwEScvw+T9cWsOKY1Xjjw9eUd2iNydklT8KJHehRoaTJKnWI4vq7LJTSEr2yiGZaYs//xAAcEQACAgMBAQAAAAAAAAAAAAAAAQIRAxAgITH/2gAIAQIBAT8BEl9ZaHxZL3m+XxZFWSpD4lMxsbvjJ4XbIS18JS9EzLpEWPSP/8QAKxAAAQMCBQIFBQEAAAAAAAAAAQACEQMxEBIgIVETQSIwYXGBBDJCUmJy/9oACAEBAAY/AsDUqGGhEfT0xl5cjFQn4Qb9U0AfsFnpmR5PQB8EDZB1W3C8LQvt+Qhc0TcIOaZB3Gso9S+aStzCPT2HKyjb/S8V02jUbma10T6eQY/NshHYufyg2qUcjI9XKHbFNLTdCe2tldt6R39lKbvLuFu4ud6JvhMuwplvcTrcKZg391lK7kHhbDM/9nBZogI5VRb/AD5BNGJ4RZVEEK0qG2QQ9PJZVF7Yyi1xvonQTwiT9nZWUDGDu1SNXT/G5RA41S35Gn3Rce+EaLqQt1CCGiRdQdjjJtoGE4wbLaPldlvhCA43w//EACMQAQACAgIDAAMAAwAAAAAAAAEAESExEFFBYXEggZGx0eH/2gAIAQEAAT8h4J2e1YegmDb9qDaw7DUbiMU6+k3IqXyfiyzG3PqOV0sg3K2cPUZXAPq5/wB/sqvOzs4ueOSJi3WIx3brPstx9IXJ8ghmmnnT9dzXnRIBBLJkkARsc/isE+pw9zUgbbqUSb1DJK6LfyDRkGrDVjk2VTaD3Lgx1NYhe/7SWSHdxwyFy0ESUz9SFUHJluyripdf7ll5Q5RQYPCxSom6dOpjdBqNQYP2rzAnfPQOqgigOnUZTy1ANboEL/CxILm/RmzUREZVPiZFs9xdBtFN0Nza84cCEI82CIKpZiurYnjKRyk4a/Ya5yLOqrm0UcaI0rOnfuXQiwaJ4JcZtDqdk8VeDmgIqANmn7fUsO9I95ddE8uW8WCV2/SJvqEuGgR1Q2qidh3L/siOnyZFqd08lgNw4ZAiWkBWH/SFPpFZPbMATWaZRcTTPQwyhXCeT0hB/iVrYMVJre5v7Ij+7gDygLBajbSISmp30V6IDJNN4i6XJ7in/9oADAMBAAIAAwAAABDB5GxyD3WCF4GLAyIKCQ89at2HkQIWE9H8wAjMmNYLCCMJ3yL/AP/EAB0RAQEBAAIDAQEAAAAAAAAAAAEAESExECBBUWH/2gAIAQMBAT8Q2ayZG7YnD65HHc5OC2zLLPHE21XgmiVXXxl3L4SfIEXXpAfl+sR6+QdIjHyQ/Z6j+NZeS5lkTT4CwY9ETdvk3//EABsRAAMBAQEBAQAAAAAAAAAAAAABESExEFFh/9oACAECAQE/EBJA+cFmjeiZfDY+eV8Gt8gtE6khqdKnh2UgkKBC0YNMXlhTEPkOQ/CQgzSIQFrDo2tMpgotOxdGHQdwfTg//8QAJBABAAICAgICAwADAAAAAAAAAQARITFBUWFxgaEQkcGx0fD/2gAIAQEAAT8QCvx/IShjt8Q4OxBW9Br0yyYLoAdBWJnfwcbb6O6lEWOndO/U8cQLlskDzEVfw5ZY1GJakFobu/qKdLRZHmCS9TusqkFUKREj8SdFPDoQXI4dJkYOLmjUHGGyJcsYYNQpXyrEIemvFFiDaU0HbK2srBahKBozQ8DKgo0LFSPcRhYWYcJ4L/UGGCiOxg9QWi/iVuDf4gtFw7hNLQZG1v7IipzrheOD1lg82VGreo9EaBhXtFF0cNjGnBOIR6HxAQpZzx/zOa2IbYh+sqWY2iLsUzaALbi34afmLGBUrO8/2B+gjlW41Yzzqjg6hB3qUUWVeCZT0edmxKXW+7KmfuJLN5IEW2bs4ndqPtqKlhbfsiL8CHDFQrdmRS2l81E8GCsq4BprbuXdusAHLQQPyg7Y1CjIWOMzqisLmMVqE6dwEfEW3BCHWMNR5p6iBpLaoakLmEoDNg5hiqCkE2SrPGz/ADFb4mEVkXBxDUcw0e5mxcGFeIUqZLmfY+Y9dk7qby1xCGGFugQ7cQG74/DcyPRvfuILUqLMDRCLhWrM31ZzPB/iUhrd5lJ66BNXSZEq5SdbS/QwQyprWR6gvEdMWPUYDc00Dcp4Fixa8enMwkiyvCZiXQSyLNMOo9qN7iDLNFS3hIdH/ZxKqjbTLM6m4TGV3B4yf2y0fWeDiPUOQ8w30rNunU7MYQlC+5YMPqDioTI57PLN11N9R0W1p8T9VjgdMLgsN9RghoCO6JiDcFlnQjwyxMDYUwvWKsj6hGx5NxvCsY6QHua0G1iBsfca94S6l0tj6gBGiHw+ZZdWxIbdGLfFItPmXCxxhjmvDkq+pa3NYLivCzb5ji4H2GHeBn//2Q==';
        });
    }
    logout(event) {
        //this.fechaMenu();
        this.user = null;
        this.usuarioService.logout();
    }
}
HomeComponent.ɵfac = function HomeComponent_Factory(t) { return new (t || HomeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_usuario__WEBPACK_IMPORTED_MODULE_1__["UsuarioService"])); };
HomeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HomeComponent, selectors: [["br-home"]], decls: 172, vars: 221, consts: [[1, "displayFlex"], [1, "flexItemLabel"], [1, "flexItem20"], [1, "flexItem80"], [3, "itens"], ["ngClass", "primary"], ["ngClass", "secondary"], ["ngClass", "secondary inverted"], ["aria-hidden", "true", 1, "fas", "fa-mail-bulk"], ["ngClass", "primary", 3, "isLoading"], ["ngClass", "primary", 3, "isDisabled"], ["ngClass", "primary circle"], ["aria-hidden", "true", 1, "fas", "fa-film"], ["ngClass", "secondary circle"], ["aria-hidden", "true", 1, "fas", "fa-ticket-alt"], ["textoLabel", "Campo default", "placeHolder", "Uma dica default", "textoFeedback", "default n\u00E3o d\u00E1 feedback"], ["textoLabel", "Campo sucesso", "placeHolder", "Uma dica de sucesso", "estado", "success", "textoFeedback", "Feedback de sucesso"], ["textoLabel", "Campo perigoso", "placeHolder", "Uma dica perigosa", "estado", "danger", "textoFeedback", "Feedback perigoso"], ["textoLabel", "Campo alerta", "placeHolder", "Uma dica alarmista", "estado", "warning", "textoFeedback", "Feedback de aten\u00E7\u00E3o"], ["textoLabel", "Campo informa\u00E7\u00E3o", "placeHolder", "Uma dica informativa", "estado", "info", "textoFeedback", "Feedback informativo"], ["textoLabel", "Campo com bot\u00E3o", "placeHolder", "Uma dica com bot\u00E3o", "classIconeFontAwesomeBotao", "fas fa-dog", 3, "clickButton"], ["textoLabel", "Campo desabilitada", "placeHolder", "Uma dica desabilitada", "estado", "warning", "textoFeedback", "Feedback de desabilita\u00E7\u00E3o", 3, "isDisabled"], [1, "flexItem100"], ["textoAssinatura", "Sistema Ancine Digital", "titulo", "Sistema de Coisar Coisas", "subtitulo", "Vers\u00E3o: 1.0.0", 3, "links", "funcionalidades", "usuario", "clickEntrar", "clickSair"], [3, "gruposLinks", "linksRedesSociais"], [1, "header-menu-trigger"], ["type", "button", "aria-label", "Menu", "data-toggle", "menu", "data-target", "#main-navigation", "id", "navigation", 1, "br-button", "small", "circle", 3, "click"], ["aria-hidden", "true", 1, "fas", "fa-bars"], ["titulo", "Agrupamento Expans\u00E3o", 3, "visivel", "grupos", "linksExternos", "closeMenu"], ["titulo", "Agrupamento R\u00F3tulos", "tipoAgrupamentoMenu", "rotulo", 3, "visivel", "grupos", "linksExternos", "closeMenu"], ["titulo", "Agrupamento Dividers", "tipoAgrupamentoMenu", "divider", 3, "visivel", "grupos", "linksExternos", "closeMenu"]], template: function HomeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Bem vindo! Abaixo podem ser encontrados exemplos de uso dos componentes da biblioteca:\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Bot\u00E3o de Login");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br-signin");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, " <br-signin></br-signin> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Breadcrumb");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "br-breadcrumb", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Button");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "br-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Bot\u00E3o");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, " <br-button ngClass=\"primary\">Bot\u00E3o</br-button> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "br-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Bot\u00E3o");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, " <br-button ngClass=\"secondary\">Bot\u00E3o</br-button> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "br-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " Bot\u00E3o");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, " <br-button ngClass=\"secondary inverted\" ><i class=\"fas fa-mail-bulk\" aria-hidden=\"true\"></i> Bot\u00E3o</br-button > ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "br-button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Bot\u00E3o");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, " <br-button ngClass=\"primary\" [isLoading]=\"true\">Bot\u00E3o</br-button> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "br-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, "Bot\u00E3o Desabilitado");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, " <br-button ngClass=\"primary\" [isDisabled]=\"true\">Bot\u00E3o</br-button> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "br-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](48, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](50, " <br-button ngClass=\"primary circle\" ><i class=\"fas fa-film\" aria-hidden=\"true\"></i> </br-button> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "br-button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](53, "i", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](55, " <br-button ngClass=\"secondary circle\" ><i class=\"fas fa-ticket-alt\" aria-hidden=\"true\"></i ></br-button> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](58, "Input");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](60, "br-input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, " <br-input textoLabel=\"Campo default\" placeHolder=\"Uma dica default\" textoFeedback=\"default n\u00E3o d\u00E1 feedback\"></br-input> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](64, "br-input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](66, " <br-input textoLabel=\"Campo sucesso\" placeHolder=\"Uma dica de sucesso\" estado=\"success\" textoFeedback=\"Feedback de sucesso\"></br-input> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](68, "br-input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](70, " <br-input textoLabel=\"Campo perigoso\" placeHolder=\"Uma dica perigosa\" estado=\"danger\" textoFeedback=\"Feedback perigoso\" ></br-input> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](72, "br-input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](74, " <br-input textoLabel=\"Campo alerta\" placeHolder=\"Uma dica alarmista\" estado=\"warning\" textoFeedback=\"Feedback de aten\u00E7\u00E3o\" ></br-input> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](76, "br-input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](78, " <br-input textoLabel=\"Campo informa\u00E7\u00E3o\" placeHolder=\"Uma dica informativa\" estado=\"info\" textoFeedback=\"Feedback informativo\" ></br-input> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "br-input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("clickButton", function HomeComponent_Template_br_input_clickButton_80_listener() { return ctx.alerta(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](82, " <br-input textoLabel=\"Campo com bot\u00E3o\" placeHolder=\"Uma dica com bot\u00E3o\" classIconeFontAwesomeBotao=\"fas fa-dog\" (clickButton)=\"alerta()\" ></br-input> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](84, "br-input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "blockquote", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](86, " <br-input textoLabel=\"Campo desabilitada\" placeHolder=\"Uma dica desabilitada\" estado=\"warning\" textoFeedback=\"Feedback de desabilita\u00E7\u00E3o\" [isDisabled]=\"true\" ></br-input> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](89, "Header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "br-header", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("clickEntrar", function HomeComponent_Template_br_header_clickEntrar_91_listener($event) { return ctx.signin($event); })("clickSair", function HomeComponent_Template_br_header_clickSair_91_listener($event) { return ctx.logout($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "blockquote", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](93, " <br-header textoAssinatura=\"Sistema Ancine Digital\" titulo=\"Sistema de Coisar Coisas\" subtitulo=\"Vers\u00E3o: 1.0.0\"");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](94, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](95);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](96, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](97);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](98, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, " (clickEntrar)=\"signin($event)\" (clickSair)=\"logout($event)\" [usuario]=\"user\" >");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](100, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](101, "</br-header> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](104, "Footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](106, "br-footer", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "blockquote", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](108, " <br-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](109, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](110);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](111, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](112);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](113, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](114, "</br-footer> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](115, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](117, "Menu: Agrupamento por Expans\u00E3o");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](119, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_Template_button_click_120_listener() { return ctx.menuExpansaoVisivel = !ctx.menuExpansaoVisivel; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](121, "i", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "br-menu", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("closeMenu", function HomeComponent_Template_br_menu_closeMenu_122_listener() { return ctx.menuExpansaoVisivel = false; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](123, "blockquote", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](124, " <div class=\"header-menu-trigger\"> <button class=\"br-button small circle\" type=\"button\" aria-label=\"Menu\" data-toggle=\"menu\" data-target=\"#main-navigation\" id=\"navigation\" (click)=\"menuExpansaoVisivel = !menuExpansaoVisivel\" > <i class=\"fas fa-bars\" aria-hidden=\"true\"></i> </button> </div>");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](125, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](126, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](127, " <br-menu titulo=\"Agrupamento Expans\u00E3o\" [visivel]=\"menuExpansaoVisivel\" (closeMenu)=\"menuExpansaoVisivel = false\"");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](128, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](129);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](130, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](131, " {{ \"[linksExternos]=\"[ { tipo: 'url', texto: 'Portal', url: 'http://gov.br/ancine' }, { tipo: 'url', texto: 'SAVI', url: 'http://savi.ancine.gov.br' } ]\\\"\" }}>");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](132, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](133, "</br-menu> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](134, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](136, "Menu: Agrupamento por R\u00F3tulos");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](138, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_Template_button_click_139_listener() { return ctx.menuRotuloVisivel = !ctx.menuRotuloVisivel; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](140, "i", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](141, "br-menu", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("closeMenu", function HomeComponent_Template_br_menu_closeMenu_141_listener() { return ctx.menuRotuloVisivel = false; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](142, "blockquote", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](143, " <div class=\"header-menu-trigger\"> <button class=\"br-button small circle\" type=\"button\" aria-label=\"Menu\" data-toggle=\"menu\" data-target=\"#main-navigation\" id=\"navigation\" (click)=\"menuRotuloVisivel = !menuRotuloVisivel\" > <i class=\"fas fa-bars\" aria-hidden=\"true\"></i> </button> </div>");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](144, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](145, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](146, " <br-menu titulo=\"Agrupamento R\u00F3tulos\" tipoAgrupamentoMenu=\"rotulo\" [visivel]=\"menuRotuloVisivel\" (closeMenu)=\"menuRotuloVisivel = false\"");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](147, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](148);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](149, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](150, " {{ \"[linksExternos]=\"[ { tipo: 'url', texto: 'Portal', url: 'http://gov.br/ancine' }, { tipo: 'url', texto: 'SAVI', url: 'http://savi.ancine.gov.br' } ]\\\"\" }}>");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](151, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](152, "</br-menu> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](155, "Menu: Agrupamento por Dividers");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](156, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](157, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](158, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_Template_button_click_158_listener() { return ctx.menuDividerVisivel = !ctx.menuDividerVisivel; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](159, "i", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "br-menu", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("closeMenu", function HomeComponent_Template_br_menu_closeMenu_160_listener() { return ctx.menuDividerVisivel = false; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](161, "blockquote", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](162, " <div class=\"header-menu-trigger\"> <button class=\"br-button small circle\" type=\"button\" aria-label=\"Menu\" data-toggle=\"menu\" data-target=\"#main-navigation\" id=\"navigation\" (click)=\"menuDividerVisivel = !menuDividerVisivel\" > <i class=\"fas fa-bars\" aria-hidden=\"true\"></i> </button> </div>");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](163, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](164, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](165, " <br-menu titulo=\"Agrupamento Dividers\" tipoAgrupamentoMenu=\"divider\" [visivel]=\"menuDividerVisivel\" (closeMenu)=\"menuDividerVisivel = false\"");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](166, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](167);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](168, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](169, " {{ \"[linksExternos]=\"[ { tipo: 'url', texto: 'Portal', url: 'http://gov.br/ancine' }, { tipo: 'url', texto: 'SAVI', url: 'http://savi.ancine.gov.br' } ]\\\"\" }}>");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](170, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](171, "</br-menu> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("itens", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](29, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](26, _c0), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](27, _c1), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](28, _c2)));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" <br-breadcrumb ", "[itens]=\"[ { label: 'A', link: '/a' }, { label: 'B', link: '/b' }, { label: 'C', link: '/c' } ]\"", " ></br-breadcrumb> ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("isLoading", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("isDisabled", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](42);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("isDisabled", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("links", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](36, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](33, _c4), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](34, _c5), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](35, _c6)))("funcionalidades", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](44, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](40, _c7, ctx.sirene), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](42, _c8, ctx.relogio)))("usuario", ctx.user);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", "[links]=\"[ { texto: 'Link A', url: '/a' }, { texto: 'Link B', link: '/b' }, { texto: 'Link C', link: '/c' } ]\"", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", "[funcionalidades]=\"[ { classIconeFontAwesome: 'fas fa-ambulance', funcao: sirene }, { classIconeFontAwesome: 'fas fa-business-time', funcao: relogio }]\"", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("gruposLinks", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](61, _c17, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](49, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](47, _c10), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](48, _c11)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction4"](56, _c16, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](52, _c12), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](53, _c13), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](54, _c14), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](55, _c15))))("linksRedesSociais", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](67, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](64, _c18), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](65, _c19), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](66, _c20)));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", "[gruposLinks]=\"{ '\u00D3rg\u00E3os de Controle': [ { texto: 'TCU', url: 'http://tcu.gov.br' }, { texto: 'Minist\u00E9rio P\u00FAblico', url: 'http://mp.gov.br' } ], 'Outros sistemas': [ { texto: 'SAVI', url: 'http://sad.ancine.gov.br/sadis' }, { texto: 'Cota de Tela', url: 'http://sad.ancine.gov.br/cota' }, { texto: 'SICA', url: 'http://sad.ancine.gov.br/sica' }, { texto: 'RPPF', url: 'http://sad.ancine.gov.br/rppf' } ] }\"", " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", "[linksRedesSociais]=\"[ { classIconeFontAwesome: 'fab fa-facebook-f', texto: 'Facebook', url: 'http://facebook.com/ancinegovbr' }, { classIconeFontAwesome: 'fab fa-twitter', texto: 'Twitter', url: 'http://twitter.com/ancinegovbr' }, { classIconeFontAwesome: 'fab fa-youtube', texto: 'Youtube', url: 'http://youtube.com/ancinegov' } ]\"", ">");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("visivel", ctx.menuExpansaoVisivel)("grupos", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](113, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](104, _c31, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](100, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](72, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](71, _c21)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](75, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](74, _c23)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](97, _c30, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](77, _c24), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](93, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](79, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](78, _c25)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](82, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](81, _c26)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](90, _c30, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](84, _c27), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](88, _c29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](86, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](85, _c28)))))))), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](111, _c34, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](109, _c29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](107, _c33, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](106, _c32))))))("linksExternos", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](118, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](116, _c35), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](117, _c36)));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", " [grupos]=\"[ { classIconeFontAwesome: 'fas fa-film', texto: 'Grupo 1', itens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-users', texto: 'Entidade', url: '/entidade' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-map-signs', texto: 'Qualquer coisa' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-university', texto: 'Subgrupo 1.1' }, subItens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-photo-video', texto: 'Obras publicit\u00E1rias', url: 'http://oglobo.com.br' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-money-bill-alt', texto: 'Fomento', url: 'http://ge.com.br' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-film', texto: 'Esse tem subitens' }, subItens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-allergies', texto: 'Teste ', url: '/entidade' } } ] } ] } ] }, { classIconeFontAwesome: 'fas fa-futbol', texto: 'Grupo 2', itens: [ { link: { classIconeFontAwesome: 'fas fa-users', texto: 'Entidade', url: '/entidade' } } ] } ]\"", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("visivel", ctx.menuRotuloVisivel)("grupos", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](163, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](154, _c31, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](150, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](122, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](121, _c21)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](125, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](124, _c23)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](147, _c30, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](127, _c24), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](143, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](129, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](128, _c25)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](132, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](131, _c26)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](140, _c30, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](134, _c27), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](138, _c29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](136, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](135, _c28)))))))), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](161, _c34, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](159, _c29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](157, _c33, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](156, _c32))))))("linksExternos", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](168, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](166, _c35), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](167, _c36)));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", " [grupos]=\"[ { classIconeFontAwesome: 'fas fa-film', texto: 'Grupo 1', itens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-users', texto: 'Entidade', url: '/entidade' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-map-signs', texto: 'Qualquer coisa' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-university', texto: 'Subgrupo 1.1' }, subItens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-photo-video', texto: 'Obras publicit\u00E1rias', url: 'http://oglobo.com.br' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-money-bill-alt', texto: 'Fomento', url: 'http://ge.com.br' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-film', texto: 'Esse tem subitens' }, subItens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-allergies', texto: 'Teste ', url: '/entidade' } } ] } ] } ] }, { classIconeFontAwesome: 'fas fa-futbol', texto: 'Grupo 2', itens: [ { exibicao: 'sempre', link: { classIconeFontAwesome: 'fas fa-users', texto: 'Entidade', url: '/entidade' } } ] } ]\"", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("visivel", ctx.menuDividerVisivel)("grupos", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](213, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](204, _c31, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](200, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](172, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](171, _c21)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](175, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](174, _c23)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](197, _c30, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](177, _c24), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](193, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](179, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](178, _c25)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](182, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](181, _c26)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](190, _c30, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](184, _c27), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](188, _c29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](186, _c22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](185, _c28)))))))), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](211, _c34, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](209, _c29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](207, _c33, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](206, _c32))))))("linksExternos", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](218, _c9, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](216, _c35), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](217, _c36)));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", " [grupos]=\"[ { classIconeFontAwesome: 'fas fa-film', texto: 'Grupo 1', itens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-users', texto: 'Entidade', url: '/entidade' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-map-signs', texto: 'Qualquer coisa' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-university', texto: 'Subgrupo 1.1' }, subItens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-photo-video', texto: 'Obras publicit\u00E1rias', url: 'http://oglobo.com.br' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-money-bill-alt', texto: 'Fomento', url: 'http://ge.com.br' } }, { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-film', texto: 'Esse tem subitens' }, subItens: [ { link: { tipo: 'rota', classIconeFontAwesome: 'fas fa-allergies', texto: 'Teste ', url: '/entidade' } } ] } ] } ] }, { classIconeFontAwesome: 'fas fa-futbol', texto: 'Grupo 2', itens: [ { exibicao: 'sempre', link: { classIconeFontAwesome: 'fas fa-users', texto: 'Entidade', url: '/entidade' } } ] } ]\"", "");
    } }, directives: [_dsgov_components_src_lib_components_signin_signin_signin_component__WEBPACK_IMPORTED_MODULE_2__["SigninComponent"], _dsgov_components_src_lib_components_breadcrumb_breadcrumb_breadcrumb_component__WEBPACK_IMPORTED_MODULE_3__["BreadcrumbComponent"], _dsgov_components_src_lib_components_button_button_button_component__WEBPACK_IMPORTED_MODULE_4__["ButtonComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgClass"], _dsgov_components_src_lib_components_input_input_input_component__WEBPACK_IMPORTED_MODULE_6__["InputComponent"], _dsgov_components_src_lib_components_header_header_header_component__WEBPACK_IMPORTED_MODULE_7__["HeaderComponent"], _dsgov_components_src_lib_components_footer_footer_footer_component__WEBPACK_IMPORTED_MODULE_8__["FooterComponent"], _dsgov_components_src_lib_components_menu_menu_menu_component__WEBPACK_IMPORTED_MODULE_9__["MenuComponent"]], styles: ["p[_ngcontent-%COMP%] {\n  margin-top: 10px;\n  margin-bottom: 20px;\n}\n\nhr[_ngcontent-%COMP%] {\n  border-bottom: 1px solid grey;\n}\n\n.displayFlex[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n}\n\n.flexItemLabel[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-bottom: 20px;\n  margin-top: 20px;\n  font-size: large;\n  text-decoration: underline;\n}\n\n.flexItem20[_ngcontent-%COMP%] {\n  width: 19%;\n  margin-right: 1%;\n}\n\n.flexItem80[_ngcontent-%COMP%] {\n  width: 80%;\n}\n\n.flexItem100[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\ndiv[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFnQjtFQUNoQixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUNoQiwwQkFBMEI7QUFDNUI7O0FBRUE7RUFDRSxVQUFVO0VBQ1YsZ0JBQWdCO0FBQ2xCOztBQUNBO0VBQ0UsVUFBVTtBQUNaOztBQUNBO0VBQ0UsV0FBVztBQUNiOztBQUVBO0VBQ0UsaUJBQWlCO0FBQ25CIiwiZmlsZSI6ImhvbWUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInAge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5ociB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBncmV5O1xufVxuXG4uZGlzcGxheUZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LXdyYXA6IHdyYXA7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5mbGV4SXRlbUxhYmVsIHtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIGZvbnQtc2l6ZTogbGFyZ2U7XG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xufVxuXG4uZmxleEl0ZW0yMCB7XG4gIHdpZHRoOiAxOSU7XG4gIG1hcmdpbi1yaWdodDogMSU7XG59XG4uZmxleEl0ZW04MCB7XG4gIHdpZHRoOiA4MCU7XG59XG4uZmxleEl0ZW0xMDAge1xuICB3aWR0aDogMTAwJTtcbn1cblxuZGl2IHNwYW4ge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cbiJdfQ== */"] });


/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map